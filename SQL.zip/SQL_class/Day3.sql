select * from emp
where not ( comm is null or comm = 0)
/
