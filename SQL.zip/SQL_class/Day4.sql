select job
from emp
group by job
having count(*) = 1
/
