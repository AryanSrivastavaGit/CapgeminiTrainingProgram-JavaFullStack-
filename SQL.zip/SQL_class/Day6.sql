select E1.ename, E2.ename as EMP_MGR, E3.loc
from emp E1, emp E2, dept E3
where E1.mgr = E2.empno and E2.deptno = E3.deptno and E1.job = 'CLERK'
/
