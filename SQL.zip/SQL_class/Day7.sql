select * from tab
/
