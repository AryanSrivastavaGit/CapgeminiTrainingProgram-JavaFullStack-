 select distinct sal
from (select sal, dense_rank() over(order by sal desc) as Rank from emp)
where Rank = 2
/
