package com.example.springDataJPA.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springDataJPA.entity.Student;
import com.example.springDataJPA.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	private StudentRepository studentRepository;

	@Override
	public boolean addStudentDetails(Student s) {
		studentRepository.save(s);
		return true;
	}

	@Override
	public Student getStudentById(int id) {		
		return studentRepository.findById(id).orElse(null);
	}

	@Override
	public List<Student> getStudentDetailsList() {		
		return new ArrayList<>(studentRepository.findAll());
	}

	@Override
	public boolean updateStudentDetailsById(int id, Student s) {
		s.setId(id);
		studentRepository.save(s);
		return true;
	}

	@Override
	public boolean deleteStudentDetailsById(int id) {
		studentRepository.deleteById(id);
		return true;
	}

}
