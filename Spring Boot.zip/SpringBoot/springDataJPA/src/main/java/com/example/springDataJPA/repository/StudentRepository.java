package com.example.springDataJPA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springDataJPA.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Integer>{

}
