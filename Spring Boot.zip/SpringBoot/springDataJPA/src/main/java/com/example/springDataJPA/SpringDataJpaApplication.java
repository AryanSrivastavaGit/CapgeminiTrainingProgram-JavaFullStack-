package com.example.springDataJPA;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.springDataJPA.entity.Student;
import com.example.springDataJPA.service.StudentService;
import com.example.springDataJPA.service.StudentServiceImpl;

@SpringBootApplication
public class SpringDataJpaApplication {

	public static void main(String[] args) {
		
		ApplicationContext context = SpringApplication.run(SpringDataJpaApplication.class, args);
		StudentService studentService = context.getBean(StudentServiceImpl.class);
		
////		 get student details list
//		List<Student> sList = studentService.getStudentDetailsList();
//		for(Student s : sList) {
//			System.out.println(s.getId() + " " + s.getName());
//		}
		
		
//		// add student details
//		Student s = new Student();
//		s.setName("Aryan Kumar");
//		boolean tf = studentService.addStudentDetails(s);
//		System.out.println(tf);
//		
		
//		// get student details by id
//		int id = 3;
//		Student stu = studentService.getStudentById(id);
//		System.out.println(stu.getId() + " " + stu.getName());
		
		
//		//update student details by id
//		int id = 1;
//		Student s = new Student();
//		s.setName("Aryan");
//		boolean tf = studentService.updateStudentDetailsById(id, s);
//		System.out.println(tf);
		
		
//		// delete student details by id
//		int id = 2;
//		boolean tf = studentService.deleteStudentDetailsById(id);
//		System.out.println(tf);
		

	}

}
