package com.example.springDataJPA.service;
import java.util.List;

import com.example.springDataJPA.entity.Student;

public interface StudentService {
	public boolean addStudentDetails(Student s);
	public Student getStudentById(int id);
	public List<Student> getStudentDetailsList();
	public boolean updateStudentDetailsById(int id, Student s);
	public boolean deleteStudentDetailsById(int id);
}
