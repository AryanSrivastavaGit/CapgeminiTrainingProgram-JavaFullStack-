package com.example.myJournalApp.repository;

import com.example.myJournalApp.entity.JournalEntry;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JournalRepository extends JpaRepository<JournalEntry, Integer> {
}


// controller --> service --> repository