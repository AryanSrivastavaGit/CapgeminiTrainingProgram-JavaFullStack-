package com.example.myJournalApp.controller;

import com.example.myJournalApp.entity.User;
import com.example.myJournalApp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("myJournal/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("add")
    public ResponseEntity<?> addUser(@RequestBody User obj){
        return new ResponseEntity<>(userService.addUser(obj), HttpStatus.CREATED);
    }

    @GetMapping("get/list")
    public ResponseEntity<?> getUserList(){
        List<User> ul =  userService.getUserList();
        if(ul!=null){
            return new ResponseEntity<>(ul, HttpStatus.FOUND);
        }
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("get/{id}")
    public ResponseEntity<?> getUserById(@PathVariable int id){
        User u =  userService.getUserById(id);
        if(u!=null){
            return new ResponseEntity<>(u, HttpStatus.FOUND);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("delete/{username}")
    public ResponseEntity<?> deleteUserByUsername(@PathVariable String username){
        User u = userService.deleteUserByUsername(username);
        if(u!=null){
            return new ResponseEntity<>(u, HttpStatus.GONE);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("update/{username}")
    public ResponseEntity<?> updateUserByUsername(@PathVariable String username, @RequestBody User obj){
        User u = userService.updateUserByUsername(username, obj);
        if(u==null){
            return new ResponseEntity<>(u, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(u, HttpStatus.ACCEPTED);
    }
}
