package com.example.myJournalApp.service;

import com.example.myJournalApp.entity.JournalEntry;
import com.example.myJournalApp.repository.JournalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

//@Component
public class JournalEntryServiceV2 {

//    @Autowired
    private JournalRepository journalRepository;

    public boolean addJournalEntryService(JournalEntry obj){
        journalRepository.save(obj);
        return true;
    }

    public List<JournalEntry> getJournalEntryListService(){
        return journalRepository.findAll();
    }

    public JournalEntry getJournalEntryByIdService(int id){
        return journalRepository.findById(id).orElse(null);
    }

    public boolean updateJournalEntryService(int id, JournalEntry obj){
        JournalEntry oldObject = journalRepository.findById(id).orElse(null);
        obj.setCreatedAt(oldObject.getCreatedAt());
        obj.setId(id);
        journalRepository.save(obj);
        return true;
    }

    public boolean deleteJournalEntryByIdService(int id){
        journalRepository.deleteById(id);
        return true;
    }
}
