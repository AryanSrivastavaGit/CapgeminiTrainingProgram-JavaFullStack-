package com.example.myJournalApp.controller;

import com.example.myJournalApp.entity.JournalEntry;
import com.example.myJournalApp.service.JournalEntryServiceV2;
import com.example.myJournalApp.service.JournalEntryServiceV2ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("journal")
public class JournalEntryControllerV2ResponseEntity {

    @Autowired
    private JournalEntryServiceV2ResponseEntity journalEntryServiceV2ResponseEntity;

    @PostMapping("add/entry")
    public ResponseEntity<Boolean> addJournalEntry( @RequestBody JournalEntry obj  ){
        Boolean tf = journalEntryServiceV2ResponseEntity.addJournalEntryService(obj);
        if(tf){
            return new ResponseEntity<>(tf, HttpStatus.CREATED);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @GetMapping("get/list")
    public ResponseEntity<List<JournalEntry>> getJournalEntryList(){
        List<JournalEntry> obj = journalEntryServiceV2ResponseEntity.getJournalEntryListService();
        if(!obj.isEmpty()){
            return new ResponseEntity<>(obj, HttpStatus.FOUND);
        }
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("get/entry/{id}")
    public ResponseEntity<JournalEntry> getJournalEntryById(@PathVariable int id){
        JournalEntry obj = journalEntryServiceV2ResponseEntity.getJournalEntryByIdService(id);
        if(obj!=null){
            return new ResponseEntity<>(obj, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("update/entry/{id}")
    public ResponseEntity<Boolean> updateJournalEntry(@PathVariable int id, @RequestBody JournalEntry obj){
        Boolean tf = journalEntryServiceV2ResponseEntity.updateJournalEntryService(id, obj);
        if(tf){
            return new ResponseEntity<>(tf, HttpStatus.ACCEPTED);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("delete/entry/{id}")
    public ResponseEntity<?> deleteJournalEntryById(@PathVariable int id){  // ? will take any return type
        Boolean tf = journalEntryServiceV2ResponseEntity.deleteJournalEntryByIdService(id);
        if(tf){
            return new ResponseEntity<>(tf, HttpStatus.GONE);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
