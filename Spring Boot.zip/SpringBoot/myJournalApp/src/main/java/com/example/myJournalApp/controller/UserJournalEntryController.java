package com.example.myJournalApp.controller;

import com.example.myJournalApp.entity.JournalEntry;
import com.example.myJournalApp.repository.JournalRepository;
import com.example.myJournalApp.repository.UserRepository;
import com.example.myJournalApp.service.UserJournalEntryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("myJournal/user/journal")
public class UserJournalEntryController {

    @Autowired
    private UserJournalEntryService userJournalEntryService;

    @PostMapping("add/{username}")
    public String addJournalEntry(@PathVariable String username,@RequestBody JournalEntry obj){
        return userJournalEntryService.addJournalEntry(username, obj);
    }

    @GetMapping("list/{username}")
    public List<JournalEntry> getJournalEntryListByUsername(@PathVariable String username){
        return userJournalEntryService.getJournalEntryListByUsername(username);
    }

    @GetMapping("entry/{username}/{id}")
    public JournalEntry getUserJournalEntryById(@PathVariable String username, @PathVariable int id){
        return userJournalEntryService.getUserJournalEntryById(username, id);
    }

    @DeleteMapping("delete/{username}/{id}")
    public String deleteUserJournalEntryById(@PathVariable String username, @PathVariable int id){
        return userJournalEntryService.deleteUserJournalEntryById(username, id);
    }

    @PutMapping("update/{username}/{id}")
    public String updateUserJournalEntryById(@PathVariable String username, @PathVariable int id, @RequestBody JournalEntry obj){
        return userJournalEntryService.updateUserJournalEntryById(username, id, obj);
    }
}
