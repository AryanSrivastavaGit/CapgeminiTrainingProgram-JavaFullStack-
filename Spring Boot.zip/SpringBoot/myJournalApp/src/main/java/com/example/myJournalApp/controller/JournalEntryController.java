package com.example.myJournalApp.controller;

import com.example.myJournalApp.entity.JournalEntry;
import com.example.myJournalApp.repository.JournalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//@RestController
@RequestMapping("journal")
public class JournalEntryController {
//    Map<Integer, JournalEntry> journalEntryList = new HashMap<>();
//
//    @PostMapping("add/entry")
//    public boolean addJournalEntry( @RequestBody JournalEntry obj  ){
//        journalEntryList.put(obj.getId(), obj);
//        return true;
//    }
//
//    @GetMapping("get/list")
//    public List<JournalEntry> getJournalEntryList(){
//        return new ArrayList<>(journalEntryList.values());
//    }
//
//    @GetMapping("get/entry/{id}")
//    public JournalEntry getJournalEntryById(@PathVariable int id){
//        return journalEntryList.get(id);
//    }
//
//    @PutMapping("update/entry/{id}")
//    public boolean updateJournalEntry(@PathVariable int id, @RequestBody JournalEntry obj){
//        journalEntryList.put(id, obj);
//        return true;
//    }
//
//    @DeleteMapping("delete/entry/{id}")
//    public boolean deleteJournalEntryById(@PathVariable int id){
//        journalEntryList.remove(id);
//        return true;
//    }



//    @Autowired
    private JournalRepository journalRepository;

    @PostMapping("add/entry")
    public String addJournalEntry(@RequestBody JournalEntry obj){
//        obj.setCreatedAt(LocalDateTime.now());
        journalRepository.save(obj);
        return "Entry Added Successfully";
    }

    @GetMapping("get/entry/list")
    public List<JournalEntry> getJournalEntryList(){
        System.out.println("Complete Journal Entry List: ");
        return journalRepository.findAll();
    }

    @GetMapping("get/entry/{id}")
    public JournalEntry getJournalEntryById(@PathVariable int id){
        System.out.println("Journal Entry of Id: " + id);
        return journalRepository.findById(id).orElse(null);
    }

    @PutMapping("update/entry/{id}")
    public String updateJournalEntry(@PathVariable int id, @RequestBody JournalEntry obj){
        obj.setId(id);
        journalRepository.save(obj);
        return "Entry Updated Successfully";
    }

    @DeleteMapping("delete/entry/{id}")
    public String deleteJournalEntryById(@PathVariable int id){
        journalRepository.deleteById(id);
        return "Entry Deleted Successfully";
    }
}
