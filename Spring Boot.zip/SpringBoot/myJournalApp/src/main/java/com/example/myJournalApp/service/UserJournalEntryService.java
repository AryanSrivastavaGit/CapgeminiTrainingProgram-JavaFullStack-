package com.example.myJournalApp.service;

import com.example.myJournalApp.entity.JournalEntry;
import com.example.myJournalApp.entity.User;
import com.example.myJournalApp.repository.JournalRepository;
import com.example.myJournalApp.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.beans.Transient;
import java.time.LocalDateTime;
import java.util.List;

@Component
//@Transient
@Transactional
public class UserJournalEntryService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private JournalRepository journalRepository;

    public String addJournalEntry(String username, JournalEntry obj){
        User u = userRepository.findByUsername(username);
        obj.setCreatedAt(LocalDateTime.now());
        obj.setUser(u);
        u.getJournalEntryList().add(obj);
        userRepository.save(u);
        journalRepository.save(obj);
        return "saved";
    }

    public List<JournalEntry> getJournalEntryListByUsername(String username){
        User u = userRepository.findByUsername(username);
        if(u == null){
            return null;
        }
        return u.getJournalEntryList();
    }

    public JournalEntry getUserJournalEntryById(String username, int id){
        User u = userRepository.findByUsername(username);
        if(u == null){
            return null;
        }
        JournalEntry e = null;
        for(JournalEntry j : u.getJournalEntryList()){
            if(j.getId()==id){
                e=j;
            }
        }
        if(e == null){
            return null;
        }
        return e;
    }

    public String deleteUserJournalEntryById(String username, int id){
        User u = userRepository.findByUsername(username);

        if(u == null){
            return "User not found";
        }

        JournalEntry entryToDelete = null;

        for(JournalEntry e : u.getJournalEntryList()){
            if(e.getId() == id){
                entryToDelete = e;
                break;
            }
        }

        if(entryToDelete != null){
            u.getJournalEntryList().remove(entryToDelete); // remove from user list
            journalRepository.delete(entryToDelete);       // delete from DB
            userRepository.save(u);                        // update user
            return "Journal Entry Deleted";
        }

        return "Journal Entry not found";
    }

    public String updateUserJournalEntryById(String username, int id, JournalEntry obj){
        User u = userRepository.findByUsername(username);

        if(u == null){
            return "User not found";
        }

        JournalEntry entryToUpdate = null;

        for(JournalEntry e : u.getJournalEntryList()){
            if(e.getId() == id){
                entryToUpdate = e;
                break;
            }
        }

        if(entryToUpdate == null){
            return "Journal Entry not found";
        }

        // update fields
        entryToUpdate.setTitle(obj.getTitle());
        entryToUpdate.setContent(obj.getContent());

        journalRepository.save(entryToUpdate);

        return "Entry Updated Successfully";
    }
}
