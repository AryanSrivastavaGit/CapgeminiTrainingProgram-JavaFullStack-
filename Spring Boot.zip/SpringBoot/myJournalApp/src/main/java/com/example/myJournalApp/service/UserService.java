package com.example.myJournalApp.service;

import com.example.myJournalApp.entity.User;
import com.example.myJournalApp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UserService {


    @Autowired
    private UserRepository userRepository;

    public User addUser(User obj){
        return userRepository.save(obj);
    }

    public List<User> getUserList(){
        return userRepository.findAll();
    }

    public User getUserById(int id){
        return userRepository.findById(id).orElse(null);
    }

    public User deleteUserByUsername(String username){
        User u = userRepository.findByUsername(username);
        if(u!=null){
            int id = u.getId();
            userRepository.deleteById(id);
            return u;
        }
        return null;
    }

    public User updateUserByUsername(String username, User obj){
        User old = userRepository.findByUsername(username);
        if(old == null){
            return null;
        }
        obj.setId(old.getId());
        return userRepository.save(obj);
    }
}
