package com.example.myJournalApp.controller;

import com.example.myJournalApp.entity.JournalEntry;
import com.example.myJournalApp.service.JournalEntryServiceV2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//@RestController
@RequestMapping("journal")
public class JournalEntryControllerV2 {

//    @Autowired
    private JournalEntryServiceV2 journalEntryServiceV2;

    @PostMapping("add/entry")
    public boolean addJournalEntry( @RequestBody JournalEntry obj  ){
        return journalEntryServiceV2.addJournalEntryService(obj);
    }

    @GetMapping("get/list")
    public List<JournalEntry> getJournalEntryList(){
        return journalEntryServiceV2.getJournalEntryListService();
    }

    @GetMapping("get/entry/{id}")
    public JournalEntry getJournalEntryById(@PathVariable int id){
        return journalEntryServiceV2.getJournalEntryByIdService(id);
    }

    @PutMapping("update/entry/{id}")
    public boolean updateJournalEntry(@PathVariable int id, @RequestBody JournalEntry obj){
        return journalEntryServiceV2.updateJournalEntryService(id, obj);
    }

    @DeleteMapping("delete/entry/{id}")
    public boolean deleteJournalEntryById(@PathVariable int id){
        return journalEntryServiceV2.deleteJournalEntryByIdService(id);
    }
}
