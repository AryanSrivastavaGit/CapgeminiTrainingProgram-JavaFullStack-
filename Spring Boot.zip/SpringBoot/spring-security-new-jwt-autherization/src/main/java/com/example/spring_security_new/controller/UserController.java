package com.example.spring_security_new.controller;

import com.example.spring_security_new.entity.User;
import com.example.spring_security_new.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/add")
    public User userDetails(@RequestBody User user){
        return userService.userDetails(user);
    }

    @GetMapping
    public String healthCheck(){
        return "OK";
    }

    @GetMapping("/csrf-token")
    public CsrfToken getCsrfToken(CsrfToken token){
        return token;
    }
}
