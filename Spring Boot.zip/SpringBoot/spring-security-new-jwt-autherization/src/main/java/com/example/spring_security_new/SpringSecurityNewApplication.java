package com.example.spring_security_new;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityNewApplication.class, args);
	}

}
