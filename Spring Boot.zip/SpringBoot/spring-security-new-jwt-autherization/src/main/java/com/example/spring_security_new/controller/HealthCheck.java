package com.example.spring_security_new.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("health-check")
public class HealthCheck {
    @GetMapping
    public String healthCheck(){
        return "OK";
    }

    @GetMapping("/2")
    public String healthCheck2(){
        return "OK";
    }
}
