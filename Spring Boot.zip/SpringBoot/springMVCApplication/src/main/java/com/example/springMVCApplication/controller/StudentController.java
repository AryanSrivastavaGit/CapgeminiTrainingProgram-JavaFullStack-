package com.example.springMVCApplication.controller;

import com.example.springMVCApplication.entity.Student;
import com.example.springMVCApplication.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("student")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping("form")
    public String showForm(){
        return "StudentDataSurveyForm";
    }

    @PostMapping("save")
    public String saveStudent(Student student, Model m){
        studentService.saveStudentService(student);
        m.addAttribute("result", student);
        return "Response";
    }
}
