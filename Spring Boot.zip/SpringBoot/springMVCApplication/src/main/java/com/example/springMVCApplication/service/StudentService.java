package com.example.springMVCApplication.service;

import com.example.springMVCApplication.entity.Student;
import com.example.springMVCApplication.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public void saveStudentService(Student student){
        studentRepository.save(student);
    }
}
