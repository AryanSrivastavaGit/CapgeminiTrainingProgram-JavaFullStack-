package com.example.sprindDataJPAMapping.controller;

import com.example.sprindDataJPAMapping.entity.Category;
import com.example.sprindDataJPAMapping.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("category")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @PostMapping
    public String addCategory(@RequestBody Category obj){
        return categoryService.addCategory(obj);
    }

    @GetMapping("{id}")
    public Category getCategoryById(@PathVariable String id){
        return categoryService.getCategoryById(id);
    }
}
