package com.example.sprindDataJPAMapping.entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;

@Entity
//@JsonIdentityInfo(  // break bidirectional loop, and allow both side to access each other. Note: Must be defined in both classes to work
//        generator = ObjectIdGenerators.PropertyGenerator.class,
//        property = "pincode" // @Id
//)
public class Address {
    private String addressType;
    private String country;
    private String state;
    private String city;
    @Id
    private int pincode;

    @ManyToOne
    @JoinColumn(name = "student_id")
    @JsonIgnoreProperties("addressList")
    private Student student;

    public Address(){}

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getPincode() {
        return pincode;
    }

    public void setPincode(int pincode) {
        this.pincode = pincode;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
}
