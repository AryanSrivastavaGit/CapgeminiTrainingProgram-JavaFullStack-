package com.example.sprindDataJPAMapping.repository;

import com.example.sprindDataJPAMapping.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, String> {
}
