package com.example.sprindDataJPAMapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprindDataJpaMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprindDataJpaMappingApplication.class, args);
	}

}
