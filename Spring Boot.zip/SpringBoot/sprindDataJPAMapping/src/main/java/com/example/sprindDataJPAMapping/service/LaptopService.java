package com.example.sprindDataJPAMapping.service;

import com.example.sprindDataJPAMapping.entity.Laptop;
import com.example.sprindDataJPAMapping.repository.LaptopRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LaptopService {

    @Autowired
    private LaptopRepository laptopRepository;

    public String addLaptop(Laptop obj){
        laptopRepository.save(obj);
        return "Laptop Saved";
    }

    public Laptop getLaptopById(int id){
        return laptopRepository.findById(id).orElse(null);
    }
}
