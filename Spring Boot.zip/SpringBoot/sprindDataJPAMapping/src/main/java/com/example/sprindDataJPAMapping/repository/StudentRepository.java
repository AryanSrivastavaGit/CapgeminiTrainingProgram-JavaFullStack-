package com.example.sprindDataJPAMapping.repository;

import com.example.sprindDataJPAMapping.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Integer> {
}
