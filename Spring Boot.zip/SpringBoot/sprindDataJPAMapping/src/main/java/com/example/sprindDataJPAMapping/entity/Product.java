package com.example.sprindDataJPAMapping.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class Product {

    @Id
    private String id;
    private String name;

    @ManyToMany(mappedBy = "productList", fetch = FetchType.EAGER)
    @JsonIgnoreProperties("productList")
    private List<Category> categoryList;

    public Product() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Category> getCategoryList() {
        return categoryList;
    }

    public void setCategoryList(List<Category> categoryList) {
        this.categoryList = categoryList;
    }
}
