package com.example.sprindDataJPAMapping.controller;

import com.example.sprindDataJPAMapping.entity.Student;
import com.example.sprindDataJPAMapping.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("student")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping
    public String addStudent(@RequestBody Student obj){
        return studentService.addStudent(obj);
    }

    @GetMapping("{id}")
    public Student getStudentById(@PathVariable int id){
        return studentService.getStudentById(id);
    }
}
