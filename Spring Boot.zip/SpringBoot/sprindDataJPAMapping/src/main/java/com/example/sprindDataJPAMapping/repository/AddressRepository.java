package com.example.sprindDataJPAMapping.repository;

import com.example.sprindDataJPAMapping.entity.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Integer> {
}
