package com.example.sprindDataJPAMapping.controller;

import com.example.sprindDataJPAMapping.entity.Address;
import com.example.sprindDataJPAMapping.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("address")
public class AddressController {

    @Autowired
    private AddressService addressService;

    @PostMapping
    public String addAddress(@RequestBody Address obj){
        return addressService.addAddress(obj);
    }

    @GetMapping("{pincode}")
    public Address getAddressByPincode(@PathVariable int pincode){
        return addressService.getAddressByPincode(pincode);
    }
}
