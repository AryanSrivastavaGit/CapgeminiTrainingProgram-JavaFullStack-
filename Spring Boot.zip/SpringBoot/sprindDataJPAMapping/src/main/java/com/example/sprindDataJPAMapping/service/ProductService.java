package com.example.sprindDataJPAMapping.service;

import com.example.sprindDataJPAMapping.entity.Product;
import com.example.sprindDataJPAMapping.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public String addProduct(Product obj){
        productRepository.save(obj);
        return "Product Saved";
    }

    public Product getProductById(String id){
        return productRepository.findById(id).orElse(null);
    }
}
