package com.example.sprindDataJPAMapping.service;

import com.example.sprindDataJPAMapping.entity.Student;
import com.example.sprindDataJPAMapping.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;


    public String addStudent(Student obj){
        studentRepository.save(obj);
        return "Student Saved";
    }

    public Student getStudentById(int id){
        return studentRepository.findById(id).orElse(null);
    }
}
