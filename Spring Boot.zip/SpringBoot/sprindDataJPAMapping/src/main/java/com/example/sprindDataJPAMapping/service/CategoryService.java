package com.example.sprindDataJPAMapping.service;

import com.example.sprindDataJPAMapping.entity.Category;
import com.example.sprindDataJPAMapping.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

@Component
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    public String addCategory(Category obj){
        categoryRepository.save(obj);
        return "Category Saved";
    }

    public Category getCategoryById(@PathVariable String id){
        return categoryRepository.findById(id).orElse(null);
    }
}
