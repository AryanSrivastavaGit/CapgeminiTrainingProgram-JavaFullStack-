package com.example.sprindDataJPAMapping.entity;

import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;

import java.util.List;

@Entity
//@JsonIdentityInfo(  // break bidirectional loop, It tells Jackson: if the same object appears again during serialization, do not print it again — just reference it using its ID(Jackson replaces the object with its ID.).
//        generator = ObjectIdGenerators.PropertyGenerator.class,
//        property = "id"
//)
public class Student {

    @Id
    private int id;
    private String name;
    private String email;

//    -----------------------------------one to one relationship----------------------------------------------
    @OneToOne // create relation between student and laptop table, inside student table extra table get created using FK of laptop table as reference to connect this two table(Student----->Laptop, unidirectional), it is unidirectional because only student knows about laptop not vise versa
    @JoinColumn(name="laptop_id")  // explicitly control the column name.
    @JsonIgnoreProperties("student")
    private Laptop laptop;


//    -----------------------------------one to Manny relationship----------------------------------------------
    @OneToMany(mappedBy = "student")
    @JsonIgnoreProperties("student")  // It tells Jackson not to include certain properties when converting Java objects to JSON or JSON to Java objects
//    example : -
        //    @JsonIgnoreProperties({"password","salary"})
        //    public class User {
        //    private String name;
        //    private String password;
        //    private double salary;
        //    output---
                //{
                //    "name": "Aryan"
                //}
                //    password and salary are ignored.
    private List<Address> addressList;

    public Student(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Laptop getLaptop() {
        return laptop;
    }

    public void setLaptop(Laptop laptop) {
        this.laptop = laptop;
    }


    public List<Address> getAddressList() {
        return addressList;
    }

    public void setAddressList(List<Address> addressList) {
        this.addressList = addressList;
    }
}
