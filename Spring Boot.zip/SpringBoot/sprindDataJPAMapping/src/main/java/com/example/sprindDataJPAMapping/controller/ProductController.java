package com.example.sprindDataJPAMapping.controller;

import com.example.sprindDataJPAMapping.entity.Product;
import com.example.sprindDataJPAMapping.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping
    public String addProduct(@RequestBody Product obj){
        return productService.addProduct(obj);
    }

    @GetMapping("{id}")
    public Product getProductById(@PathVariable String id){
        return productService.getProductById(id);
    }
}
