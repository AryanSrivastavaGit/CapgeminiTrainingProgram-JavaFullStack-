package com.example.sprindDataJPAMapping.controller;

import com.example.sprindDataJPAMapping.entity.Laptop;
import com.example.sprindDataJPAMapping.service.LaptopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("laptop")
public class LaptopController {

    @Autowired
    private LaptopService laptopService;

    @PostMapping
    public String addLaptop(@RequestBody Laptop obj){
        return laptopService.addLaptop(obj);
    }

    @GetMapping("{id}")
    public Laptop getLaptopById(@PathVariable int id){
        return laptopService.getLaptopById(id);
    }
}
