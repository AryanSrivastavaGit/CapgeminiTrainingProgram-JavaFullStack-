package com.example.sprindDataJPAMapping.entity;

import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;

@Entity
//@JsonIdentityInfo(
//        generator = ObjectIdGenerators.PropertyGenerator.class,
//        property = "id"
//)
public class Laptop {

    @Id
    private int id;
    private String brand;
    private String specification;

//    -----------------------------------one to one relationship----------------------------------------------
//    @OneToOne
//    @JoinColumn(name = "student_id")
//    @JsonIgnore // use to break bidirectional loop. Note: laptop will not able to access student data, because before reaching to student @JsonIgnore will break the loop.
//    private Student student;

    @OneToOne(mappedBy = "laptop")
    @JsonIgnoreProperties("laptop")
    private Student student;

    public Laptop(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
}
