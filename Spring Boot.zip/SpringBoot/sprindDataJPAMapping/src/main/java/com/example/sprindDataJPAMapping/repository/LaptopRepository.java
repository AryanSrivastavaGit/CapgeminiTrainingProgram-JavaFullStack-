package com.example.sprindDataJPAMapping.repository;

import com.example.sprindDataJPAMapping.entity.Laptop;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LaptopRepository extends JpaRepository<Laptop, Integer> {
}
