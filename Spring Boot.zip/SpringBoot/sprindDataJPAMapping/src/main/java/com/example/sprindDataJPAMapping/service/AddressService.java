package com.example.sprindDataJPAMapping.service;

import com.example.sprindDataJPAMapping.entity.Address;
import com.example.sprindDataJPAMapping.repository.AddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

@Component
public class AddressService {

    @Autowired
    private AddressRepository addressRepository;

    public String addAddress(Address obj){
        addressRepository.save(obj);
        return "Address Saved";
    }

    public Address getAddressByPincode(int pincode){
        return addressRepository.findById(pincode).orElse(null);
    }
}
