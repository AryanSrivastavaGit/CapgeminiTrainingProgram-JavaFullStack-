package com.example.sprindDataJPAMapping.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class Category {

    @Id
    private String id;
    private String name;

//    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)  //For @ManyToMany associations, the REMOVE entity state transition doesn't make sense to be cascaded because it will propagate beyond the link table. If you delete one entity, Hibernate may delete the other entity completely, not just the relationship.
    @ManyToMany(
        fetch = FetchType.LAZY,
        cascade = {CascadeType.PERSIST, CascadeType.MERGE}
    )
    @JoinTable(name = "category_product_relation", joinColumns = {@JoinColumn(name = "cid")}, inverseJoinColumns = {@JoinColumn(name = "pid")})
    @JsonIgnoreProperties("categoryList")
    private List<Product> productList;

    public Category(){}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Product> getProductList() {
        return productList;
    }

    public void setProductList(List<Product> productList) {
        this.productList = productList;
    }
}


//
//3. CascadeType.REMOVE
//        Meaning
//
//When parent is deleted, the child is also deleted.
//
//Example
//
//Database:
//
//Student
//1 Aryan
//
//Laptop
//101 Dell
//
//Code:
//
//studentRepository.deleteById(1);
//Hibernate executes
//delete from laptop where id=101
//delete from student where id=1
//
//So both get deleted.
//
//        ⚠ This is safe for OneToOne / OneToMany, but dangerous for ManyToMany.