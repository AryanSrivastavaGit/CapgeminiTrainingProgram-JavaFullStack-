package com.example.sprindDataJPAMapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprindDataJpaMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
