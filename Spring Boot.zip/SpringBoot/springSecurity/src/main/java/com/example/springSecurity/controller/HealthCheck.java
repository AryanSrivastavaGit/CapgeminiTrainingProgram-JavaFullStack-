package com.example.springSecurity.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("health-check")
public class HealthCheck {
    @GetMapping
    public String healthCheck(HttpServletRequest request){
        return "OK: " + request.getSession().getId(); // request.getSession().getId() use to get session id
    }
}
