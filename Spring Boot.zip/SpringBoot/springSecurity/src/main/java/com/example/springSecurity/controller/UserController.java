package com.example.springSecurity.controller;

import com.example.springSecurity.entity.User;
import com.example.springSecurity.repository.UserRepository;
import com.example.springSecurity.service.JWTService;
import com.example.springSecurity.service.MyUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("user")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    private BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder(10);  // use to encrypt password

    @PostMapping
    public User addUser(@RequestBody User user){
        user.setPassword(bCryptPasswordEncoder.encode(user.getPassword())); // encrypting and changing password using bCryptPasswordEncoder.encode()
        return userRepository.save(user);
    }

    @GetMapping
    public List<User> userList(){
        return userRepository.findAll();
    }



    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JWTService jwtService;

    @PostMapping("login")
    public String addUserLogin(@RequestBody User user){
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
//        if(authentication.isAuthenticated()){
//            return "Authentication Successful";
//        }
//        return "Authentication Failed";

        if(authentication.isAuthenticated()){
            return jwtService.getToken(user.getUsername());
        }
        return "Authentication Failed";
    }
}
