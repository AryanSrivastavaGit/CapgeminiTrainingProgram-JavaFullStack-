//23)WAJP Reverse each element in an array?
class ReverseEachElement {
    public static void main(String[] args) {

        int[] arr = {123, 45, 908, 7};

        for (int i = 0; i < arr.length; i++) {
            int num = arr[i];
            int rev = 0;

            while (num != 0) {
                int digit = num % 10;
                rev = rev * 10 + digit;
                num = num / 10;
            }

            arr[i] = rev;
        }

        for (int x : arr) {
            System.out.print(x + " ");
        }
    }
}
