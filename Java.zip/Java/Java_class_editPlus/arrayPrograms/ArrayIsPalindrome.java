//17)WAJP Check Array is palindrome or not?
import java.util.Scanner;
class ArrayIsPalindrome {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int size = 5;
        int[] arr = new int[size];

        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }

        boolean isPalindrome = true;

        for (int i = 0; i < size / 2; i++) {
            if (arr[i] != arr[size - 1 - i]) {
                isPalindrome = false;
                break;
            }
        }

        if (isPalindrome) {
            System.out.println("Array is Palindrome");
        } else {
            System.out.println("Array is NOT Palindrome");
        }
    }
}
