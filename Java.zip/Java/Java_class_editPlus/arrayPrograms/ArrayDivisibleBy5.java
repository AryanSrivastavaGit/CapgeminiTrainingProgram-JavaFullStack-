//1)WAJP Print element in array which is divisible by 5 ?
import java.util.Scanner;
class  ArrayDivisibleBy5
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int n = 5;
		int arr[] = new int[n];
		for(int i=0; i<n; i++){
			arr[i]=sc.nextInt();
		}
		for(int i=0; i<n; i++){
			if(arr[i]%5==0){
				System.out.println(arr[i]);
			}
		}
	}
}
