//11)WAJP Find Average of an array?
import java.util.Scanner;
class  ArrayAverage
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int n = 5;
		int arr[] = new int[n];
		int sum = 0;
		for(int i=0; i<n; i++){
			arr[i]=sc.nextInt();
			sum+=arr[i];
		}
		System.out.println(sum/n);
	}
}