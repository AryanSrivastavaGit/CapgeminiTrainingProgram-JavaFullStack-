//21)WAJP Merge given two array?
import java.util.Scanner;

class MergeArrays {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n1 = 3;
        int n2 = 4;

        int[] arr1 = new int[n1];
        int[] arr2 = new int[n2];

        for (int i = 0; i < n1; i++) {
            arr1[i] = sc.nextInt();
        }

        for (int i = 0; i < n2; i++) {
            arr2[i] = sc.nextInt();
        }

        int[] merged = new int[n1 + n2];
        int index = 0;

        for (int i = 0; i < n1; i++) {
            merged[index++] = arr1[i];
        }

        for (int i = 0; i < n2; i++) {
            merged[index++] = arr2[i];
        }

        for (int i = 0; i < merged.length; i++) {
            System.out.print(merged[i] + " ");
        }
    }
}

