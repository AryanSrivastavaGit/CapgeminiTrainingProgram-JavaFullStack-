//6)WAJP Print positive even element in an array?
import java.util.Scanner;
class  PositiveEvenArray
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int n = 5;
		int arr[] = new int[n];
		for(int i=0; i<n; i++){
			arr[i]=sc.nextInt();
		}
		for(int i=0; i<n; i++){
			if(arr[i]%2==0 && arr[i]>=0){
				System.out.println(i);
			}
		}
	}
}
