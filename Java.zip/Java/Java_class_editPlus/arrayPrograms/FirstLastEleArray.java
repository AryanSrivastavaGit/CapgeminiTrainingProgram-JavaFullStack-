//7)WAJP Print First Element and last element?
import java.util.Scanner;
class  FirstLastEleArray
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int n = 5;
		int arr[] = new int[n];
		for(int i=0; i<n; i++){
			arr[i]=sc.nextInt();
		}
		
		System.out.println(arr[0]);
		System.out.println(arr[arr.length-1]);
		
	}
}
