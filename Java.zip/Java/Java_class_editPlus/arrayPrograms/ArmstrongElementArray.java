//14)WAJP Print Armstrong element in an array
import java.util.Scanner;

class ArmstrongElementArray {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int size = 5;
        int arr[] = new int[size];

        // Input array
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }

        // Check Armstrong numbers
        for (int i = 0; i < size; i++) {

            int num = arr[i];
            int temp = num;
            int count = 0;

            // Count digits
            while (temp != 0) {
                count++;
                temp /= 10;
            }

            int sum = 0;
            temp = num;

            // Armstrong calculation
            while (temp != 0) {
                int digit = temp % 10;
                sum += Math.pow(digit, count);
                temp /= 10;
            }

            if (num == sum) {
                System.out.println(num + " is an Armstrong number");
            }
        }
    }
}
