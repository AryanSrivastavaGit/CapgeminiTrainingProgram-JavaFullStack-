//10)WAJP Find Sum of Odd element in an array?
import java.util.Scanner;
class  OddElementSumArray
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int n = 5;
		int arr[] = new int[n];
		int sum = 0;
		for(int i=0; i<n; i++){
			arr[i]=sc.nextInt();
		}
		for(int i=0; i<n; i++){
			if(arr[i]%2!=0){
				sum+=arr[i];
			}
		}
	}
}