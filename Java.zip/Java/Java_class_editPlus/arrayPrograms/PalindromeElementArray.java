//15)WAJP Print Palindrome element in an array?
import java.util.Scanner;
class PalindromeElementArray {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int size = 5;
        int[] arr = new int[size];

        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }

        for (int i = 0; i < size; i++) {

            int num = arr[i];
            int temp = num;
            int rev = 0;

            while (temp != 0) {
                int digit = temp % 10;
                rev = rev * 10 + digit;
                temp /= 10;
            }

            if (num == rev) {
                System.out.println(num + " is a Palindrome");
            }
        }
    }
}
