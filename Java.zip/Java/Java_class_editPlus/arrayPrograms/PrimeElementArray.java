//16)WAJP Print Prime element in an array?
import java.util.Scanner;
class PrimeElementArray {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int size = 5;
        int[] arr = new int[size];

        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }

        for (int i = 0; i < size; i++) {

            int num = arr[i];

            if (num <= 1) continue;

            boolean isPrime = true;

            for (int j = 2; j <= Math.sqrt(num); j++) {
                if (num % j == 0) {
                    isPrime = false;
                    break;
                }
            }

            if (isPrime) {
                System.out.println(num + " is a Prime number");
            }
        }
    }
}
