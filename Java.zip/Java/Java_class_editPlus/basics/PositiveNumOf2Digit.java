class PositiveNumOf2Digit 
{
	public static void main(String[] args) 
	{
		int a = 20;
		String res;
		res = a>=10 && a<=99 ? "2 digit number":"Not 2 digit number";
		System.out.println(res);
	}
}
