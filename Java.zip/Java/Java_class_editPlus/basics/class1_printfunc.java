class class1_printfunc 
{
	public static void main(String[] args) 
	{
		System.out.print("Name: ");
		System.out.println("Aryan");
		System.out.print("Reg no.: ");
		System.out.println("12215619");
	}
}
