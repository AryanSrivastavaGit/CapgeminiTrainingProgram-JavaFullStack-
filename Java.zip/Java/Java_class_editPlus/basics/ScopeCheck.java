class ScopeCheck 
{
	public static void main(String[] args) 
	{
		{
			int a = 10;
			System.out.println(a);
		}
		
		int a = 20;
		System.out.println(a);
	}
}
