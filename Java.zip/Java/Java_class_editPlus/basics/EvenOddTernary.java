class EvenOddTernary 
{
	public static void main(String[] args) 
	{
		int n = 10;
		String res;
		res = n%2==0 ? "Even":"Odd";
		System.out.println(res);
	}
}
