class ForEachLoop 
{
	public static void main(String[] args) 
	{
		String str[] = {"Aryan", "Kumar", "Srivastava"};
		for( String name:str){
			System.out.println(name);
		}
	}
}
//This loop is used to iterate over arrays or collections.