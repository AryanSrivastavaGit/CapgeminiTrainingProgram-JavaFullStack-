class StudentEligibilityTernary
{
	public static void main(String[] args) 
	{
		int attendence = 80;
		int marks = 74;
		String res;
		res = attendence>=75 && marks>=40 ? "Eligible":"Not eligible";
		System.out.println(res);
	}
}
