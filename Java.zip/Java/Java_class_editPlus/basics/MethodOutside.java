public static void greet(){
	System.out.println("Hello");
}

class MethodOutside 
{
	public static void main(String[] args) 
	{
		greet();
	}
}
//All methods in Java must belong to a class