class DivisibleBy3and5Ternary
{
	public static void main(String[] args) 
	{
		int a = 20;
		String res;
		res = a%3==0 && a%5==0 ? "DivisibleBy 3 & 5 both":"Not Divisible By 3 & 5 both";
		System.out.println(res);
	}
}
