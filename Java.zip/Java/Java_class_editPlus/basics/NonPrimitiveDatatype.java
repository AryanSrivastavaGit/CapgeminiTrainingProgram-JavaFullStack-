class Demo
{
}

class NonPrimitiveDatatype 
{
	public static void main(String[] args) 
	{
		Demo obj;
	}
}
