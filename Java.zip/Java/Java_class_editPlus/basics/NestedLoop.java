class NestedLoop 
{
	public static void main(String[] args) 
	{
		int a = 1;
		do{
			System.out.println(a);
			a++;
			do{
				System.out.println(a);
				a++;
			}while(a<1);
		}while(a<1);
	}
}
