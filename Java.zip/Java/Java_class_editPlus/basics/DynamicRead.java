import java.util.Scanner;
class DynamicRead 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		String first_name = sc.next();
		int age = sc.nextInt(); //int age = Integer.parseInt(sc.nextLine()); Industry-recommended
		sc.nextLine(); // consume newline
		String full_name = sc.nextLine();
		char name_first_letter = sc.next().charAt(0);
		System.out.println(first_name);
		System.out.println(full_name);
		System.out.println(age);
		System.out.println(name_first_letter);
	}
}

// Whenever you use nextInt(), nextDouble(), etc. before nextLine(), always consume the leftover newline.