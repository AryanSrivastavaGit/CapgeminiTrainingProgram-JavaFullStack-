import java.util.Scanner;
class DoWhileLoop 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		char ch;
		do{
			System.out.println("Welcome");
			System.out.println("Do you want me to print again\nType y for 'yes' or n for 'no'");
			ch = sc.next().charAt(0);
		}while(ch=='y');
									
	}
}
