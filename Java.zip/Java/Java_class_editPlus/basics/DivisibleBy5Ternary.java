class DivisibleBy5Ternary 
{
	public static void main(String[] args) 
	{
		int n = 40
		String res;
		res = n%5==0: "Number is Divisible By 5":"Number is not Divisible By 5";
		System.out.println(res);
	}
}
