class OperandPlusOperator 
{
	public static void main(String[] args) 
	{
		System.out.println(10+20);
		System.out.println('A'+'B');
		System.out.println('A'+20);
		System.out.println(10+"Hello");
		System.out.println(10+20+"Hello");
		System.out.println("Hello"+10+20);
	}
}