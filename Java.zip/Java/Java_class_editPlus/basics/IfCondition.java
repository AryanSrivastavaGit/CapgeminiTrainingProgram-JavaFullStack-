class IfCondition
{
	public static void main(String[] args)
	{
		int age = 22;
		if(age>18){
			System.out.println("Welcome you are eleigible for voting.");
	}
	if(age>16){
		System.out.println("Thank you");
	}

}
}