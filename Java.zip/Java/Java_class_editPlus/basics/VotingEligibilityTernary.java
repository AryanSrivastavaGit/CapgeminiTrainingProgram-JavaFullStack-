class VotingEligibilityTernary 
{
	public static void main(String[] args) 
	{
		String name = "Aryan";
		int age = 22;
		String res;
		res = age>=18 ? "Eligible for voting.":"Not Eligible for voting.";
		System.out.println(res);
	}
}
