class PassOrFailTernary 
{
	public static void main(String[] args) 
	{
		int marks = 40
		String res;
		res = marks>40: "Pass":"Fail";
		System.out.println(res);
	}
}
