class PatternLoop 
{
	public static void main(String[] args) 
	{
		/*
		*
		*
		*
		* * * *
		*/
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(i==3 || j==0){
					System.out.print("*");
				}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		      *
		      *
		      *
		* * * * 
		*/
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(i==3 || j==3){
					System.out.print("*");
				}else{
					System.out.print(" ");
				}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		* * * *
		      *
		      *
		      *
		*/
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(i==0 || j==3){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		* * * *
		*
		*
		*
		*/
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(i==0 || j==0){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		*    *
		*    *
		*    *
		*    *
		*/
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(j==0 || j==3){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		* * * *
		
		
		* * * *
		*/
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(i==0 || i==3){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		* * * *
		*     *
		*     *
		* * * *
		*/
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(i==0 || i==3 || j==0 || j==3){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		* 
		  *
		    *
		      *
		*/
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(i==j){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		       * 
		     *
		   *
		 *
		*/
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if((i+j)==3){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		 * 
		 **
		 ***
		 ****
		*/
		for(int i=0; i<4; i++){
			for(int j=0; j<=i; j++){
				System.out.print("*");
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		    * 
		   **
		  ***
		 ****
		*/
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if((i+j)>=3){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*		  
		 ****
		  ***
		   **
		    *
		*/
		for(int i=4; i>0; i--){
			for(int j=0; j<4; j++){
				if(j<i){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*		  
		 ****
		  ***
		   **
		    *
		*/
		for(int i=0; i<4; i++){
			for(int j=0; j<4; j++){
				if(j>=i){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		    * 
		   ***
		  *****
		 *******
		*/
		int n = 4;
		for(int i=0; i<n; i++){
			for(int j=0; j<n*2-1; j++){
				if(j>=(n-1-i) && j<=(n-1+i)){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		 *******
		  *****
		   ***
		    *
		*/
		int n1 = 4;
		for(int i=0; i<n1; i++){
			for(int j=0; j<n1*2-1; j++){
				if(j>=i && j<(n1*2-1)-i){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		
		 *
		 **
		 ***
		 **
		 *
		 
		*/
		int n2 = 4;
		for(int i=0; i<n2*2-1; i++){
			for(int j=0; j<n2; j++){
				if(j<=i && j+i<=n2*2-2){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*
		
		   *
		  **
		 ***
		  **
		   *
		 
		*/		
		int n3 = 4;
		for(int i=0; i<n3*2-1; i++){
			for(int j=0; j<n3; j++){
				if(i+j>=n3-1 && i-j<=n3-1){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		
		/*
		
		   *
		  ***
		 *****
		  ***
		   *
		 
		*/
		int n4 = 5;
		for(int i=0; i<n4; i++){
			for(int j=0; j<n4; j++){
				if(i+j>=n4/2 && i-j<=n4/2){
					System.out.print("*");
				}else{
						System.out.print(" ");
					}
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		
		/*  
		  *   *
		  ** **
		  *****
		 
		*/
		
		/*  
		  *****
		  ** **
		  *   *
		 
		*/
		
		/*  
		  * * *
		  * * 
		  *   
		  * *
		  * * *
		 
		*/
		
		/*  
		  * * *
		    * * 
		      *   
		    * * 
		  * * *
		 
		*/
		
		/*  
		  *****
		  ** **
		  *   *
		  ** **
		  *****
		 
		*/
		
		/*  
		  *   *
		  ** **
		  *****
		  ** **
		  *   *
		 
		*/
	}
}

//Note:
//Rule - 1. Compare
//	   2. Add
//	   3.Subtract