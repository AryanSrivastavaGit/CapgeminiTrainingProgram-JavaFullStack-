class PositiveNegativeTernary 
{
	public static void main(String[] args) 
	{
		int n = 10;
		String res;
		res = n<0 ? "Negative":"Positive";
		System.out.println(res);
	}
}
