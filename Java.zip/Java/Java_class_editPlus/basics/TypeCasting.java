class TypeCasting 
{
	public static void main(String[] args) 
	{
		//widening
		int a = 10;
		double b = a; // implicit
		System.out.println(b);
		
		//narrowing
		double c = 20.23;
		int d = (int)c; // explicit
		System.out.println(d);
	}
}
