class RelationalOperator 
{
	public static void main(String[] args) 
	{
		boolean b1 = 10==10;
		System.out.println(b1);
		boolean b2 = 10!=10;
		System.out.println(b2);
	}
}
