import java.util.Scanner;
class SwitchConditionWithDynamicRead 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		char ch = sc.next().charAt(0);
		switch(ch){
			case 'a': System.out.println("Apple");
			break;
			case 'b': System.out.println("Ball");
			break;
			case 'c': System.out.println("Cat");
		}
	}
}
