class NoArgMethod 
{
	public static void area_circle(){
		float r = 3;
		float area = 3.14f*r*r;
		System.out.println(area);
	}
	
	public static void area_square(){
		float s = 3;
		float area = s*s;
		System.out.println(area);
	}
	
	public static void area_triangle(){
		float b = 3;
		float h = 4;
		float area = (1.0f/2.0f)*b*h;
		System.out.println(area);
	}
	public static void main(String[] args) 
	{
		area_circle();
		area_square();
		area_triangle();
	}
}