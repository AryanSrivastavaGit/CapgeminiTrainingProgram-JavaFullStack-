class PrimitiveDataType 
{
	public static void main(String[] args) 
	{
		byte b;
		b=10;
		System.out.println("byte: "+b);
		short s;
		s=1;
		System.out.println("short: "+s);
		int i;
		i=3;
		System.out.println("int: "+i);
		long l;
		l=123L;
		System.out.println("long: "+l);
		float f;
		f=1.2f;
		System.out.println("float: "+f);
		double d;
		d=1.234d;
		System.out.println("double: "+d);
		char c;
		c='a';
		System.out.println("char: "+c);
		boolean bn;
		bn=true;
		System.out.println("bool: "+bn);
		
	}
	}