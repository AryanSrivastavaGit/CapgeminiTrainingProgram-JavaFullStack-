class MultipleOf10Ternary 
{
	public static void main(String[] args) 
	{
		int n = 50;
		String res;
		res = n%10==0; "Number is Multiple of 10":"Number is not Multiple of 10";
		System.out.println(res);
	}
}
