class class1 
{
	public static void main(String[] args) 
	{
		System.out.print("Hii ");
		System.out.println("Hello");
		System.out.print("LPU ");
		System.out.print("Welcome ");
		System.out.print("to ");
		System.out.print("Java ");
		System.out.print("class");
	}
}
