class Methods 
{
	public static void print_msg(){
		System.out.println("Inside method");
	}
	public static void main(String[] args) 
	{
		System.out.println("Inside main");
		print_msg();
		System.out.println("Inside main");
	}
}
