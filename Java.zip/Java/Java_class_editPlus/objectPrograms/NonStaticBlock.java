class NonStaticBlock 
{
	NonStaticBlock(){
		System.out.println("constructor call");
	}
	{
		System.out.println("non-static block"); // only get call when object is created.
	}
	public static void main(String[] args) 
	{
		NonStaticBlock obj = new NonStaticBlock();
	}
}