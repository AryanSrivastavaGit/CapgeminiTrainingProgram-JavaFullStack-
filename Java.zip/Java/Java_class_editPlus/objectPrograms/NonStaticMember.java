class NonStaticMember 
{
	double s1;
	double s2;
	NonStaticMember(double s1, double s2){  // we can access static variable inside non-static member
		this.s1 = s1;
		this.s2 = s2;
	}
	void area(){
		System.out.println(s1*s2);	
	}
	public static void main(String[] args) 
	{
		NonStaticMember obj = new NonStaticMember(3,4);
		obj.area();
	}
}
