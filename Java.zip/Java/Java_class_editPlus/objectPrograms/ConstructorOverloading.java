class ConstructorOverloading 
{
	String pan;
	String aadhar;
	String voting;
	
	ConstructorOverloading(){
	}
	
	ConstructorOverloading(String pan){
		this.pan = pan;
	}
	
	ConstructorOverloading(String pan, String aadhar){
		this.pan = pan;
		this.aadhar = aadhar;
	}
	
	ConstructorOverloading(String pan, String Aadhar, String voting){
		this.pan = pan;
		this.aadhar = aadhar;
		this.voting = voting;
	}
	
	public static void main(String[] args) 
	{
		ConstructorOverloading obj1 = new ConstructorOverloading();
		ConstructorOverloading obj2 = new ConstructorOverloading("pan123");
		ConstructorOverloading obj3 = new ConstructorOverloading("pan123", "aadhar123");
		ConstructorOverloading obj4 = new ConstructorOverloading("pan123", "aadhar123", "voting123");
	}
}
