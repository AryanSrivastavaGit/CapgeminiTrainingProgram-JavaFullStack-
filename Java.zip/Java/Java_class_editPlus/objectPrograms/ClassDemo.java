public class ClassDemo 
{
	public static void main(String[] args) 
	{
		ClassDemo ObjDemoClass = new ClassDemo();
		System.out.println(ObjDemoClass);
		//ObjectReference ObjObjectReference = new ObjectReference();
		//System.out.println(ObjObjectReference);
		
	}
}
