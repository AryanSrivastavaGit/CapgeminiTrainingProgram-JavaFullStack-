class classObjWithThis 
{
	String title;
	int price;
	
	classObjWithThis(String title, int price){
		this.title = title;
		this.price = price;
	}
	
	public static void main(String[] args) 
	{
		classObjWithThis obj = new classObjWithThis("Java", 1000);
		System.out.println(obj.title);
		System.out.println(obj.price);
		
	}
}
