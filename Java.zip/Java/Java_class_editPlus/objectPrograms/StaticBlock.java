class StaticBlock 
{
	static{
		System.out.println("1st static block"); // get call when class is loaded
	}
	static{
		System.out.println("2st static block");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
