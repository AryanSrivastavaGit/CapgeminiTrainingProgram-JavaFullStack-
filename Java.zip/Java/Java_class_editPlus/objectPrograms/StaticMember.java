class StaticMember 
{
	static int a;//static variable also called class variable
	public static void m1(){
		System.out.println("Static-Method");	// we can't access non-static variable inside static member
	}
	static{
		System.out.println("static block");
	}
	public static void main(String[] args) 
	{
		m1();
		StaticMember.m1();// mandatory to use className to access static member in different class
		System.out.println(a);
		System.out.println(StaticMember.a);// mandatory to use className to access static member in different class
	}
}
