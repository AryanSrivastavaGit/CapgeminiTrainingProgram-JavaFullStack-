public class All1 
{
	All1(){System.out.println("All1 default constructor call");}
	public static void main(String[] args) 
	{

	}
}
