public class All2 
{
	int length;
	int breadth;
	int height;
	
	int non_static_var;
	static int static_var;
	
	All2(){System.out.println("All2 default constructor call");}
	
	All2(int length, int breadth){
		this.length = length;
		this.breadth = breadth;
	}
	All2(int length, int breadth, int height){
		this(length,breadth);
		this.height = height;
	}
	void area_square(){
		System.out.println(length*breadth);
	}
	
	public void non_static_method(){
		System.out.println(non_static_var);
		System.out.println(static_var);
	}
	public static void static_method(){
		System.out.println(static_var);
	}
	
	
	public static void main(String[] args) 
	{
		//All1 All1obj = new All1();
		
		
		All2 All2obj = new All2(1,2,3);
		
		All2obj.non_static_var = 10;
		
		static_var = 20;
		
		All2obj.non_static_method();
		
		static_method();
		
	}
}
