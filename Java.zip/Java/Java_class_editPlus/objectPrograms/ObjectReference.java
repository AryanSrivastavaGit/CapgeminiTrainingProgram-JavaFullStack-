public class ObjectReference 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		ObjectReference ObjObjectReference = new ObjectReference();
		System.out.println(ObjObjectReference);
		ClassDemo ObjDemoClass = new ClassDemo();
		System.out.println(ObjDemoClass);
	}
}