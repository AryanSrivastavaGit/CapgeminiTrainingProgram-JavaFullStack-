class ConstructorOverloading2 
{
	String pan;
	String aadhar;
	String voting;
	
	ConstructorOverloading2(){
	}
	
	ConstructorOverloading2(String pan){
		this();
		this.pan = pan;
	}
	
	ConstructorOverloading2(String pan, String aadhar){
		this(pan);
		this.aadhar = aadhar;
	}
	
	ConstructorOverloading2(String pan, String aadhar, String voting){
		this(pan,aadhar);
		this.voting = voting;
	}
	
	public static void main(String[] args) 
	{
		ConstructorOverloading2 obj1 = new ConstructorOverloading2();
		ConstructorOverloading2 obj2 = new ConstructorOverloading2("pan123");
		ConstructorOverloading2 obj3 = new ConstructorOverloading2("pan123", "aadhar123");
		ConstructorOverloading2 obj4 = new ConstructorOverloading2("pan123", "aadhar123", "voting123");
	}
}