class ExtraTime5
{
	public static void main(String[] args) 
	{
		int attendance  = 78;
		String challenged = "Not";
		String approved = "Not";
		int examd = 2;
		System.out.println(examd);
		String res;
		res = (attendance<60 && approved=="Yes") || challenged=="Yes" ? "eligible for extra time":"Not eligible for extra time";
		int eexamd = 1;
		examd = res=="eligible for extra time" ? examd+=eexamd : examd;
		System.out.println(res);
		System.out.println(examd);
	}
}
