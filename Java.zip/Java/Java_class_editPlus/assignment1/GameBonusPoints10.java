class GameBonusPoints10
{
	public static void main(String[] args) 
	{
		int score = 240;
		System.out.println(score);
		int level_time = 15;
		String cheats = "none";
		String res;
		res = score>100 && level_time<=20 && cheats=="none" ? "eligible for bonus":"not eligible for bonus";
		int bonus = 10;
		score = res=="eligible for bonus" ? score+=bonus:score;
		System.out.println(res);
		System.out.println(score);
	}
}
