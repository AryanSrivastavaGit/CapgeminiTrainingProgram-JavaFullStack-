class TrafficSystemCheck6 
{
	public static void main(String[] args) 
	{
		int speed = 78;
		String emergency_service_provider = "Not";
		String res;
		res = speed<65 && emergency_service_provider=="Not" ? "fine":"No fine";
		int penalty = 0;
		System.out.println(penalty);
		penalty = res=="fine" ? penalty+=1000 : 0;
		System.out.println(res);
		System.out.println(penalty);
	}
}
