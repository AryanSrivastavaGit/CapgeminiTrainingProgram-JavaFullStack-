class ElectrictyBoardCheck9 
{
	public static void main(String[] args) 
	{
		int bill = 0;
		System.out.println(bill);
		int units_consumed = 480;
		String customer = "commercial";
		String res;
		res = units_consumed>300 || customer=="commercial" ? "check":"not check";
		int bill_rate = 3;
		bill = res=="check" ? units_consumed*bill_rate:0;
		int tax = (bill*18)/100;
		bill+=tax;
		System.out.println(res);
		System.out.println(bill);
	}
}
