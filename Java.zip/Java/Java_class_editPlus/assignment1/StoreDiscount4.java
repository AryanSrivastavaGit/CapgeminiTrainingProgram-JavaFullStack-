class StoreDiscount4
{
	public static void main(String[] args) 
	{
		int purchase  = 3500;
		System.out.println(purchase);
		String member = "premium";
		String first_time = "Not";
		String res;
		res = (purchase>2000 && member=="premium") || first_time=="Not" ? "eligible for discount":"Not eligible for discount";
		int discount = 500;
		purchase-=discount;
		System.out.println(res);
		System.out.println(purchase);
	}
}
