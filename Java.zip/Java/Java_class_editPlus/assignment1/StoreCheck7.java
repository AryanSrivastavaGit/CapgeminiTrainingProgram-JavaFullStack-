class StoreCheck7 
{
	public static void main(String[] args) 
	{
		int stock_quantity = 8;
		System.out.println(stock_quantity);
		String item_marked = "fast-moving";
		String res;
		res = stock_quantity<10 && item_marked=="fast-moving" ? "reorder":"No reorder";
		int reordered_quantity = 100;
		stock_quantity = res=="reorder" ? stock_quantity+=reordered_quantity : stock_quantity;
		System.out.println(res);
		System.out.println(stock_quantity);
	}
}
