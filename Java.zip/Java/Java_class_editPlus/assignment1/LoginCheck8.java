class LoginCheck8 
{
	public static void main(String[] args) 
	{
		String username = "Aryan";
		int password = 123;
		String acc = "Not-locked";
		int login_attempt = 3;
		System.out.println(login_attempt);
		int login_attempted = 1;
		System.out.println(login_attempted);
		String res;
		res = username=="Aryan" && password==123 && acc == "Not-locked" && login_attempted<login_attempt? "login successfull":"login not successfull";
		System.out.println(res);
		login_attempt = res=="login not successfull" ? login_attempt+=2:login_attempt;
		//login_attempt = res=="login successfull" ? login_attempt:login_attempt+=2;
		System.out.println(login_attempt);
	}
}