class BankVerification2 
{
	public static void main(String[] args) 
	{
		int balance = 10000;
		System.out.println(balance);
		String res;
		res = balance>0 ? "active, allow withdrawal":"inactive, no allow withdrawal";
		System.out.println(res);
		int withdrawal = 1500;
		balance = res=="active, allow withdrawal" ? balance-=withdrawal:balance;
		System.out.println(balance);
	}
}
