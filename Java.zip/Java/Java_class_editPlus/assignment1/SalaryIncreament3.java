class SalaryIncreament3
{
	public static void main(String[] args) 
	{
		int salary = 150000;
		System.out.println(salary);
		float prating = 4.7f;
		int eyear = 7;
		String daction = "None";
		String res;
		res = (prating>4 || eyear>5) && daction=="None" ? "eligible":"Not eligible";
		int isalary = 50000;
		salary = res=="eligible" ? salary+=isalary:salary;
		System.out.println(res);
		System.out.println(salary);
	}
}
