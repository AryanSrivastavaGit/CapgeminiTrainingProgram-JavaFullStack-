class StudentPass1 
{
	public static void main(String[] args) 
	{
		int marks = 74;
		int attendance = 78;
		String res;
		res = marks>=40 && attendance>75 ? "Pass":"Fail";
		System.out.println(res);
		marks = res=="Pass" ? marks+=5:marks;
		System.out.println(marks);
	}
}
