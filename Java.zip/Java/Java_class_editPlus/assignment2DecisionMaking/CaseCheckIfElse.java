import java.util.Scanner;
class CaseCheckIfElse
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		char ch = sc.next().charAt(0);
		int asc = (int)ch;
		if((asc>=65) && (asc<=90)){
			System.out.println("UpperCase letter");
		}else if((asc>=97) && (asc<=122)){
			System.out.println("LowerCase letter");
		}else if(((asc>=32)&&(asc<=47)) || ((asc>=58)&&(asc<=64)) || ((asc>=91)&&(asc<=96)) || ((asc>=123)&&(asc<=126))){
			System.out.println("Special Character");
		}else{
			System.out.println("Number");
		}
	}
}
