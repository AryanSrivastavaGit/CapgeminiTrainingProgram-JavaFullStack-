class CheckTriangleIfElse 
{
	public static void main(String[] args) 
	{
		int s1 = 10;
		int s2 = 12;
		int s3 = 10;
		
		if((s1==s2) && (s1==s3)){
			System.out.println("Equilateral");
		}else if(((s1==s2)&&(s1!=s3)) || ((s1==s3)&&(s1!=s2)) || (s2==s3)&&(s2!=s1)){
			System.out.println("Isosceles");
		}else{
			System.out.println("Scalene");
		}
	}
}
