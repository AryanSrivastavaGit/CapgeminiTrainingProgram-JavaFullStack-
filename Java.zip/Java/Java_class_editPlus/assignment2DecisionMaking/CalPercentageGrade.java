class CalPercentageGrade 
{
	public static void main(String[] args) 
	{
		int phy = 80;
		int chem = 88;
		int math = 80;
		int pedu = 90;
		int eng = 85;
		int total = phy+chem+math+pedu+eng;
		float ftotal = total;
		System.out.println(total);
		float per = (ftotal/500)*100;
		System.out.println(per);
	}
}
