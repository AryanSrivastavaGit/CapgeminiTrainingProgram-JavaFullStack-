import java.util.Scanner;
class DaysInMonthSwitch 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		String month = sc.next();
		switch(month){
			case "jan": System.out.println(31);
			break;
			case "feb": System.out.println("29 or 28");
			break;
			case "mar": System.out.println(31);
			break;
			case "apr": System.out.println(30);
		}
	}
}
