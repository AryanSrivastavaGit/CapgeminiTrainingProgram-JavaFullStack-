class DivisibleBy5and11 
{
	public static void main(String[] args) 
	{
		int a = 10;
		if((a%5==0) && (a%11==0)){
			System.out.println("Divisible by both 5 & 11");
		}
	}
}
