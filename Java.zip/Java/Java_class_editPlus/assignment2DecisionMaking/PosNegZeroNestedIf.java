class PosNegZeroNestedIf 
{
	public static void main(String[] args) 
	{
		int a = 0;
		if(a<0){
			System.out.println("Negative");
		}else if(a==0){
			System.out.println("Zero");
		}else{
			System.out.println("Positive");
		}
	}
}
