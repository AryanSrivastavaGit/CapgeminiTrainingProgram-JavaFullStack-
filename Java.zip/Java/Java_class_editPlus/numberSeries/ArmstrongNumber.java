class  ArmstrongNumber
{
	public static void main(String[] args) 
	{
			int num = 153;
            int temp = num;
            int count = 0;

            // Count digits
            while (temp != 0) {
                count++;
                temp /= 10;
            }

            int sum = 0;
            temp = num;

            // Armstrong calculation
            while (temp != 0) {
                int digit = temp % 10;
                sum += Math.pow(digit, count);
                temp /= 10;
            }

            if (num == sum) {
                System.out.println(num + " is an Armstrong number");
            }
	}
}
