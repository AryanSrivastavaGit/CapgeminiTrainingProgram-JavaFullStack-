class Factorial6 
{
	public static void main(String[] args) 
	{
		int n = 6;
		int fact = 1;
		for(int i=1; i<n; i++){
			if(n%i==0){
				fact*=i;
			}
		}
		System.out.println(fact);
	}
}
