class NumberLength1
{
	public static void main(String[] args) 
	{
		int n = 123;
		int count = 0;
		while(n%10!=0){
			count++;
			n = n/10;
		}
		System.out.println(count);
	}
}
