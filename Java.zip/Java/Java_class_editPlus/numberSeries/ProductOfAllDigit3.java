class ProductOfAllDigit3 
{
	public static void main(String[] args) 
	{
		int n = 123;
		int prod;
		if(n==0){
			prod=0;
		}else{
			prod = 1;
			while(n%10!=0){
				int digit = n%10;
				prod*=digit;
				n=n/10;
			}
		}
		System.out.println(prod);
	}
}
