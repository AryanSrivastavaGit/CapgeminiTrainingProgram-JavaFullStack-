class PrimeOrNot5 
{
	public static void main(String[] args) 
	{
		int n = 0;
		if(n==0 || n==1){
			System.out.println("Neither prime nor composite");
			return;
		}
		int count = 0;
		for(int i=1; i<n; i++){
			if(n%i==0){
				count++;
			}
		}
		if(count<2){
			System.out.println("Prime Number");
		}else{
			System.out.println("Not prime number");
		}
	}
}
