class  SpyNumber4
{
	public static void main(String[] args) 
	{
		int n = 123;
		
		int sum = 0;
		while(n%10!=0){
			int digit = n%10;
			sum+=digit;
			n=n/10;
		}
		
		int prod;
		if(n==0){
			prod=0;
		}else{
			prod = 1;
			while(n%10!=0){
				int digit = n%10;
				prod*=digit;
				n=n/10;
			}
		}
		
		if(sum==prod){
			System.out.println("Spy Number");
		}else{
			System.out.println("Not Spy Number");
		}
	}
}
