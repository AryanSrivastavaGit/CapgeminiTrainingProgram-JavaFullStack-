class SumOfAllDigit2 
{
	public static void main(String[] args) 
	{
		int n = 123;
		int sum = 0;
		while(n%10!=0){
			int digit = n%10;
			sum+=digit;
			n=n/10;
		}
		System.out.println(sum);
	}
}
