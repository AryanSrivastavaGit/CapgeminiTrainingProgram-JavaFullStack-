package arrayList;

import java.util.ArrayList;

public class ArrayListMethods {

	public static void main(String[] args) {
		
		ArrayList al1 = new ArrayList();
		
		al1.add(1);
		al1.add(2);
		al1.add(3);
		al1.add(new AddingStudentClassToArrayList("Aryan", 1));
		
		System.out.println(al1);
		
		System.out.println(al1.contains(2));
		System.out.println(al1.contains(4));
		
		System.out.println(al1.indexOf(2));
		
		System.out.println(al1.contains(new AddingStudentClassToArrayList("Aryan", 1)));

	}

}
