package arrayList;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class AccessingElements {

	public static void main(String[] args) {
		ArrayList al = new ArrayList();
		
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		
		System.out.println(al.get(3));
		
		System.out.println("==================================");
		
		for(int i=0; i<al.size(); i++) {
			System.out.println(al.get(i));
		}
		
		System.out.println("==================================");
		
		for(Object o : al){
			System.out.println(o + " ");
		}
		
		System.out.println("==================================");
		
		Iterator i = al.iterator();
		
		System.out.println(i.next());
		System.out.println(i.next());
		System.out.println(i.next());
		System.out.println(i.next());
//		System.out.println(i.next()); // NoSuchElementException
		
		while(i.hasNext()) {
			System.out.println(i.next());
		}
		
		System.out.println("==================================");
		
		ListIterator li = al.listIterator();
		
		System.out.println(li.next());
		System.out.println(li.next());
		System.out.println(li.next());
		System.out.println(li.next());
//		System.out.println(li.next()); // NoSuchElementException
		
		while(li.hasNext()) {
			System.out.println(li.next());
		}
		
		while(li.hasPrevious()) {
			System.out.println(li.previous());
		}
		

	}

}
