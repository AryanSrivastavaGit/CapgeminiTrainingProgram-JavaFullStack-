package arrayList;

import java.util.ArrayList;

public class AddingData {

	public static void main(String[] args) {
		ArrayList al1 = new ArrayList(); //heterogeneous
		
		al1.add(1);
		al1.add(2);
		al1.add(3);
		al1.add(1);
		al1.add("aryan");
		al1.add(true);
		al1.add(null);
		al1.add(1.2);
		
		ArrayList al2 = new ArrayList();
		al2.add(1);
		al2.add(2);
		al2.add(3);
		
		al1.add(al2);
		al1.add(3, 4);
		
		al1.addAll(al2); //add values individually
		al1.addAll(0, al2);
		
		System.out.println(al1);
		
		System.out.println(al1.get(4));
		
		
		al1.add(new AddingStudentClassToArrayList("Aryan",1));
		al1.add(new AddingStudentClassToArrayList("Abishek",2));
		al1.add(new AddingStudentClassToArrayList("Priyanshu",3));
		
		System.out.println(al1);
		
		System.out.println(al1.get(19));
		
		for(Object o : al1){
			System.out.print(o + " ");
		}
		
		AddingStudentClassToArrayList o = (AddingStudentClassToArrayList)al1.get(19);
		System.out.println(o.getName());
	}

}
