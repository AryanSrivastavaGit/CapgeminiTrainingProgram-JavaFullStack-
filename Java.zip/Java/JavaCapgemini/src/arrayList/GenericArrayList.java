package arrayList;

import java.util.ArrayList;
import java.util.Iterator;

public class GenericArrayList {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<Integer>();
		
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		
		int sum1=0;
		for(int i=0; i<al.size(); i++) {
			sum1+=al.get(i);
		}
		
//		int sum2=0;
//		for(Object o : al) {
//			sum2+=o;
//		}
		
//		int sum3=0;
//		for(Iterator i : al) {
//			sum3+=i;
//		}

	
	}

}
