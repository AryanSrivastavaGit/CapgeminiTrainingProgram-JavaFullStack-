package arrayList;

import java.util.ArrayList;
import java.util.Collections;

public class SortElement {

	public static void main(String[] args) {
//		ArrayList<Integer> al1 = new ArrayList<Integer>();
//		al1.add(10);
//		al1.add(50);
//		al1.add(30);
//		al1.add(40);
//		al1.add(20);
//		System.out.println(al1);
//		
//		Collections.sort(al1);
//		System.out.println(al1);
		
		
		ArrayList books = new ArrayList();
		books.add(new ClassSorting(100));
		books.add(new ClassSorting(500));
		books.add(new ClassSorting(100));
		books.add(new ClassSorting(300));
		books.add(new ClassSorting(150));
		
		System.out.println(books);
		
//		Collections.sort(books);  // using compareTo(obj) override
//		System.out.println(books);
		
		Collections.sort(books);  // using compare(obj1, obj2) override
//		Collections.sort(books, Collections.reverseOrder()); // reverse sorting
		System.out.println(books);
		

	}

}
