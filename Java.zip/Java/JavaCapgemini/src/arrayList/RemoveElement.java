package arrayList;

import java.util.ArrayList;

public class RemoveElement {

	public static void main(String[] args) {
		ArrayList<Integer> al1 = new ArrayList<Integer>();
		al1.add(10);
		al1.add(20);
		al1.add(30);
		al1.add(40);
		System.out.println(al1);
		
		ArrayList<Integer> al2 = new ArrayList<Integer>();
		al2.add(20);
		al2.add(30);
		
		al1.remove(0);
		System.out.println(al1);
		
		al1.removeAll(al2);
		System.out.println(al1);
		
		al1.add(10);
		al1.add(20);
		al1.add(30);
		
		al1.retainAll(al2);
		System.out.println(al1);
		
		al1.clear();
		System.out.println(al1);
		
		
	}

}
