package arrayList;

public class ClassSorting implements Comparable<ClassSorting>{

	int price;
	
	ClassSorting(){}
	
	ClassSorting(int price){
		this.price=price;
	}
	
	public String toString() {
		return "Book [Price=" + price +"]";
	}
	
	public int compareTo(ClassSorting o) {
		return this.price-o.price;
	}

}
