package arrayList;

public class AddingStudentClassToArrayList {
	
	private String name;
	private int id;
	
	AddingStudentClassToArrayList(){}
	
	AddingStudentClassToArrayList(String name, int id){
		this.name=name;
		this.id=id;
	}
	
	public String toString() {
		return name + " " + id;
	}
	
//	public boolean equals(Object o) {
//		
//	}
	
	public String getName() {
		return name;
	}
}
