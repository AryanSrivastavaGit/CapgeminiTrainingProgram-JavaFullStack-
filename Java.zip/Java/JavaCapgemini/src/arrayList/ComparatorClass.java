package arrayList;

import java.util.Comparator;

public class ComparatorClass implements Comparator<ClassSorting>{
	
	public int compare(ClassSorting o1, ClassSorting o2) {
		return o1.price - o2.price;
	}
}
