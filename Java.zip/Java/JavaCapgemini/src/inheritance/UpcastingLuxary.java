package inheritance;

public class UpcastingLuxary extends UpcastingCab{
	
	UpcastingLuxary(){}

	UpcastingLuxary(String name, String phoneNumber) {
		super(name, phoneNumber);
	}

}
