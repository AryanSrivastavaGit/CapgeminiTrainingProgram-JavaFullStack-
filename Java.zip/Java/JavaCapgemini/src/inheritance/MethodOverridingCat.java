package inheritance;

public class MethodOverridingCat extends MethodOverridingAnimal{
	public void sound() {
		System.out.println("Meow");
	}
}
