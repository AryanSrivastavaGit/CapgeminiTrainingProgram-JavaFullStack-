package inheritance;

public class SuperWithConstructorMainApp extends SuperWithConstructor{
		int id;
		
		SuperWithConstructorMainApp(){}
		SuperWithConstructorMainApp(String name, int id){
			super(name);
			this.id = id;
		}
		
		void display() {
			System.out.println(name);
			System.out.println(id);
		}
		
	public static void main(String[] args) {
		SuperWithConstructorMainApp obj = new SuperWithConstructorMainApp("Aryan", 12215619);
		obj.display();

	}

}
