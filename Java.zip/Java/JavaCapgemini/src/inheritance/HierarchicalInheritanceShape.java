package inheritance;

public class HierarchicalInheritanceShape {
	double area;
}
