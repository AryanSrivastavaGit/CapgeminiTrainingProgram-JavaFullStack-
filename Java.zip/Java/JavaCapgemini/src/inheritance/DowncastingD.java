package inheritance;

public class DowncastingD extends DowncastingC{
	void show() {
		System.out.println("D");
	}
}
