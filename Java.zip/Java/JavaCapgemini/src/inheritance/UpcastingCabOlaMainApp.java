package inheritance;

import java.util.Scanner;

public class UpcastingCabOlaMainApp {

	public static void main(String[] args) {
		System.out.println("Ola");
		System.out.println("Press: 1 for Mini");
		System.out.println("Press: 2 for Sedan");
		System.out.println("Press: 3 for Luxary");
		System.out.println("Press: ");
		
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		sc.nextLine();
		
		String name = sc.nextLine();
		String phoneNumber = sc.nextLine();
		
		
		
		UpcastingCab c = null;
		switch(choice){
		case 1: {
			c = new UpcastingMini(name,phoneNumber);
		}
		break;
		
		case 2: {
			c = new UpcastingSedan(name,phoneNumber);
		}
		break;
		
		case 3: {
			c = new UpcastingLuxary(name,phoneNumber);
		}
		break;
		
		default: {
			System.out.println("Invalid Input");
		}
		}
		
		System.out.println(c);
		if(c!=null) {
			System.out.println(c.name);
			System.out.println(c.phoneNumber);			
		}
		
		sc.close();

	}

}
