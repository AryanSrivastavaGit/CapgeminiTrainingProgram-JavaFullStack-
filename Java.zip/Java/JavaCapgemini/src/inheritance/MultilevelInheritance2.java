package inheritance;

public class MultilevelInheritance2 extends MultilevelInheritance1{ // Student
	void student() {
		System.out.println("Displaying Student");
	}
}
