package inheritance;

public class HierarchicalInheritanceMainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HierarchicalInheritanceTriangle objTriangle = new HierarchicalInheritanceTriangle();
		objTriangle.area(3, 5);
		
		HierarchicalInheritanceCircle objCircle = new HierarchicalInheritanceCircle();
		objCircle.area(5);
		
		HierarchicalInheritanceSquare objSquare = new HierarchicalInheritanceSquare();
		objSquare.area(5);
		
		System.out.println(objTriangle.area);
		System.out.println(objCircle.area);
		System.out.println(objSquare.area);
	}
}
