package inheritance;

public class MultilevelInheritance3 extends MultilevelInheritance2{ // Engineer
	void engineer() {
		System.out.println("Displaying Engineer");
	}
}
