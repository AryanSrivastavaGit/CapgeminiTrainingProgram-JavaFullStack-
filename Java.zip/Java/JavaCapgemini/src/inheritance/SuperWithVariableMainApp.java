package inheritance;

public class SuperWithVariableMainApp extends SuperWithVariable{
	String name = "Ankesh";
	
	void display() {
		System.out.println("Father name: " + super.name);
		System.out.println("Child name: " + this.name);
	}

	public static void main(String[] args) {
		SuperWithVariableMainApp obj = new SuperWithVariableMainApp();
		obj.display();

	}

}
