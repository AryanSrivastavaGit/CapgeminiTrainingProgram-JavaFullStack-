package inheritance;

public class MultilevelInheritanceMainApp {

	public static void main(String[] args) {
		MultilevelInheritance3 obj = new MultilevelInheritance3();
		obj.person();
		obj.student();
		obj.engineer();

	}

}
