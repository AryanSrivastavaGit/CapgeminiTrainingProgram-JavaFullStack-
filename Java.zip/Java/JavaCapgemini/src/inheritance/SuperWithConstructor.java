package inheritance;

public class SuperWithConstructor {
	String name;
	
	SuperWithConstructor(){}
	SuperWithConstructor(String name){
		this.name = name;
	}
}
