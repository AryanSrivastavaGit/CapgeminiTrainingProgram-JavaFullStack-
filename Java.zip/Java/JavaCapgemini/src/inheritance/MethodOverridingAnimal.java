package inheritance;

public class MethodOverridingAnimal {
	public void walk() {
		System.out.println("This animal walks on 4 legs.");
	}
	
	public void sound() {
		System.out.println("All animal have sound");
	}
	
}
