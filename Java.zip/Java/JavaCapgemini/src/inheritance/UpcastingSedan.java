package inheritance;

public class UpcastingSedan extends UpcastingCab{
	
	UpcastingSedan(){}

	UpcastingSedan(String name, String phoneNumber) {
		super(name, phoneNumber);
	}

}
