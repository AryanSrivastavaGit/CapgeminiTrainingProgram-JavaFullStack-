package inheritance;

public class UpcastingMini extends UpcastingCab{
	
	UpcastingMini(){}

	UpcastingMini(String name, String phoneNumber) {
		super(name, phoneNumber);
	}

}
