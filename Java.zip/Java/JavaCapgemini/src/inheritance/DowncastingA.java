package inheritance;

public class DowncastingA {
	void show() {
		System.out.println("A");
	}
	
	void showC() {
		System.out.println("AC");
	}
}
