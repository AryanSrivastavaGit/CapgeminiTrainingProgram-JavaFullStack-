package inheritance;

public class MethodOverridingDog extends MethodOverridingAnimal{
	public void sound() {
		System.out.println("Bark");
	}
}
