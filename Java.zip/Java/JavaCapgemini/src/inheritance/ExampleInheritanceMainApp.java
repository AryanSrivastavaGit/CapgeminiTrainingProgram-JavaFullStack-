package inheritance;

public class ExampleInheritanceMainApp extends ExampleInheritance{
	
	void display() {
		System.out.println("Child class.");
	}

	public static void main(String[] args) {
		ExampleInheritanceMainApp obj = new ExampleInheritanceMainApp();
		System.out.println(a);
		System.out.println(obj.b);
		display1();
		obj.display2();

	}

}
