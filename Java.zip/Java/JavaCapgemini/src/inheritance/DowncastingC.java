package inheritance;

public class DowncastingC extends DowncastingA{
	void show() {
		System.out.println("C");
	}
	void showC() {
		System.out.println("C");
	}
}
