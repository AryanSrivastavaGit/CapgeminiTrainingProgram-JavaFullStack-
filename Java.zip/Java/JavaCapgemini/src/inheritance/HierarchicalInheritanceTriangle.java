package inheritance;

public class HierarchicalInheritanceTriangle extends HierarchicalInheritanceShape{
	int base;
	int height;
	
	void area(int base, int height) {
		this.base = base;
		this.height = height;
		
		super.area = (1.0/2.0)*this.base*this.height;
	}
}
