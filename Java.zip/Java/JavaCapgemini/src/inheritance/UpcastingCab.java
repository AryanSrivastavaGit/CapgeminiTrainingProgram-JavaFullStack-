package inheritance;

public class UpcastingCab {
	String name;
	String phoneNumber;
	
	UpcastingCab(){}
	
	UpcastingCab(String name, String phoneNumber){
		this.name = name;
		this.phoneNumber = phoneNumber;
	}
}
