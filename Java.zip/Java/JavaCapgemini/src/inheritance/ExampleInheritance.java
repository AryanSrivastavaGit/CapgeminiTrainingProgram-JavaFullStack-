package inheritance;

public class ExampleInheritance {
	
	static int a = 10;
	int b = 20;
	
	static void display1() {
		System.out.println("Parent class static method");
	}
	
	void display2() {
		System.out.println("Parent class non-static method");
	}
}
