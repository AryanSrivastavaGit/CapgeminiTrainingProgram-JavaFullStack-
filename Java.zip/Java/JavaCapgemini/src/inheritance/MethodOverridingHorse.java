package inheritance;

public class MethodOverridingHorse extends MethodOverridingAnimal{
//	public void sound() {
//		System.out.println("neigh");
//	}
}
