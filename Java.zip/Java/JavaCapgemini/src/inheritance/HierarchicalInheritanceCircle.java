package inheritance;

public class HierarchicalInheritanceCircle extends HierarchicalInheritanceShape{
	double radius;
	
	void area(double radius) {
		this.radius = radius;
		
		super.area = 3.14*this.radius*this.radius;
	}
}
