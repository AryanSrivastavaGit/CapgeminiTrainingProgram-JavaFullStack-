package inheritance;

public class SuperWithVariable {
	String name = "Vividh";
}
