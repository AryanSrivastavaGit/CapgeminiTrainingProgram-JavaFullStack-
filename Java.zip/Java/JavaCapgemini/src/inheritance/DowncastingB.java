package inheritance;

public class DowncastingB extends DowncastingA{
	void show() {
		System.out.println("B");
	}
}
