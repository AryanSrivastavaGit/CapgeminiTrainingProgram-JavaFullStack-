package inheritance;

public class DowncastingMainApp {

	public static void main(String[] args) {
		//Upcasting
		DowncastingA objA = new DowncastingD();
		objA.show();
		objA.showC();
		
		//Downcasting
		DowncastingC objC = (DowncastingC)objA;
		objC.show();
		
		System.out.println(objA instanceof DowncastingA);
		System.out.println(objA instanceof DowncastingC);
		System.out.println(objA instanceof DowncastingD);
		System.out.println(objA instanceof DowncastingB);
		
//		DowncastingB B = (DowncastingB)objA;  //java.lang.ClassCastException
		
		if(objA instanceof DowncastingB) {  //java.lang.ClassCastException solution
			DowncastingB objB = (DowncastingB)objA; 
		}

	}

}