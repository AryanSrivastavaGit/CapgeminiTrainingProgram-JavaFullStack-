package inheritance;

public class MultilevelInheritance1 { // Person
	void person() {
		System.out.println("Displaying Person");
	}
}
