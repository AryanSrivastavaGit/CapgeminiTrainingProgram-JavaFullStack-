package inheritance;

public class MethodOverridingAnimalMainApp {

	public static void main(String[] args) {
		MethodOverridingAnimal obj = new MethodOverridingDog(); 
		obj.walk();
		obj.sound();
		
		obj = new MethodOverridingHorse(); 
		obj.walk();
		obj.sound();
	}

}
