package inheritance;

public class HierarchicalInheritanceSquare extends HierarchicalInheritanceShape{
	int side;
	
	void area(int side) {
		this.side = side;
		
		super.area = this.side*this.side;
	}
}
