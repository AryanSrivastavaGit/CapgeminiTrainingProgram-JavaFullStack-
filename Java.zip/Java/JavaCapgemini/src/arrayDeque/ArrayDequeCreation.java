package arrayDeque;

import java.util.ArrayDeque;

public class ArrayDequeCreation {

	public static void main(String[] args) {
		ArrayDeque ad = new ArrayDeque();
		
		ad.offer(10);
		ad.offer(30);
		ad.offer(20);
		ad.offer(10);
		ad.offer("Hello");
//		ad.offer(null); //java.lang.NullPointerException because here null means queue is ended
		
		System.out.println(ad);
		
		ad.offerFirst(5);
		
		System.out.println(ad);
		
		ad.offerLast(50);
		
		System.out.println(ad);
		
		ad.poll();
		
		System.out.println(ad);
		
		ad.pollFirst();
		
		System.out.println(ad);
		
		ad.pollLast();
		
		System.out.println(ad);
		
		

	}

}
