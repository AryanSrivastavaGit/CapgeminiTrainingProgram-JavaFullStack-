package playingWithObjects;

public class ObjectReferenceTOMethodMainApp {
	
	public static void printRef(ObjectReferenceTOMethod o) {
		System.out.println(o);
	}
	public static void printRef(ObjectReferenceTOMethod2 o) {
		System.out.println(o);
	}
	
	public static void main(String[] args) {
		ObjectReferenceTOMethod obj1 = new ObjectReferenceTOMethod();
		printRef(obj1);
		ObjectReferenceTOMethod2 obj2 = new ObjectReferenceTOMethod2();
		printRef(obj2);
	}

}
