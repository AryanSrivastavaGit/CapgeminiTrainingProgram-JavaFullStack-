package playingWithObjects;

public class ObjectReferenceCopyMainApp {

	public static void main(String[] args) {
		ObjectReferenceCopy obj1 = new ObjectReferenceCopy("dog");
		System.out.println(obj1.name);
		ObjectReferenceCopy obj2 = obj1;
		obj2.name = "cat";
		System.out.println(obj2.name);
		System.out.println(obj1.name);

	}

}
