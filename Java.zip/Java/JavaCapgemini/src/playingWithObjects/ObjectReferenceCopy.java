package playingWithObjects;

public class ObjectReferenceCopy {
	
	String name;
	
	public ObjectReferenceCopy(String name) {
		this.name = name;
	}
}
