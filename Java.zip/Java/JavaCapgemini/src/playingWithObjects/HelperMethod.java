package playingWithObjects;

public class HelperMethod {
	double length;
	
	HelperMethod(){}
	
	HelperMethod(double length){
		this.length = length;
	}
	
	public static HelperMethod createHelperMethod() {  // helper method/ factory method
		return new HelperMethod();
	}
	
	public static HelperMethod createHelperMethod(double length) {
		return new HelperMethod(length);
	}
	
}
