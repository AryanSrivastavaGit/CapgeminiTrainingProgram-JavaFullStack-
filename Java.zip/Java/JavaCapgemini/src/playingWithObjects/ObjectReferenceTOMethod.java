package playingWithObjects;

public class ObjectReferenceTOMethod {
	
}

class ObjectReferenceTOMethod2 {
	
}
