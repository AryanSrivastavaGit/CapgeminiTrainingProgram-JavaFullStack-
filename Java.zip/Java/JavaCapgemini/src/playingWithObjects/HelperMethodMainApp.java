package playingWithObjects;

public class HelperMethodMainApp {

	public static void main(String[] args) {
		HelperMethod obj = HelperMethod.createHelperMethod();
		System.out.println(obj);
		
		HelperMethod obj2 = HelperMethod.createHelperMethod(5);
		System.out.println(obj2);

	}
}
