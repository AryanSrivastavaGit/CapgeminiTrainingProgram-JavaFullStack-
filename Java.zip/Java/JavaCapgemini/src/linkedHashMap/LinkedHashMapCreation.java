package linkedHashMap;

import java.util.LinkedHashMap;

public class LinkedHashMapCreation {

	public static void main(String[] args) {
		LinkedHashMap lhm = new LinkedHashMap();
		
		lhm.put(1, "Aryan");
		lhm.put(1, "Abishek");
		lhm.put(1, "Priyanshu");
		lhm.putIfAbsent(1, "Divyanshu");
		lhm.put(99, "Aryan");
		lhm.put(86, "Abishek");
		lhm.put(4, "Priyanshu");
		lhm.put(45, "Divyanshu");
		lhm.put(6, null);
		
		System.out.println(lhm);
		System.out.println(lhm.entrySet());
		System.out.println(lhm.keySet());
		System.out.println(lhm.values());
		
		for(Object o : lhm.entrySet()) {
			System.out.println(o);
		}
		
		for(Object o : lhm.keySet()) {
			System.out.println(o);
		}
		
		for(Object o : lhm.values()) {
			System.out.println(o);
		}

	}

}
