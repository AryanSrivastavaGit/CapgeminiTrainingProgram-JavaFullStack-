package wrapperClasses;

public class Parsing {

	public static void main(String[] args) {
		
		//parsing int string
		String s1 = "123";
		int a = Integer.parseInt(s1);
		System.out.println(a);
		
		//parsing byte string
		byte b = Byte.parseByte(s1);
		System.out.println(b);
		
		String s2 = "TrUe";  //only true for "true" else false, not caseSensitive
		boolean tf = Boolean.parseBoolean(s2);
		System.out.println(tf);

	}

}
