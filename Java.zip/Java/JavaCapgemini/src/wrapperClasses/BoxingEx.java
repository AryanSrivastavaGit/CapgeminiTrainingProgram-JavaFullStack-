package wrapperClasses;

public class BoxingEx {

	public static void main(String[] args) {
		// Boxing
		int a = 10;
		Integer i1 = new Integer(a);
		System.out.println(i1);
		
		Integer i2 = Integer.valueOf(a);
		System.out.println(i2);
		
		//AutoBoxing
		Integer i3 = a;
		System.out.println(i3);

	}

}
