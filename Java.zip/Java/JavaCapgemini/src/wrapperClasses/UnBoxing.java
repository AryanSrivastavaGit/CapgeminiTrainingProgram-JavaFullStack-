package wrapperClasses;

public class UnBoxing {

	public static void main(String[] args) {
		
		//Boxing
		int a = 10;
		Integer i = Integer.valueOf(a);
		
		//UnBoxing
		int b = i.intValue();
		System.out.println(b);
		
		//AutoBoxing
		Integer i2 = a;
		
		//AutoUnBoxing
		int c = i2;
		System.out.println(c);

	}

}
