package thread;

//class A extends Thread{
	class A implements Runnable{ // instead of extending class, implements runnable, which is going to allow multiple inheritance also. Thread implements Runnable 
	
	public void run() { // start() executes run() because of tread
		
		for(int i=0; i<100; i++)
		System.out.println("Hi");
		
		try {
			Thread.sleep(10);  // makes program execution to wait
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}

//class B extends Thread{
	class B implements Runnable{
	
	public void run() {
		
		for(int i=0; i<100; i++)
		System.out.println("Hello");
		
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
	

class Counter{
	int count;
//	public void increament() {
	public synchronized void increament() { // synchronized ensures that only one thread at a time can execute a method or block on the same object, preventing race conditions.
		count++;
	}
}

public class ThreadEx {

	public static void main(String[] args) {
		
//		A obj1 = new A();
//		B obj2 = new B();
		
//		System.out.println(obj1.getPriority()); // part of Thread class
//		obj2.setPriority(10); //part of Thread class
//		obj2.setPriority(Thread.MAX_PRIORITY);  // priority range is from 1 - 10 (min-max) by default normal priority is 5. //part of Thread class
		
//		obj1.start(); //part of Thread class
//		try {
//			Thread.sleep(2);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		obj2.start();
		
		
		
		
//		Runnable a = new A();
//		Runnable b = new B();
//		
//		Thread t1 = new Thread(a); //Tread have multiple overloaded constructor, one of which is Thread(Runnable task).
//		Thread t2 = new Thread(b);
//		
//		t1.start();
//		t2.start();
		
		
		
		
//		Runnable c = new A() {  // anonymous class
//			public void run() {
//				for(int i=0; i<5; i++)
//					System.out.println("Hi");
//			}
//		};
//		Thread t3 = new Thread(c);
//		t3.start();
//		
//		Runnable d = () -> {  // lambda expression also possible, because runnable is function interface
//				for(int i=0; i<5; i++)
//					System.out.println("Hello");
//		};
//		Thread t4 = new Thread(d);
//		t4.start();
		
		
		
		
		// thread-safe technique
		Counter c = new Counter();
		Runnable r1 = () -> {
			for(int i=0; i<1000; i++)
			c.increament();
		};
		Runnable r2 = () -> {
			for(int i=0; i<1000; i++)
			c.increament();
		};
		
		Thread t5 = new Thread(r1);
		Thread t6 = new Thread(r2);
		
		t5.start();
		t6.start();
		
		try {
			t5.join(); // it holds the main to execute further, Until the Thread executes completely
			t6.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println(c.count);
		
	}

}


//								         -----<------------notify()--------<---
//										 |									 |		
//										 |				 -wait()/sleep()-> Waiting
//										 |				|
// Thread states =>   New -start()-> Runnable -run()-> Running
//										 |				|
//										 |------>------stop()-> Dead
