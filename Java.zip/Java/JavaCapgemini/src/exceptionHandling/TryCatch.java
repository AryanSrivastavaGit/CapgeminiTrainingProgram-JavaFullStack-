package exceptionHandling;

import java.util.Scanner;

public class TryCatch {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Num1: ");
		int n1 = sc.nextInt();
		System.out.println("Num2: ");
		int n2 = sc.nextInt();
		
		try {
			System.out.println(n1/n2);			
		}catch(Exception e) {
			System.out.println(e);
		}
		
		
		try {
			System.out.println(n1/n2);		
			
			String s = null;
			System.out.println(s.toUpperCase());
			
		}catch(ArithmeticException e) {
			System.out.println(e);
		}catch(NullPointerException e) {
			System.out.println(e);
		}catch(Exception e) {
			System.out.println(e);
		}
		
		
		try {
			System.out.println(n1/n2);		
			
			String s = null;
			System.out.println(s.toUpperCase());
			
		}catch(ArithmeticException e) {
			e.printStackTrace(); // provide details about exception
			System.out.println("Catch: AE");
		}catch(NullPointerException e) {
			e.printStackTrace();
			System.out.println("Catch: NPE");
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
		
		
		try {
			System.out.println(n1/n2);		
			
			String s = null;
			System.out.println(s.toUpperCase());
			
//		}catch(ArithmeticException | NullPointerException | Exception e) { // can not take parent exception class and child exception class at same time
		}catch(ArithmeticException | NullPointerException e) {
			e.printStackTrace();
			System.out.println(e);
		}
		
		
		try {

			System.out.println(n1/n2);		
			
			String s = null;
			System.out.println(s.toUpperCase());
			
		}catch(ArithmeticException | NullPointerException e) {
			e.printStackTrace();
			System.out.println(e);
		}
		
		finally {
			System.out.println("finally block, use to close open methods");
		}
		
		System.out.println("main block");
	}

}
