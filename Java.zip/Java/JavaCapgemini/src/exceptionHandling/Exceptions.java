package exceptionHandling;

import java.util.Scanner;

public class Exceptions {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		//ArithmaticException
		System.out.println("Num1: ");
		int n1 = sc.nextInt();
		System.out.println("Num2: ");
		int n2 = sc.nextInt();
		System.out.println(n1/n2); // java.lang.ArithmeticException if n2==0
		
		//NullPointerException
		String str = null;
		System.out.println(str.toUpperCase()); // java.lang.NullPointerException

	}

}
