package exceptionHandling;

import java.util.Scanner;

public class Throw {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Num1: ");
		int n1 = sc.nextInt();
		System.out.println("Num2: ");
		int n2 = sc.nextInt();
		
		if(n2==0) {
//			throw new ArithmeticException();
			throw new ArithmeticException("AE");
		}else {
			System.out.println(n1/n2);
		}
		
		
		//Custom Exception Handling
		if(n2==0) {
//			throw new CustomThrowException();
			throw new CustomThrowException("By Zero");
		}else {
			System.out.println(n1/n2);
		}
		

	}

}
