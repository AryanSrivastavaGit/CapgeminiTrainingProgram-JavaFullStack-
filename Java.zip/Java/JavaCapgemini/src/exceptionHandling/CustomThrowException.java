package exceptionHandling;


public class CustomThrowException extends RuntimeException{
	
	String message;
	
	CustomThrowException(){}
	
	CustomThrowException(String message){
		this.message=message;
	}
	
	public String getMessage() {
		return message;
	}

}
