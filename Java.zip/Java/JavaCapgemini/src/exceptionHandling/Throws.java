package exceptionHandling;

import java.io.IOException;

public class Throws {
	
//	static void m1() throws ArithmeticException, NullPointerException, IOException{
//	static void m1() throws ArithmeticException, NullPointerException{
	static void m1() throws ArithmeticException{
		int a = 1;
		int b = 0;
		System.out.println(a/b);
	}
	
	static void m2() {
//		m1();
		
		try {
			m1();
		}catch(ArithmeticException e) {
			System.out.println(e);
		}
	}

	public static void main(String[] args) {
		m2();

	}

}
