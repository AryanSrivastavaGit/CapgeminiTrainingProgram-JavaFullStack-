package exceptionHandling;

import java.util.Scanner;

public class CustomAgeException extends RuntimeException{
	
	String message;
	
	CustomAgeException(){}
	
	CustomAgeException(String message){
		this.message=message;
//		super(message);
	}
	
	public String getMessage() {
		return message;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter your age: ");
		int age = sc.nextInt();
		
//		if(age<18) {
//			throw new CustomAgeException("Age should be greater than 17");
//		}else {
//			System.out.print("You are eligible for voting");
//		}
		
		try {
			if(age<18) {
				throw new CustomAgeException("Age should be greater than 17");
			}else {
				System.out.print("You are eligible for voting");
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
