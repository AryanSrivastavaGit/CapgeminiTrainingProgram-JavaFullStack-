package abstractionAssignment;

abstract class Restaurant {

    abstract void prepareFood();

    void orderReceived() {
        System.out.println("Order received");
    }
}

class FastFoodRestaurant extends Restaurant {
    void prepareFood() {
        System.out.println("Fast food prepared in 10 minutes");
    }
}

class FineDiningRestaurant extends Restaurant {
    void prepareFood() {
        System.out.println("Fine dining food prepared in 30 minutes");
    }
}

public class FoodDeliveryApplication {

	public static void main(String[] args) {
		Restaurant r;

        r = new FastFoodRestaurant();
        r.orderReceived();
        r.prepareFood();

        r = new FineDiningRestaurant();
        r.prepareFood();

	}

}
