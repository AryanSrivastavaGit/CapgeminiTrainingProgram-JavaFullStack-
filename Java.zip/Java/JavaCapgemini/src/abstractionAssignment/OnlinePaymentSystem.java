package abstractionAssignment;

abstract class Payment{
	abstract void processPayment(double amount);
	void printReceipt() {
		System.out.println("Receipt");
	}
}

class CreditCardPayment extends Payment{
	void processPayment(double amount) {
		System.out.println("CreditCardPayment: " + amount);
	}
}

class UPIPayment extends Payment{
	void processPayment(double amount) {
		System.out.println("UPIPayment: " + amount);
	}
}

class NetBankingPayment extends Payment{
	void processPayment(double amount) {
		System.out.println("NetBankingPayment: " + amount);
	}
}

public class OnlinePaymentSystem {

	public static void main(String[] args) {
		Payment p1 = new CreditCardPayment();
		p1.processPayment(1000);
		
		Payment p2 = new UPIPayment();
		p2.processPayment(1100);
		
		Payment p3 = new NetBankingPayment();
		p3.processPayment(1200);

	}

}
