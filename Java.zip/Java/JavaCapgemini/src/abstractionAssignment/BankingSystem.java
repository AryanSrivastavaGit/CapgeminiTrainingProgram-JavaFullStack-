package abstractionAssignment;

abstract class BankAccount {

    abstract void calculateInterest();

    void deposit() {
        System.out.println("Amount deposited");
    }

    void withdraw() {
        System.out.println("Amount withdrawn");
    }
}

class SavingsAccount extends BankAccount {
    void calculateInterest() {
        System.out.println("Savings Account Interest = 4%");
    }
}

class CurrentAccount extends BankAccount {
    void calculateInterest() {
        System.out.println("Current Account Interest = 0%");
    }
}


public class BankingSystem {

	public static void main(String[] args) {
		BankAccount b;

        b = new SavingsAccount();
        b.deposit();
        b.calculateInterest();

        b = new CurrentAccount();
        b.withdraw();
        b.calculateInterest();

	}

}
