package abstractionAssignment;

abstract class Ride {

    abstract void calculateFare(int distance);

    void rideDetails() {
        System.out.println("Ride booked successfully");
    }
}

class BikeRide extends Ride {
    void calculateFare(int distance) {
        System.out.println("Bike Fare = ₹" + (distance * 10));
    }
}

class AutoRide extends Ride {
    void calculateFare(int distance) {
        System.out.println("Auto Fare = ₹" + (distance * 15));
    }
}

class CarRide extends Ride {
    void calculateFare(int distance) {
        System.out.println("Car Fare = ₹" + (distance * 20));
    }
}

public class RideBookingApplication {

	public static void main(String[] args) {
		Ride r;

        r = new BikeRide();
        r.rideDetails();
        r.calculateFare(10);

        r = new CarRide();
        r.calculateFare(10);

	}

}
