package abstractionAssignment;

abstract class Employee {

    abstract void calculateSalary();

    void displayDetails() {
        System.out.println("Employee details displayed");
    }
}

class FullTimeEmployee extends Employee {
    void calculateSalary() {
        System.out.println("Full Time Salary = ₹50,000");
    }
}

class PartTimeEmployee extends Employee {
    void calculateSalary() {
        System.out.println("Part Time Salary = ₹20,000");
    }
}

public class EmployeeManagementSystem {

	public static void main(String[] args) {
		Employee e;

        e = new FullTimeEmployee();
        e.displayDetails();
        e.calculateSalary();

        e = new PartTimeEmployee();
        e.calculateSalary();

	}

}
