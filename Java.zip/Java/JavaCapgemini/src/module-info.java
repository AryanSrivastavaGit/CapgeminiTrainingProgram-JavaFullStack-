/**
 * 
 */
/**
 * 
 */
module JavaCapgemini {
}