package linkedList;

import java.util.Collections;
import java.util.LinkedList;

public class LinkedListCreation {

	public static void main(String[] args) {
		LinkedList ll = new LinkedList();
		
		ll.add(10);
		ll.add(20);
		ll.add(30);
		ll.add(15);
		
		System.out.println(ll);
		
		System.out.println(ll.get(3));
		
		System.out.println(ll.contains(20));

		System.out.println(ll.indexOf(15));
		
		Collections.sort(ll);
		System.out.println(ll);
		
	}

}
