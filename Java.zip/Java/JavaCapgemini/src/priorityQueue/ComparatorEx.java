package priorityQueue;

import java.util.Comparator;

public class ComparatorEx implements Comparator<Student> {

    @Override
    public int compare(Student s1, Student s2) {
        return Integer.compare(s1.id, s2.id);   // sort by id (min-heap)
    }
}
