package priorityQueue;

import java.util.*;
import java.util.PriorityQueue;

import treeSet.Student;

public class PriorityQueueCreation {

	public static void main(String[] args) {
		PriorityQueue pq = new PriorityQueue();  //mean-heap
//		PriorityQueue pq = new PriorityQueue(Collections.reverseOrder());  //max-heap
		pq.offer(10);
		pq.add(3); //add work same as offer but if capacity is full then it will throw exception(IllegalStateException)
		pq.offer(5);
		pq.offer(1);
//		pq.offer("Hello"); // java.lang.ClassCastException because of heterogeneous type data, only homogeneous data allowed
//		pq.offer(null); // java.lang.NullPointerException because of comparison between value.
		pq.offer(1);
		
		System.out.println(pq);
		pq.poll();
		System.out.println(pq);
		
		System.out.println(pq.contains(5));
		
		PriorityQueue<Student> pqs = new PriorityQueue<>((s1, s2) -> s1.id - s2.id);
		pqs.offer(new Student("Aryan", 1, 80));
		pqs.offer(new Student("Aryan", 1, 80));
		pqs.offer(new Student("Aryan", 5, 80));
		pqs.offer(new Student("Aryan", 1, 90));
		pqs.offer(new Student("Ariyan", 1, 80));
		pqs.offer(new Student("Abishek", 2, 90));
		pqs.offer(new Student("Priyanshu", 3, 60));
		pqs.offer(new Student("Devanshu", 4, 75));
		
		while(!pqs.isEmpty()) {
			System.out.println(pqs.poll());
		}
		
	}

}
