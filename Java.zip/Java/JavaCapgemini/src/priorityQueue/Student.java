package priorityQueue;

public class Student{
	String name;
	int id;
	int marks;
	
	Student(){}
	
	public Student(String name, int id, int marks){
		this.name=name;
		this.id=id;
		this.marks=marks;
	}
	
	public String toString() {
		return "Student[ " +name+ " " + id + " "+ marks + "]";
	}

}
