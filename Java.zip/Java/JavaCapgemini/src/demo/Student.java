package demo;

public class Student {
	String name;
	int id;
	int marks;
	
	Student(){}
	
	public Student(String name, int id, int marks){
		this.name=name;
		this.id=id;
		this.marks=marks;
	}
	
	public String toString() {
		return "Student[ " +name+ " " + id + " "+ marks + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}
	
//	public int hashCode() {
//		return id;
//	}
//	
//	public boolean equals(Object o) {
//		Student s = (Student)o;
//		return this.id == s.id;
//	}
}
