package demo;

import java.time.*;
import java.util.*;

public class Demo2 {

	public static void main(String[] args) {
		String date1 = "2026-10-04";
		String date2 = "2026-08-07";
		LocalDate d1 = LocalDate.parse(date1);
		LocalDate d2 = LocalDate.parse(date2);
		Period p = Period.between(d2,d1);
		System.out.println(p.getDays());
		System.out.println(p.getMonths());
		System.out.println(p.getYears());
		
		String time1 = "07:08:00";
		String time2 = "09:10";
		LocalTime t1 = LocalTime.parse(time1);
		LocalTime t2 = LocalTime.parse(time2);
		Duration d = Duration.between(t1,  t2);
		System.out.println(d.toSeconds());
		System.out.println(d.toMinutes());
		System.out.println(d.toHours());
		
		String dateTime1 = "2026-02-17T07:18:25";
		String dateTime2 = "2025-02-17T09:18:25";
		LocalDateTime dt1 = LocalDateTime.parse(dateTime1);
		LocalDateTime dt2 = LocalDateTime.parse(dateTime2);
		Duration dtd = Duration.between(dt2,dt1);
		System.out.println(dtd.toDays());
		System.out.println(dtd.toSeconds());
		System.out.println(dtd.toMinutes());
		System.out.println(dtd.toHours());

	}

}
