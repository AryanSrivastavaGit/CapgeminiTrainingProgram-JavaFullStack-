package demo;

import java.util.*;

public class Demo3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.nextLine();
		
		Vessel vObj[] = new Vessel[n];
		List<Vessel> vL = new ArrayList<>();
		
		for(int i=0; i<n; i++) {
			String v = sc.nextLine();
			String vArr[] = v.split(":");
			vObj[i] = new Vessel(vArr[0], vArr[1], Double.parseDouble(vArr[2]), vArr[3]);
			vL.add(vObj[i]);
		}
		
		VesselUtil vUObj = new VesselUtil();
		vUObj.setVesselList(vL);
		
		List<Vessel> HPVL = vUObj.getHighPerformanceVessels();
		
		String vBI = sc.next();
		Vessel vBId = vUObj.getVesselById(vBI);
		
		System.out.println(vBId.vesselId + " | " + vBId.vesselName + " | " + vBId.vesselType + " | " + vBId.averageSpeed + " knots");
		
		System.out.println("High performance vessels are");
		for(Vessel v : HPVL) {
			System.out.println(vBId.vesselId + " | " + vBId.vesselName + " | " + vBId.vesselType + " | " + vBId.averageSpeed + " knots");
		}
	}

}

class Vessel{
	String vesselId;
	String vesselName;
	double averageSpeed;
	String vesselType;
	
	public String getVesselId() {
		return vesselId;
	}
	public void setVesselId(String vesselId) {
		this.vesselId = vesselId;
	}
	public String getVesselName() {
		return vesselName;
	}
	public void setVesselName(String vesselName) {
		this.vesselName = vesselName;
	}
	public double getAverageSpeed() {
		return averageSpeed;
	}
	public void setAverageSpeed(double averageSpeed) {
		this.averageSpeed = averageSpeed;
	}
	public String getVesselType() {
		return vesselType;
	}
	public void setVesselType(String vesselType) {
		this.vesselType = vesselType;
	}
	
	public Vessel() {}
	public Vessel(String vesselId, String vesselName, double averageSpeed, String vesselType) {
		this.vesselId = vesselId;
		this.vesselName = vesselName;
		this.averageSpeed = averageSpeed;
		this.vesselType = vesselType;
	}
}

class VesselUtil{
	private List<Vessel> vesselList;

	public List<Vessel> getVesselList() {
		return vesselList;
	}

	public void setVesselList(List<Vessel> vesselList) {
		this.vesselList = vesselList;
	}
	
	public void addVesselPerformance(Vessel vessel) {
		vesselList.add(vessel);
	}
	
	public Vessel getVesselById(String vesselId) {
		for(Vessel v : vesselList) {
			if(v.vesselId.equals(vesselId)) {
				return v;
			}
		}
		return null;
	}
	
	public List<Vessel> getHighPerformanceVessels(){
		Double highestAverageSpeed = Double.MIN_VALUE;
		for(Vessel v : vesselList) {
			if(v.averageSpeed > highestAverageSpeed) {
				highestAverageSpeed=v.averageSpeed;
			}
		}
		List<Vessel> vesselWithHighestAverageSpeed = new ArrayList<>();
		for(Vessel v : vesselList) {
			if(v.averageSpeed==highestAverageSpeed) {
				vesselWithHighestAverageSpeed.add(v);
			}
		}
		return vesselWithHighestAverageSpeed;
	}
}