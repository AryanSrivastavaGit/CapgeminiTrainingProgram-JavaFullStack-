package demo;

import java.util.Scanner;

public class Demo4 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		
		UtilityTest u = new UtilityTest();
		
		if(u.validateTestId(input.split(":")[0])) {
			DiagnosticTest dt = u.parseDetails(input);
			
			if(dt instanceof BloodTest) {
				System.out.println("Test id : " + input.split(":")[0]);
				System.out.println("Date of test : " + input.split(":")[1]);
				System.out.println("Test priority : " + input.split(":")[2]);
				System.out.println("Test category : " + input.split(":")[5]);
				System.out.println("Equipment used : " + dt.equipmentSelection());
				System.out.println("Final bill : " + String.format("%.2f",dt.calculateFinalBill()));
			}else {
				System.out.println("Test id : " + input.split(":")[0]);
				System.out.println("Date of test : " + input.split(":")[1]);
				System.out.println("Test priority : " + input.split(":")[2]);
				System.out.println("Test priority : " + input.split(":")[4]);
				System.out.println("Equipment used : " + dt.equipmentSelection());
				System.out.println("Final bill : " + String.format("%.2f",dt.calculateFinalBill()));
			}
			
			
		}else {
			System.out.println("Test id " + input.split(":")[0] + " is invalid");
			System.out.println("Please provide a valid record");
		}

	}

}

abstract class DiagnosticTest{
	String testId;
	String testDate;
	int testPriority;
	
	public DiagnosticTest(String testId, String testDate, int testPriority) {
		this.testId = testId;
		this.testDate = testDate;
		this.testPriority = testPriority;
	}
	
	public abstract String equipmentSelection();
	public abstract double calculateFinalBill();
}

class BloodTest extends DiagnosticTest{
	private int sampleCount;
	private String testCategory; // "Routine" / "Advanced"
	private double costPerSample;
	public BloodTest(String testId, String testDate, int testPriority, int sampleCount, String testCategory,
			double costPerSample) {
		super(testId, testDate, testPriority);
		this.sampleCount = sampleCount;
		this.testCategory = testCategory;
		this.costPerSample = costPerSample;
	}
	
	public String equipmentSelection() {
		if(sampleCount<5) {
			return "Analyzer";
		}else if(sampleCount >= 5 && sampleCount <= 10) {
			return "AutoAnalyzer";
		}else {
			return "HighThroughputSystem";			
		}
	}
	public double calculateFinalBill() {
		int Ecost = 0;
		if(equipmentSelection().equals("Analyzer")) {
			Ecost=800;
		}else if(equipmentSelection().equals("AutoAnalyzer")) {
			Ecost=1500;
		}else {
			Ecost=2800;
		}
		double BaseCost = sampleCount * costPerSample;
		if (testCategory.equalsIgnoreCase("Advanced")) BaseCost *= 1.35;
		double Tax = BaseCost * 0.18;
		double discountPercentage=0;
		if(testPriority == 5) {
			discountPercentage=0.2;
		}else if(testPriority == 3 || testPriority == 4) {
			discountPercentage=0.1;
		}
		double Discount = BaseCost * discountPercentage;
		return BaseCost + Ecost + Tax - Discount;
	}
}

class ImagingTest extends DiagnosticTest{
	String scanType; // "MRI" / "CT" / "XRAY"
	int scanDuration; // minutes
	double ratePerMinute;
	public ImagingTest(String testId, String testDate, int testPriority, String scanType, int scanDuration,
			double ratePerMinute) {
		super(testId, testDate, testPriority);
		this.scanType = scanType;
		this.scanDuration = scanDuration;
		this.ratePerMinute = ratePerMinute;
	}
	
	public String equipmentSelection() {
		if(scanDuration<20) {
			return "BasicScanner";
		}else if(scanDuration >= 20 && scanDuration <= 45) {
			return "AdvancedScanner";
		}else {
			return "UltraScanner";			
		}
	}
	
	public double calculateFinalBill() {
		Double BaseCost = scanDuration * ratePerMinute;
		if (scanType.equalsIgnoreCase("MRI")) BaseCost *= 1.5;
		if (scanType.equalsIgnoreCase("CT")) BaseCost *= 1.3;  
		if (scanType.equalsIgnoreCase("XRAY")) BaseCost *= 1.1;
		double Tax = BaseCost * 0.25;
		double discountPercentage=0;
		if(testPriority == 5) {
			discountPercentage=0.2;
		}else if(testPriority == 3 || testPriority == 4) {
			discountPercentage=0.1;
		}
		double Discount = BaseCost * discountPercentage;
		int Ecost = 0;
		if(equipmentSelection().equals("BasicScanner")) {
			Ecost=1000;
		}else if(equipmentSelection().equals("AdvancedScanner")) {
			Ecost=2000;
		}else {
			Ecost=3500;
		}
		return (BaseCost + Ecost + Tax) - Discount;
	}
}

class UtilityTest{
	public DiagnosticTest parseDetails(String input) {
		String inputArr[] = input.split(":");
		if(input.contains("BloodTest")) {
			return new BloodTest(inputArr[0], inputArr[1], Integer.parseInt(inputArr[2]), Integer.parseInt(inputArr[4]), inputArr[5], Double.parseDouble(inputArr[6]));
		}else {
			return new ImagingTest(inputArr[0], inputArr[1], Integer.parseInt(inputArr[2]), inputArr[4], Integer.parseInt(inputArr[5]), Double.parseDouble(inputArr[6]));
		}
	}
	
	public boolean validateTestId(String testId){
		return testId.matches("^MED\\d{3}[A-Z]$");
	}
	
	public String findTestType(DiagnosticTest test) {
		if(test instanceof BloodTest) {
			return "BloodTest";
		}else {
			return "ImagingTest";
		}
	}
}