package demo;
import java.util.*;

public class Demo5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        EmployeeManagement em = new EmployeeManagement();
        
        
        while(sc.hasNext()) {
        	String ch = sc.next();
        	
        	if(ch.equals("A")) {
        		int id = sc.nextInt();
        		String designation = sc.next();
                em.addEmployee(id, designation);
        	}else{
        		 int id = sc.nextInt();
        		 String newDesignation = sc.next();
                 em.updateDesignation(id, newDesignation);
        	}
        }
        sc.close();
        
//        while(sc.hasNextLine()) {
//        	String input = sc.nextLine();
//        	
//        	String part[] = input.trim().split(" ");
//        	
//        	if(part[0].equals("A")) {
//        		em.addEmployee(Integer.parseInt(part[1]), part[2]);
//        	}else if(part[0].equals("U")) {
//        		em.updateDesignation(Integer.parseInt(part[1]), part[2]);
//        	}       	
//        	
//        }

	}

}

class Employee {
    int employeeID;
    String designation;

    Employee(int employeeID, String designation) {
        this.employeeID = employeeID;
        this.designation = designation;
    }
}

class EmployeeManagement {

    ArrayList<Employee> employeeList = new ArrayList<>();

    void addEmployee(int employeeID, String designation) {
        employeeList.add(new Employee(employeeID, designation));
    }

    void updateDesignation(int employeeID, String newDesignation) {
        for (Employee e : employeeList) {
            if (e.employeeID == employeeID) {
                e.designation = newDesignation;
                System.out.println(e.employeeID + " " + e.designation);
                break;
            }
        }
    }
}