package demo;

import java.util.*;
import java.util.List;

public class Demo1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String tDetails = sc.nextLine();
		
		Utility ut = new Utility();
		
		if(ut.validateTransportId(tDetails.split(":")[0])) {
			
			GoodsTransport gt = ut.parseDetails(tDetails);
			String tt = ut.findObjectType(gt);
			
			if(tt.equals("BrickTransport")) {				
				System.out.println("Transporter id : " + tDetails.split(":")[0]);
				System.out.println("Date of transport : " + tDetails.split(":")[1]);
				System.out.println("Rating of the transport : " + tDetails.split(":")[2]);
				System.out.println("Quantity of bricks : " + tDetails.split(":")[5]);
				System.out.println("Brick price : " + tDetails.split(":")[6]);
				System.out.println("Vehicle for transport : " + gt.vehicleSelection());
				System.out.println("Total charge : " + gt.calculateTotalCharge());

			}else {
				System.out.println("Transporter id : " + tDetails.split(":")[0]);
				System.out.println("Date of transport : " + tDetails.split(":")[1]);
				System.out.println("Rating of the transport : " + tDetails.split(":")[2]);
				System.out.println("Type of the timber : " + tDetails.split(":")[6]);
				System.out.println("Timber price per kilo : " + tDetails.split(":")[7]);
				System.out.println("Vehicle for transport : " + gt.vehicleSelection());
				System.out.println("Total charge : " + gt.calculateTotalCharge());

			}
			
			float tc = gt.calculateTotalCharge();
		}else {
			System.out.println("Transport id "+ tDetails.split(":")[0] +" is invalid");
			System.out.println("Please provide a valid record");
		}
	}

}

abstract class GoodsTransport{
	protected String transportId;
	protected String transportDate;
	protected int transportRating;
	
	public GoodsTransport(String transportId, String transportDate, int transportRating) {
		this.transportId=transportId;
		this.transportDate=transportDate;
		this.transportRating=transportRating;
	}

	public String getTransportId() {
		return transportId;
	}

	public void setTransportId(String transportId) {
		this.transportId = transportId;
	}

	public String getTransportDate() {
		return transportDate;
	}

	public void setTransportDate(String transportDate) {
		this.transportDate = transportDate;
	}

	public int getTransportRating() {
		return transportRating;
	}

	public void setTransportRating(int transportRating) {
		this.transportRating = transportRating;
	}
	
	abstract public String vehicleSelection();
	abstract public float calculateTotalCharge();
}

class BrickTransport extends GoodsTransport{
	private float brickSize;
	private int brickQuantity;
	private float brickPrice;
	
	public BrickTransport(String transportId, String transportDate, int transportRating,
            float brickSize, int brickQuantity, float brickPrice) {
		super(transportId, transportDate, transportRating);
		this.brickSize=brickSize;
		this.brickQuantity=brickQuantity;
		this.brickPrice=brickPrice;
	}
	
	public String vehicleSelection() {
		if(brickQuantity < 300) {
			return "Truck";
		}else if(brickQuantity >= 300 && brickQuantity <= 500) {
			return "Lorry";
		}else{
			return "MonsterLorry";
		}
	}
	public float calculateTotalCharge() {
		float price = brickPrice * brickQuantity;
		float tax = price * 0.3f;
		float discountPercentage = 0;
		if(transportRating==5) {
			discountPercentage=0.2f;
		}else if(transportRating==3 || transportRating==4) {
			discountPercentage=0.1f;
		}else {
			discountPercentage=0;
		}
		float discount = price * discountPercentage;
		float Vehicleprice = 0;
		if(vehicleSelection().equals("Truck")) {
			Vehicleprice=1000;
		}else if(vehicleSelection().equals("Lorry")) {
			Vehicleprice=1700;
		}else{
			Vehicleprice=3000;
		}
		
		return price + Vehicleprice + tax - discount;
	}
}

class TimberTransport extends GoodsTransport{
	private float timberLength;
	private float timberRadius;
	private String timberType;
	private float timberPrice;
	
	public TimberTransport(String transportId, String transportDate, int transportRating,
            float timberLength, float timberRadius,
            String timberType, float timberPrice) {
		super(transportId, transportDate, transportRating);
		this.timberLength=timberLength;
		this.timberRadius=timberRadius;
		this.timberType=timberType;
		this.timberPrice=timberPrice;
	}
	
	float Area = 2 * 3.147f * timberRadius * timberLength;
	public String vehicleSelection() {
		if(Area  < 250) {
			return "Truck";
		}else if(Area  >= 250 && Area  <= 400) {
			return "Lorry";
		}else{
			return "MonsterLorry";
		}
	}
	
	public float calculateTotalCharge() {
		float Volume = 3.147f * timberRadius * timberRadius * timberLength;
		float timberTypeRate=0;
		if(timberType.equals("Premium")) {
			timberTypeRate=0.25f;
		}else {
			timberTypeRate=0.15f;
		}
		float Price = Volume * timberPrice * timberTypeRate;
		float Tax = Price * 0.3f;
		float discountPercentage=0;
		if(transportRating==5) {
			discountPercentage=0.2f;
		}else if(transportRating==3 || transportRating==4) {
			discountPercentage=0.1f;
		}else {
			discountPercentage=0;
		}
		float Vehicleprice = 0;
		if(vehicleSelection().equals("Truck")) {
			Vehicleprice=1000;
		}else if(vehicleSelection().equals("Lorry")) {
			Vehicleprice=1700;
		}else{
			Vehicleprice=3000;
		}
		float discount = Price * discountPercentage;
		return Price + Vehicleprice + Tax - discount;
	}
}

class Utility{
	public GoodsTransport parseDetails(String input) {
		String inputArr[] = input.split(":");
		
		if(input.contains("BrickTransport")){
			GoodsTransport o1 = new BrickTransport(inputArr[0], inputArr[1], Integer.parseInt(inputArr[2]), Float.parseFloat(inputArr[4]), Integer.parseInt(inputArr[5]), Float.parseFloat(inputArr[6]));
			return o1;
		}else {
			GoodsTransport o2 = new TimberTransport(inputArr[0], inputArr[1], Integer.parseInt(inputArr[2]), Float.parseFloat(inputArr[4]), Float.parseFloat(inputArr[5]), inputArr[6], Float.parseFloat(inputArr[7]));
			return o2;
		}
	}
	
	public boolean validateTransportId(String transportId) {
		return transportId.matches("(?i)^RTS(?-i)\\d{3}[A-Z]$");
	}
	
	public String findObjectType(GoodsTransport goodsTransport) {
		if(goodsTransport instanceof BrickTransport) {
			return "BrickTransport";
		}else {
			return "TimberTransport";
		}
	}
}