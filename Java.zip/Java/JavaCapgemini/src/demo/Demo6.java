package demo;

import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class Demo6 {
	public static String processString(String str, int k) {
		
		// 1. Reverse
		String reversed = new StringBuilder(str).reverse().toString();
		
		// 2. Replace vowels
		StringBuilder replaced = new StringBuilder();
		
		for (char ch : reversed.toCharArray()) {
			
			boolean upper = Character.isUpperCase(ch);
			char lower = Character.toLowerCase(ch);
			
			char newChar = lower;
			
			switch (lower) {
			case 'a': newChar = 'e'; break;
			case 'e': newChar = 'i'; break;
			case 'i': newChar = 'o'; break;
			case 'o': newChar = 'u'; break;
			case 'u': newChar = 'a'; break;
			}
			
			if (upper)
				newChar = Character.toUpperCase(newChar);
			
			replaced.append(newChar);
		}
		
		// 3. Remove duplicates (keep first occurrence)
		StringBuilder noDuplicate = new StringBuilder();
		Set<Character> seen = new LinkedHashSet<>();
		
		for (char ch : replaced.toString().toCharArray()) {
			if (!seen.contains(ch)) {
				seen.add(ch);
				noDuplicate.append(ch);
			}
		}
		
		String result = noDuplicate.toString();
		
		// 4. Rotate right by K
		int len = result.length();
		if (len > 0) {
			k = k % len;
			result = result.substring(len - k) + result.substring(0, len - k);
		}
		
		return result;
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		sc.nextLine();
		
		for (int i = 0; i < T; i++) {
			String[] input = sc.nextLine().split(" ");
			String str = input[0];
			int k = Integer.parseInt(input[1]);
			
			System.out.println(processString(str, k));
		}
	}

}
