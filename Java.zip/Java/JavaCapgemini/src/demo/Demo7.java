package demo;

import java.util.*;
public class Demo7 {

	public static void main(String[] args) {
////		Set<Student> st = new HashSet<>();
//		LinkedHashSet<Student> st = new LinkedHashSet<>();
////		TreeSet<Student> st = new TreeSet<>(Collections.reverseOrder(new ComparatorClass()));
//		st.add(new Student("Aryan", 1, 90));
//		st.add(new Student("Aryan", 1, 90));
//		st.add(new Student("Aryan", 2, 80));
//		st.add(new Student("yan", 3, 60));
//		st.add(new Student("an", 4, 70));
//		
//		for(Student s : st) {
//			System.out.println(s);
//		}
		
		
		
//		Queue<Student> q = new PriorityQueue<>(Collections.reverseOrder(new ComparatorClass()));
//		q.add(new Student("Aryan", 1, 90));
//		q.add(new Student("Aryan", 1, 90));
//		q.add(new Student("Aryan", 2, 80));
//		q.add(new Student("yan", 3, 60));
//		q.add(new Student("an", 4, 70));
//		
//		while(!q.isEmpty()) {
//			System.out.println(q.poll());
//		}
		
		Student s1 = (new Student("Aryan", 5, 90));
		Student s2 = (new Student("Aryan", 1, 100));
		Student s3 = (new Student("Aryan", 2, 80));
		Student s4 = (new Student("yan", 3, 60));
		Student s5 = (new Student("an", 4, 70));
//		Map<Integer, Student> m = new HashMap<>();
//		Map<Integer, Student> m = new LinkedHashMap<>();
		Map<Integer, Student> m = new TreeMap<>();
		m.put(s1.getId(), s1);
		m.put(s2.getId(), s2);
		m.put(s3.getId(), s3);
		m.put(s4.getId(), s4);
		m.put(s5.getId(), s5);
		
		for(Integer i : m.keySet()) {
			System.out.println(m.get(i));
		}
		
	}

}
