package onlineYT;

import java.util.Arrays;

public class ArraysClassEx {

	public static void main(String[] args) {
//		int arr1[] = {1,2,3,4,5,6,7,8,9,10};
//		
//		int index = Arrays.binarySearch(arr1, 5); // array must be sorted for binary search
//		System.out.println(index);
//		System.out.println("=================================");
		
		int arr2[] = {8,5,3,4,2,1,10,6,9,7};
		Arrays.sort(arr2);
		for(int i : arr2) {
			System.out.print(i + " ");
		}
		System.out.println();
		System.out.println("=================================");
		
		Arrays.fill(arr2, 0);
		for(int i : arr2) {
			System.out.print(i + " ");
		}
		System.out.println();
		System.out.println("=================================");

	}

}
