package onlineYT;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CollectionsClassEx {

	public static void main(String[] args) {
		List<Integer> al = new ArrayList<Integer>();
	
	al.add(10);
	al.add(50);
	al.add(30);
	al.add(40);
	al.add(20);
	al.add(60);
	al.add(70);
	System.out.println(al);
	System.out.println("==============================");
	
	System.out.println(Collections.min(al));
	System.out.println("==============================");
	
	System.out.println(Collections.max(al));
	System.out.println("==============================");
	
	System.out.println(Collections.frequency(al,70));
	System.out.println("==============================");
	
	Collections.sort(al);
	System.out.println(al);
	System.out.println("==============================");
	
	Collections.sort(al, Comparator.reverseOrder());
	System.out.println(al);
	System.out.println("==============================");
	
	
	
	List<Student> sl = new ArrayList<Student>();
	
	sl.add(new Student(1, "Aryan"));
	sl.add(new Student(2, "Abishek"));
	sl.add(new Student(5, "Priyanshu"));
	sl.add(new Student(3, "Divyanshu"));
	sl.add(new Student(6, "Aryan"));
	
	System.out.println(sl);
	System.out.println("==============================");
	
	Collections.sort(sl); // because of compareTo() overriding
	System.out.println(sl);
	System.out.println("==============================");
	

	}

}
