package onlineYT;

import java.util.Objects;

public class Student implements Comparable<Student>{
	int id;
	String name;
	
	Student(int id, String name){
		this.id=id;
		this.name=name;
	}
	
	public String toString() {
		return "[Student = { " + this.id + ": " + this.name + " }]";
	}
	
	public int compareTo(Student s) {
//		return this.id - s.id;
		return this.name.compareTo(s.name);
	}
	
	
	public boolean equals(Object o) {
		Student s = (Student)o;
		return this.id == s.id;
	}
	
	public int hashCode() {
		return Objects.hash(id);
	}
}
