package onlineYT;

import java.util.Comparator;
import java.util.Deque;
import java.util.HashSet;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;

public class CollectionEx {

	public static void main(String[] args) {
//		ArrayList<Integer> al = new ArrayList<Integer>();
////		List<Integer> al = new ArrayList<Integer>();
////		List<Integer> al = new LinkedList<Integer>();
//		
//		al.add(10);
//		al.add(20);
//		al.add(30);
//		al.add(40);
//		al.add(50);
//		al.add(60);
//		al.add(70);
//		System.out.println(al);
//		System.out.println("==============================");
//		
//		al.add(1,80);
//		System.out.println(al);
//		System.out.println("==============================");
//		
//		ArrayList<Integer> newAl = new ArrayList<Integer>();
//		newAl.add(90);
//		newAl.add(100);
//		newAl.add(110);
//		
//		al.addAll(newAl);
//		System.out.println(al);
//		System.out.println("==============================");
//		
//		
//		System.out.println(al.get(1)); //O(n)
//		System.out.println("==============================");
//		
//		al.remove(1);  //O(n)
//		System.out.println(al);
//		System.out.println("==============================");
//		
//		al.remove(Integer.valueOf(20));
//		System.out.println(al);
//		System.out.println("==============================");
//		
////		al.clear();
////		System.out.println(al);
////		System.out.println("==============================");
//		
//		al.set(1,100);  //O(n)
//		System.out.println(al);
//		System.out.println("==============================");
//		
//		System.out.println(al.contains(100));  // O(n)
//		System.out.println("==============================");
//		
//		for(int i=0; i<al.size(); i++) {
//			System.out.print(al.get(i) + " ");
//		}
//		System.out.println();
//		System.out.println("==============================");
//		
//		for(Integer i : al) {
//			System.out.print(i + " ");
//		}
//		System.out.println();
//		System.out.println("==============================");
//		
//		Iterator<Integer> it = al.iterator();
//		while(it.hasNext()) {
//			System.out.print(it.next() + " ");
//		}
//		System.out.println();
//		System.out.println("==============================");
		
		
		
		
		
//		Stack<Integer> st = new Stack<Integer>();
//		
//		st.push(10);
//		st.push(20);
//		st.push(30);
//		st.push(40);
//		st.push(50);
//		st.push(60);
//		st.push(70);
//		System.out.println(st);
//		System.out.println("==============================");
//		
//		System.out.println(st.peek());
//		System.out.println("==============================");
//		
//		st.pop();
//		System.out.println(st);
//		System.out.println("==============================");
		
		
		
		
		
		
//		Queue<Integer> q = new LinkedList();
//		
//		q.offer(10);
//		q.offer(20);
//		q.offer(30);
//		q.offer(40);
//		q.offer(50);
//		q.offer(60);
//		q.offer(70);
//		System.out.println(q);
//		System.out.println("==============================");
//		
//		System.out.println(q.peek());
//		System.out.println("==============================");
//		
//		q.poll();
//		System.out.println(q);
//		System.out.println("==============================");
		
		
		
		
////		PriorityQueue<Integer> pq = new PriorityQueue<Integer>();
//		Queue<Integer> pq = new PriorityQueue<Integer>();  //mean-heap implementation
//		
////		Queue<Integer> pq = new PriorityQueue<Integer>(Comparator.reverseOrder()); //max-heap implementation
//		
//		pq.offer(70);
//		pq.offer(30);
//		pq.offer(20);
//		pq.offer(40);
//		pq.offer(60);
//		pq.offer(50);
//		pq.offer(10);
//		System.out.println(pq);  //first element will be always the smallest one because of mean-heap implementation inside
//		System.out.println("==============================");
//		
//		System.out.println(pq.peek());
//		System.out.println("==============================");
//		
//		pq.poll();
//		System.out.println(pq); //first element will be always the smallest one because of mean-heap implementation inside
//		System.out.println("==============================");
		
		
		
		
////		Queue<Integer> ad = new ArrayDeque<Integer>();
////		Deque<Integer> ad = new ArrayDeque<Integer>(); // extra feature included
//		ArrayDeque<Integer> ad = new ArrayDeque<Integer>();
//		
//		ad.offer(100);
//		ad.offer(30);
//		ad.offer(40);
//		ad.offer(20);
//		ad.offer(50);
//		ad.offer(60);
//		ad.offer(70);
//		System.out.println(ad);
//		System.out.println("==============================");
//		
//		ad.offerFirst(80);
//		System.out.println(ad);
//		System.out.println("==============================");
//		
//		ad.offerLast(90);
//		System.out.println(ad);
//		System.out.println("==============================");
//		
//		System.out.println(ad.peek());
//		System.out.println("==============================");
//		
//		System.out.println(ad.peekFirst());
//		System.out.println("==============================");
//		
//		System.out.println(ad.peekLast());
//		System.out.println("==============================");
//		
//		ad.poll();
//		System.out.println(ad);
//		System.out.println("==============================");
//		
//		ad.pollFirst();
//		System.out.println(ad);
//		System.out.println("==============================");
//		
//		ad.pollLast();
//		System.out.println(ad);
//		System.out.println("==============================");
		
		
		
		
////		HashSet<Integer> hs = new HashSet();
//		Set<Integer> hs = new HashSet<Integer>();  //O(1), for every operation
//		
//		hs.add(10);
//		hs.add(30);
//		hs.add(40);
//		hs.add(20);
//		hs.add(50);
//		hs.add(70);
//		hs.add(60);
//		System.out.println(hs);  // ordered not maintained
//		System.out.println("==============================");
//		
//		hs.add(20); // not added, because only unique element are allowed
//		System.out.println(hs);
//		System.out.println("==============================");
//		
//		hs.remove(20);
//		System.out.println(hs);
//		System.out.println("==============================");
//		
//		hs.contains(20);
//		System.out.println(hs);
//		System.out.println("==============================");
//		
//		System.out.println(hs.isEmpty());
//		System.out.println("==============================");
//		
//		System.out.println(hs.size());
//		System.out.println("==============================");
//		
//		hs.clear();
//		System.out.println(hs);
//		System.out.println("==============================");
		
		
		
		
////		LinkedHashSet<Integer> lhs = new LinkedHashSet<Integer>();
//		Set<Integer> lhs = new LinkedHashSet<Integer>();  //same as HashSet, except element ordered is maintained here
//		
//		lhs.add(10);
//		lhs.add(30);
//		lhs.add(40);
//		lhs.add(20);
//		lhs.add(50);
//		lhs.add(70);
//		lhs.add(60);
//		System.out.println(lhs);  // ordered is maintained
//		System.out.println("=============================="); 
		
		
		
////		TreeSet<Integer> ts = new TreeSet<Integer>(); O(log n)
//		Set<Integer> ts = new TreeSet<Integer>(); ////same as HashSet, except element is sorted here
//
//		ts.add(10);
//		ts.add(30);
//		ts.add(40);
//		ts.add(20);
//		ts.add(50);
//		ts.add(70);
//		ts.add(60);
//		System.out.println(ts);  // Sorted Order maintained here because of binary search tree implementation
//		System.out.println("=============================="); 
		
		
		
		
//		Set<Student> ts = new HashSet<Student>(); // hashCode() & equals() override for unique elements
		Set<Student> ts = new TreeSet<Student>(); // compareTo() override for sorting
		
		ts.add(new Student(1, "Aryan"));
		ts.add(new Student(2, "Abishek"));
		ts.add(new Student(3, "Priyanshu"));
		ts.add(new Student(4, "Divyanshu"));
		ts.add(new Student(1, "Aryan"));
		
		System.out.println(ts);
		System.out.println("==============================");
		
		
	}

}
