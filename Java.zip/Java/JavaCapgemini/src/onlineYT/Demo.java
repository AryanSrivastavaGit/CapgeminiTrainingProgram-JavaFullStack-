package onlineYT;

class A{
	public int a = 10;
	public void show() {
		System.out.println("A");
	}
}

class B extends A{
	public int a = 20;
	public void show() {
		System.out.println("B");
	}
	
}

class C extends A{
	public void show() {
		System.out.println("C");
	}
	
}

class Demo{
	public static void main(String[] args) {
		A obj1 = new B();
		System.out.println(obj1.a);
		obj1.show();
	}
}