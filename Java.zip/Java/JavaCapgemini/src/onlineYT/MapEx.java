package onlineYT;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapEx {

	public static void main(String[] args) {
//		Map<Integer, String> hm = new HashMap<>();
//		
//		hm.put(1,"Aryan");
//		hm.put(2,"Abishek");
//		hm.put(3,"Priyanshu");
//		hm.put(4,"Divyanshu");
//		System.out.println(hm);
//		System.out.println("=================================");
//		
//		hm.put(1,"aryan"); //update if present
//		System.out.println(hm);
//		System.out.println("=================================");
//		
//		hm.putIfAbsent(1,"Aryan"); //do not update if already present
//		System.out.println(hm);
//		System.out.println("=================================");
//		
//		System.out.println(hm.containsKey(1)); 
//		System.out.println("=================================");
//		
//		System.out.println(hm.containsValue("ARYAN"));
//		System.out.println("=================================");
//		
//		System.out.println(hm.isEmpty());
//		System.out.println("=================================");
//		
////		hm.clear();
////		System.out.println(hm);
////		System.out.println("=================================");
//		
//		for(Object o : hm.keySet()) {
//			System.out.println(o);
//		}
//		System.out.println("=================================");
//		
//		for(Object o : hm.values()) {
//			System.out.println(o);
//		}
//		System.out.println("=================================");
//		
//		for(Object o : hm.entrySet()) {
//			System.out.println(o);
//		}
//		System.out.println("=================================");
		
		
		
		Map<Integer, String> tm = new TreeMap<>();  // O(log n) 
		
		tm.put(1,"Aryan");
		tm.put(3,"Abishek");
		tm.put(2,"Priyanshu");
		tm.put(4,"Divyanshu");
		System.out.println(tm);  //sorted order by key
		System.out.println("=================================");
		
		tm.remove(2);
		System.out.println(tm);
		System.out.println("=================================");
		
	}

}
