package hashMap;

import java.util.HashMap;

public class HashMapCreation {

	public static void main(String[] args) {
		HashMap hm = new HashMap();
		
		hm.put(1, "Aryan");
		hm.put(1, "Abishek");
		hm.put(1, "Priyanshu");
		hm.putIfAbsent(1, "Divyanshu");
		hm.put(99, "Aryan");
		hm.put(86, "Abishek");
		hm.put(4, "Priyanshu");
		hm.put(45, "Divyanshu");
		hm.put(6, null);
		
		System.out.println(hm);
		System.out.println(hm.entrySet());
		System.out.println(hm.keySet());
		System.out.println(hm.values());
		
		for(Object o : hm.entrySet()) {
			System.out.println(o);
		}
		
		for(Object o : hm.keySet()) {
			System.out.println(o);
		}
		
		for(Object o : hm.values()) {
			System.out.println(o);
		}
		

	}

}
