package treeMap;

import java.util.TreeMap;

public class TreeMapCreation {

	public static void main(String[] args) {
		TreeMap tm = new TreeMap();
//		TreeMap<Integer, String> tm = new TreeMap<Integer, String>();
		
		tm.put(1, "Aryan");
		tm.put(1, "Abishek");
		tm.put(1, "Priyanshu");
		tm.putIfAbsent(1, "Divyanshu");
		tm.put(99, "Aryan");
		tm.put(86, "Abishek");
		tm.put(4, "Priyanshu");
		tm.put(45, "Divyanshu");
		tm.put(6, null);
		
		System.out.println(tm);
		System.out.println(tm.entrySet());
		System.out.println(tm.keySet());
		System.out.println(tm.values());
		
		for(Object o : tm.entrySet()) {
			System.out.println(o);
		}
		
		for(Object o : tm.keySet()) {
			System.out.println(o);
		}
		
		for(Object o : tm.values()) {
			System.out.println(o);
		}

	}

}
