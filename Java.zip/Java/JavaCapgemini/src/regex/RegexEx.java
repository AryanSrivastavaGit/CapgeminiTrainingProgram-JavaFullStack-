package regex;

public class RegexEx {

	public static void main(String[] args) {
		String s1 = "1";
		System.out.println(s1.matches("\\d")); // to check string length to be only 1 for digit
		System.out.println("==============================");
		
		String s2 = "";
		System.out.println(s2.matches("\\d+")); // to check string length to be 1 & more than 1
		System.out.println("==============================");
		
		String s3 = "";
		System.out.println(s3.matches("\\d*")); // to check string even empty will be considered
		System.out.println("==============================");

		String s4 = "45678";
		System.out.println(s4.matches("^\\d+$")); // to check from starting to end should be digit
		System.out.println("==============================");
		
		String s5 = "45678";
		System.out.println(s5.matches("^\\d{5}$")); // to check from starting to end digit count should be {5}
		System.out.println("==============================");
		
		String s6 = "45678";
		System.out.println(s6.matches("^\\d{1,5}$")); // to check from starting to end digit count should be between {1-5}
		System.out.println("==============================");
		
		String s7 = "45678.7";
		System.out.println(s7.matches("^\\d+\\.\\d$")); // to check number of digit before . is 1 or more than 1 and after . should be 1
		System.out.println("==============================");
		
		String s8 = "45678.77743";
		System.out.println(s8.matches("^\\d+\\.\\d+$")); // to check number of digit before and after . is 1 or more than 1 
		System.out.println("==============================");
		
		
		
		
		String ss1 = "a";
		System.out.println(ss1.matches("[a-z]")); // to check string length to be only 1 for alphabet in lowerCase
		System.out.println("==============================");
		
		String ss2 = "ABC";
		System.out.println(ss2.matches("[A-Z]")); // to check string length to be only 1 for alphabet in upperCase
		System.out.println("==============================");
		
		String ss3 = "aAjbSGR";
		System.out.println(ss3.matches("^[a-zA-Z]+$")); // to check string contains both lowerCase or upperCase alphabet in the string
		System.out.println("==============================");
		
		String ss4 = "aryansrivastavag00916@gmail.com";
		System.out.println(ss4.matches("^[a-z@.0-9]+$"));
		System.out.println("==============================");
		
		
		System.out.println("8234567890".matches("[89][0-9]{9}"));
		
		System.out.println("Ab0c".matches("[A-Z][a-z]*[0-9][a-z]*"));
		
		System.out.println("aryan@gmail.com".matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"));
		
		
	}
	

}
