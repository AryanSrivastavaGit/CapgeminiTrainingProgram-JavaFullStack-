package streamAPI;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamAPICreation {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(10);
		al.add(20);
		al.add(30);
		al.add(40);
		al.add(50);
		System.out.println(al);
		System.out.println("=====================================");
		
		//stream()
		al.stream()
		.forEach(System.out::println);
		System.out.println("=====================================");
		
		List<String> names = Arrays.asList("Shradha", "Abishek", "Aryan");
//		List<String> list = new ArrayList<>(Arrays.asList("Shradha", "Abishek", "Aryan")); // modifiable list
		names.stream()
		.forEach(System.out::println);
		System.out.println("=====================================");
		
		//count()
		long count = names.stream().count();
		System.out.println(count);
		System.out.println("=====================================");
		
		//filter
		List<Integer> l1 = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		l1.stream()
		.filter(x -> x%2==0)
		.forEach(System.out::println);
		System.out.println("=====================================");
		
		//map
		List<Integer> l2 = l1.stream()
				.map(x -> x*2)
				.sorted()
				.collect(Collectors.toList()); //use to store value in new List
		System.out.println(l2);
		System.out.println("=====================================");
		
		List<Integer> l3 = Arrays.asList(4,5,9,8,2,3);
		int sum = l3.stream()
		.reduce(0, (x,y)->x+y);
		System.out.println(sum);
		
		

	}

}
