package streamAPI;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FirstUpperCaseLetter {

	public static void main(String[] args) {
		List<String> names = Arrays.asList("Shradha", "Abishek", "aAryan");
		
		List<String> upperNames = names.stream()
				.filter(x -> x.charAt(0) == x.toUpperCase().charAt(0))
				.collect(Collectors.toList());
		System.out.println(upperNames);
		
		
		List<String> onlyLowerCaseNames = names.stream()
				.filter(x -> x.equals(x.toLowerCase()))
				.collect(Collectors.toList());
		System.out.println(onlyLowerCaseNames);
		
		
		List<String> onlyFirstLetter = names.stream()
				.map(x -> ""+x.charAt(x.length()-2)+x.charAt(x.length()-1))
				.collect(Collectors.toList());
		System.out.println(onlyFirstLetter);

	}

}
