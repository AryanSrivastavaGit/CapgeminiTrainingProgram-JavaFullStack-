package vector;

import java.util.Vector;

public class VectorCreation {

	public static void main(String[] args) {
		Vector v = new Vector();
		
		v.add(10);
		v.addElement(20);
		v.add("Hello");
		
		System.out.println(v);
		
		v.insertElementAt(15, 1);
		
		System.out.println(v);
		

	}

}
