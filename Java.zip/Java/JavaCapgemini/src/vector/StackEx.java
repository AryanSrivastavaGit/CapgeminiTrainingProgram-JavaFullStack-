package vector;
import java.util.Stack;

public class StackEx {

	public static void main(String[] args) {
		Stack s = new Stack();
		
		s.push(10);
		s.push(20);
		s.push(30);
		s.push(40);
		s.push("Hello");
		s.push(null);
		
		System.out.println(s);
		
		System.out.println(s.peek());
		
		s.pop();
		
		System.out.println(s);

	}

}
