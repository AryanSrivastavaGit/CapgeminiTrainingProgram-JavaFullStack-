package stringAssignment;

public class RemoveSpecialChar {

	public static void main(String[] args) {
		String str = "My name is Ary@n.";
		
		String res = str.replaceAll("[^a-zA-Z0-9 ]", "");
		
		System.out.println(res);

	}

}
