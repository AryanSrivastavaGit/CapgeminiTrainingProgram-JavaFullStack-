package stringAssignment;

//6. Count number of characters
public class CharCount {

	public static void main(String[] args) {
		char charArr[] = {'a','b','c','d'};
		
		int l = charArr.length;
		
		System.out.println(l);

	}

}
