package stringAssignment;

//3. Reverse a String
public class ReverseString {

	public static void main(String[] args) {
		StringBuffer str = new StringBuffer("Aryan Kumar");
		str.reverse();
		System.out.println(str);

	}

}
