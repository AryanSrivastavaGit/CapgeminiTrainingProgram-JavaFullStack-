package stringAssignment;

//1. Print a String
public class PrintString {

	public static void main(String[] args) {
		String str1 = "Aryan";
		String str2 = new String("Kumar");
		System.out.println(str1 + " " + str2);

	}

}
