package stringAssignment;

//9. Find longest word in a sentence
public class LongestWord {

	public static void main(String[] args) {
		String str = "My name is Aryan.";
		
		String str1[] = str.split(" ");
		
		int maxLen = 0;
		
		String str2="";
		
		for(int i=0; i<str1.length; i++) {
			if(str1[i].length()>maxLen) {
				str2=str1[i];
			}
		}
		
		System.out.println(str2);

	}

}
