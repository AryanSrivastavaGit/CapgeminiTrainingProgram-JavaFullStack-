package stringAssignment;

//5. Remove duplicate characters
public class RemoveDuplicateChar {

	public static void main(String[] args) {
		String str = "My name is Aryan.";
        String result = "";

        for (int i = 0; i < str.length(); i++) {

    		char c = str.charAt(i);
    		
        	if(c == ' ' ) {
        		result += c;
        		continue;
        		
        	}else {        		
        		boolean found = false;
        		
        		for (int j = 0; j < result.length(); j++) {
        			if (result.charAt(j) == c) {
        				found = true;
        				break;
        			}
        		}
        		
        		if (!found) {
        			result += c;
        		}
        		
        	}
        }

        System.out.println(result);
		
		

	}

}
