package stringAssignment;

public class ReverseEachWord {

	public static void main(String[] args) {
		String str = "My name is Aryan.";
		
		String str1[] = str.split(" ");
		
		String str2 = "";
		
		for(int i=0; i<str1.length; i++) {
			StringBuilder sb = new StringBuilder(str1[i]);
			sb.reverse();
			str2 += (sb+" ");
		}
		
		System.out.println(str2.trim());

	}

}
