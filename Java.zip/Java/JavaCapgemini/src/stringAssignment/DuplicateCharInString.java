package stringAssignment;

import java.util.Arrays;

//1. Find duplicate characters in a String
public class DuplicateCharInString {

	public static void main(String[] args) {
		
		String str = "My name is Aryyan";
		String str1 = str.replace(" ", "");
		char chArr[] = str1.toCharArray();
		Arrays.sort(chArr);
		System.out.println(chArr);
		
		int i=0;
		int j=0;
		int count = 0;
		while(j<chArr.length) {
			if(chArr[i]==chArr[j]) {
				count++;
				j++;
			}else {
				if(count>1) {
					System.out.println(chArr[i]);
				}
				count=0;
				i=j;
			}
		}
		if(count>1) {
			System.out.println(chArr[i]);
		}
		
	}

}
