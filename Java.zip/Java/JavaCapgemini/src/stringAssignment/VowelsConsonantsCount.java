package stringAssignment;

//5. Count vowels and consonants

public class VowelsConsonantsCount {

	public static void main(String[] args) {
		
		String str = "Aryan Kumar";
		int l = str.length();
		int countVowel = 0;
		int countConsonant = 0;
		char chArr[] = str.toCharArray();
		
		for(int i=0; i<l; i++) {
			if(chArr[i]=='A' || chArr[i]=='a' || chArr[i]=='E' || chArr[i]=='e' || chArr[i]=='I' || chArr[i]=='i' || chArr[i]=='O' || chArr[i]=='o' || chArr[i]=='U' || chArr[i]=='u') {
				countVowel++;
			}else {
				countConsonant++;
			}
		}
		
		System.out.println("V: " + countVowel + " C: " + countConsonant);

	}

}
