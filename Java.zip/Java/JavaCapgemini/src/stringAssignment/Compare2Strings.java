package stringAssignment;

public class Compare2Strings {

	public static void main(String[] args) {
		String str1 = "Aryan";
		String str2 = new String("Aryan");
		StringBuffer str3 = new StringBuffer("Hello");
		StringBuffer str5 = new StringBuffer("Hello");
		StringBuilder str4 = new StringBuilder("Hello");
		StringBuilder str6 = new StringBuilder("Hello");
		
		System.out.println(str1 == str2);
		System.out.println(str1.equals(str2) + "\n");
		
		System.out.println(str3 == str5);
		System.out.println(str3.equals(str5));
		System.out.println(str4 == str6);
		System.out.println(str4.equals(str6));
		System.out.println(str4.toString() == (str6.toString()));
		System.out.println(str4.toString().equals(str6.toString()) + "\n");
		
//		System.out.println(str3 == str4); //Incompatible operand types StringBuffer and StringBuilder
		System.out.println(str3.equals(str4) + "\n");
		
		
		char chArr1[] = str1.toCharArray();
		char chArr2[] = "Kumar".toCharArray();
		System.out.println(chArr1[3] == chArr2[3]);
//		System.out.println(chArr1[3].equals(chArr2[3]); // Cannot invoke equals(char) on the primitive type char
	}

}
