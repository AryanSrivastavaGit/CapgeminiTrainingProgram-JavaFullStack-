package stringAssignment;

public class UpperCaseLowerCase {

	public static void main(String[] args) {
		String str = "My name is Aryan";
		System.out.println(str.toUpperCase());
		System.out.print(str.toLowerCase());

	}

}
