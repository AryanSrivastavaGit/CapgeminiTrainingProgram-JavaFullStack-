package stringAssignment;

//1. Check if String contains only digits
public class OnlyLetters {

	public static void main(String[] args) {
		String str = "QAuieigv79";
		
//		boolean tf = true;
//		
//		char ch;
//		for(int i=0; i<str.length(); i++) {
//			ch = str.charAt(i);
//			if(ch == '0' || ch == '1' || ch == '2' || ch == '3' || ch == '4' || ch == '5' || ch == '6' || ch == '7' || ch == '8' || ch == '9') {
//				continue;
//			}else {
//				tf=false;
//				break;
//			}
//		}
//		
//		if(tf) {
//			System.out.println("Only Digit");
//		}else {
//			System.out.println("Not only Digit");
//		}
		
		boolean tf = true;
		
		try {
			int n = Integer.parseInt(str);
		}catch(Exception e) {
			tf=false;
			System.out.println("Not only Digit.");
		}
		
		if(tf)
		System.out.println("Only Digit");
	}

}
