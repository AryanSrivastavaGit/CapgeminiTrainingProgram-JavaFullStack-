package stringAssignment;

import java.util.Arrays;

//10. Count occurrences of a substring
public class EachWordCount {

	public static void main(String[] args) {
		String str = "a b ab ba aab bba aba bab a bb c";
		
		String str1[] = str.split(" ");
		
		Arrays.sort(str1);		
		
		String str3 = "";
		for(String s : str1) {
			str3+=(s+" ");
		}
		System.out.println(str3.trim());
		
		int i=0;
		int j=0;
		int count=0;
		
		while(j<str1.length) {
			if(str1[i].equals(str1[j])) {
				count++;
			}else {
				System.out.println(str1[i] + ": " + count);
				i=j;
				count=0;
				j--;
			}
			j++;
		}
		
		System.out.println(str1[i] + ": " + count);

	}

}
