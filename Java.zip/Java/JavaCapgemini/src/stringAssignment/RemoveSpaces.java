package stringAssignment;

//10. Remove spaces from a String
public class RemoveSpaces {

	public static void main(String[] args) {
		String str = " My name  is Aryan";
		
		String str1 = str.trim();
		String str2 = str1.replace(" ","");
		
		System.out.println(str2);

	}

}
