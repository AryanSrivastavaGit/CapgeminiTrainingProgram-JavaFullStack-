package stringAssignment;

//8. Capitalize first letter of each word
public class CapEachFirstWord {

	public static void main(String[] args) {
		String str = "My name is Aryan.";
		
		String str1[] = str.split(" ");
		
		String str2 = "";
		
		for(int i=0; i<str1.length; i++) {
			StringBuilder sb = new StringBuilder(str1[i]);
			String ch = sb.charAt(0)+"";
			sb.replace(0, 1, ch.toUpperCase());
			System.out.println(sb);
			str1[i]=sb.toString();
			
			str2+= (str1[i]+" ");
		}
		
		System.out.println(str2.trim());
		

	}

}
