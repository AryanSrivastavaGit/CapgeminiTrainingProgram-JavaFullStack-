package stringAssignment;

//4. Check if String is Palindrome
public class PlindromeString {
	
	static boolean palindrome(String s) {
		int l = s.length();
		char chArr[] = s.toCharArray();
				
		for(int i=0; i<l/2; i++) {
			if(chArr[i] != chArr[l-1-i]) {
				return false;
			}
		}
		
		return true;
	}

	public static void main(String[] args) {
		String str = "aryra";
		System.out.println(palindrome(str));

	}

}
