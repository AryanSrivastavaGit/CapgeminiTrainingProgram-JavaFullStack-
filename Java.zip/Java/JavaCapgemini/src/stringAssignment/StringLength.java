package stringAssignment;

//2. Find length of a String (without using length())
public class StringLength {
//	@SuppressWarnings("unused")
	public static void main(String[] args) {
		String str = "Aryan Kumar";
		System.out.println(str.length());
		
		
		int len = 0;
		char chArr[] = str.toCharArray();
		for(@SuppressWarnings("unused") char ch : chArr) {
			len++;
		}
		System.out.println(len);

	}

}
