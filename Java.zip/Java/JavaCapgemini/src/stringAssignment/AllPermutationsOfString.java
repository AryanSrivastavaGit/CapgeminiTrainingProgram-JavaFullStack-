package stringAssignment;

//4. Find all permutations of a String
public class AllPermutationsOfString {
	
	public static void permute(String str, String result) {

        // Base case
        if (str.length() == 0) {
            System.out.println(result);
            return;
        }

        // Recursive case
        for (int i = 0; i < str.length(); i++) {

            char ch = str.charAt(i);

            // Remaining string after removing ch
            String remaining = str.substring(0, i) + str.substring(i + 1);
            System.out.println(remaining);

            permute(remaining, result + ch);
        }
    }

	public static void main(String[] args) {
        String s = "ABC";
        permute(s, "");


	}

}
