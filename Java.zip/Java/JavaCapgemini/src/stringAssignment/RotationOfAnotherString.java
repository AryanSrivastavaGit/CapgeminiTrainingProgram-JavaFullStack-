package stringAssignment;

//3. Check if String is rotation of another String
public class RotationOfAnotherString {

	public static void main(String[] args) {
		String str1 = "Aryan";
		String str2 = "Ryana";
		
		String str3 = str1.toLowerCase();
		String str4 = str2.toLowerCase();
		
//		if(str3.length() == str4.length() && (str3+str3).contains(str4)) {
//			System.out.println("Rotation of another string.");
//		}else {
//			System.out.println("Not a rotation of another string.");
//		}
		
		String str5 = str3+str3;
		
		boolean tf = false;
		
		for(int i=0; i<=str3.length(); i++) {
			if(str5.substring(i, i+str4.length()).equals(str4)) {
				tf=true;
				break;
			}
		}
		
		if(tf) {
			System.out.println("Rotation of another string.");
		}else {
			System.out.println("Not a rotation of another string.");
		}
	
		
	}

}
