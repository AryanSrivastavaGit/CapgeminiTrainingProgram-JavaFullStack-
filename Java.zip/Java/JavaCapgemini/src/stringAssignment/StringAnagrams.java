package stringAssignment;

import java.util.Arrays;

public class StringAnagrams {

	public static void main(String[] args) {
		String str1 = "Spar";
		String str2 = str1.toLowerCase();
		char chArr1[] = str2.toCharArray();
		Arrays.sort(chArr1);
		
		String str3 = "Rasp";
		String str4 = str3.toLowerCase();
		char chArr2[] = str4.toCharArray();
		Arrays.sort(chArr2);
		
		for(int i=0; i<chArr1.length; i++) {
			if(chArr1[i]!=chArr2[i]) {
				System.out.println("Not Anagram");
				return;
			}
		}
		
		System.out.println("Anagram");

	}

}
