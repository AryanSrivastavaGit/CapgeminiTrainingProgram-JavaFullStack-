package stringAssignment;

//7. Count number of words
public class WordCount {

	public static void main(String[] args) {
		String str = "My name is Aryan";
		String strArr[] = str.split("\\s+");
		System.out.print(strArr.length);

	}

}
