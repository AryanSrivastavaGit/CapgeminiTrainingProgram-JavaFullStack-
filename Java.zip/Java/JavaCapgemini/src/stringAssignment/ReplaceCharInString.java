package stringAssignment;

//4. Replace a character in a String
public class ReplaceCharInString {

	public static void main(String[] args) {
		String str = "Aryan";
		
		String str1 = str.replace("r","");
		
		System.out.println(str1);

	}

}
