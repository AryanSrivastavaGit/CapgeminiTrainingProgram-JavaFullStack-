package stringAssignment;

//6. Find first non-repeating character

public class FirstNonRepeatingChar {

	public static void main(String[] args) {
		String str = "My name is Aryan.";
		
		for(int i=0; i<str.length(); i++) {
			boolean tf = true;
			for(int j=i+1; j<str.length(); j++) {
				if(str.charAt(i) == str.charAt(j)) {
					tf=false;
				}
			}
			
			if(tf)
				System.out.println(str.charAt(i));
				break;
		}
	

	}

}
