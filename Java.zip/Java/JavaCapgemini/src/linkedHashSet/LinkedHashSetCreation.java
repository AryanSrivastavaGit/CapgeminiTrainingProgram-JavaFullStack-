package linkedHashSet;

import java.util.LinkedHashSet;

public class LinkedHashSetCreation {

	public static void main(String[] args) {
		LinkedHashSet lhs = new LinkedHashSet();
		
		lhs.add(10);
		lhs.add(30);
		lhs.add(20);
		lhs.add(40);
		lhs.add(null);
		
		System.out.println(lhs);
		
		System.out.println(lhs.contains(null));
		
		for(Object o : lhs) {
			System.out.println(o);
		}

	}

}