package abstraction;

public class AbstractAnimalMainApp {

	public static void main(String[] args) {
		AbstractionAnimal objDog = new AbstractionDog();
		objDog.walk();
		objDog.sound();

	}

}
