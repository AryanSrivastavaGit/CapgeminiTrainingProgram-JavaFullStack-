package abstraction;

public class AbstractionCat extends AbstractionAnimal{
	void sound() {
		System.out.println("Meow");
	}
}
