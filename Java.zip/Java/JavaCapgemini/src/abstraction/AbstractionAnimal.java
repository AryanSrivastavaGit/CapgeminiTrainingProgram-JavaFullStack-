package abstraction;

public abstract class AbstractionAnimal {
	void walk() {
		System.out.println("These animals walks on four legs");
	}
	abstract void sound();
}
