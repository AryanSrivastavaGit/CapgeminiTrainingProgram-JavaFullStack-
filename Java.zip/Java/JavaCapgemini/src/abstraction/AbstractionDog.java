package abstraction;

public class AbstractionDog extends AbstractionAnimal{
	void sound() {
		System.out.println("Bark");
	}
}
