package lambdaFunction;

interface Display{
	int a = 10;
	void print();
}

interface Add{
	int addition(int x, int y);
}

public class LambdaFunctionCreation {

	public static void main(String[] args) {
		
//		Display D = new Display(){
//			public void print(){
//				System.out.println("Functional Display interface " + Display.a);
//			}
//		};
//		D.print();
		
		Display D = ()->{  // only functional interface allowed to make lambda expression
			System.out.println("Hello");
			System.out.println("Hello World!");
			System.out.println(Display.a);
		};
		D.print();
		
		
//		Add add = (x,y)->{
//			return x+y;
//		};		
//		System.out.println(add.addition(10, 20));
		
		Add add = (x,y) -> x+y;
		System.out.println(add.addition(10, 20));
		
		

	}

}
