package objectClass;

public class EqualsMethod {

//	public boolean equals(Object obj) {  // actual equals method written inside Object class
//	    return (this == obj);
//	}

	public static void main(String[] args) {
		EqualsMethod obj1 = new EqualsMethod();
		EqualsMethod obj2 = new EqualsMethod();
		EqualsMethod obj3 = obj1;
		
		System.out.println(obj1==obj2);
		System.out.println(obj1.equals(obj2));
		System.out.println(obj1.equals(obj3));

	}

}
