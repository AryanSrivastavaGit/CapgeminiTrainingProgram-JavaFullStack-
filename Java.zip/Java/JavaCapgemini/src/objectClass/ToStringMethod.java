package objectClass;

public class ToStringMethod {
	
//	public String toString() {  // actual toString method written inside the Object class
//	    return getClass().getName() + "@" + Integer.toHexString(hashCode());
//	}


	public static void main(String[] args) {
		ToStringMethod obj = new ToStringMethod();
		System.out.println(obj.toString());
		System.out.println(obj);// toString() returning the reference here implicitly because of System.out.println(Object x) overloading

	}

}
