package objectClass;

public class HashcodeMethodOverrideMainApp {

	public static void main(String[] args) {
		HashcodeMethodOverride obj1 = new HashcodeMethodOverride("Aryan", 1);
		HashcodeMethodOverride obj2 = new HashcodeMethodOverride("Aryan", 1);
		
		System.out.println(obj1 == obj2);
		System.out.println(obj1.equals(obj2));
		
		System.out.println(obj1); //here toString is giving the overrided hashCode value, which is return the hashCode value of members inside its class
		System.out.println(obj2); //here toString is giving the overrided hashCode value, which is return the hashCode value of members inside its class
		System.out.println(obj1.hashCode());
		System.out.println(obj2.hashCode());
		System.out.println(obj1.hashCode() == obj2.hashCode()); // both have same member values which is getting converting into same hashCode integer because of which result is true
		
		
		
		System.out.println(obj1.getClass()); // provide the package address of program
		System.out.println(obj2.getClass());

	}

}
