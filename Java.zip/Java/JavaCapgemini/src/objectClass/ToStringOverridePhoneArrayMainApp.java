package objectClass;

public class ToStringOverridePhoneArrayMainApp {

	public static void main(String[] args) {
		ToStringOverridePhoneArray phone[] = new ToStringOverridePhoneArray[4];
		
		phone[0] = new Iphone(5,5);
		ToStringOverridePhoneArray iphone = phone[0];
		
		System.out.println(iphone.toString()); // toString() provides a String representation of an object and is used to convert an object to a String.
		System.out.println(iphone);  //implicitly calling toString()
	}

}
