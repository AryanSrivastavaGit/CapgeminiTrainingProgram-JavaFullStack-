package objectClass;

public class HashcodeMethode {
	
//	public native int hashCode(); // Method signature in Object class
	
//	The actual hashCode() method in java.lang.Object is native.
//	That means:
//	It is NOT written in Java
//	It is implemented in JVM native code (C/C++)
//	So there is no pure Java source code for it


	public static void main(String[] args) {
		HashcodeMethode obj1 = new HashcodeMethode();
		HashcodeMethode obj2 = new HashcodeMethode();
		HashcodeMethode obj3 = obj1;
		
		
		System.out.println(obj1.hashCode());  // hashCode takes the reference value which is in string format and convert it into some integer value
		System.out.println(obj2.hashCode());
		System.out.println(obj3.hashCode());
		
		System.out.println(obj1.hashCode() == obj2.hashCode());
		System.out.println(obj1.hashCode() == obj3.hashCode()); // this is equal because both the reference value is same so the converted hashCode integer is also same

	}

}
