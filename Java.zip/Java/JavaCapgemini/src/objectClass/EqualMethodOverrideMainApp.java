package objectClass;

public class EqualMethodOverrideMainApp {

	public static void main(String[] args) {
		EqualMethodOverride obj1 = new EqualMethodOverride("Aryan", 1);
		EqualMethodOverride obj2 = new EqualMethodOverride("Aryan", 1);
		
		System.out.println(obj1==obj2);
		System.out.println(obj1.equals(obj2)); // equals only works with objects/non-primitive datatype
		

	}

}
