package objectClass;

public class HashcodeMethodOverride {
	String name;
	int id;
	
	HashcodeMethodOverride(String n, int i){
		name=n;
		id=i;
	}
	
	public boolean equals(Object o) {
		HashcodeMethodOverride obj = (HashcodeMethodOverride)o;
		return this.name.equals(obj.name) && id == obj.id;
	}
	
	public int hashCode() {
//		return this.name.hashCode();
		return this.name.hashCode() + id;
	}

}
