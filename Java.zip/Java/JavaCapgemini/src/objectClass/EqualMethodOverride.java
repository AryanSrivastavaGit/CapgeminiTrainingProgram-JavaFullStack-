package objectClass;

public class EqualMethodOverride {
	String name;
	int id;
	
	EqualMethodOverride(String name, int id){
		this.name = name;
		this.id = id;
	}
	
	public boolean equals(Object o) {  // we override it to make it compare the member's actual values instead of references
		EqualMethodOverride obj = (EqualMethodOverride)o; // down-casting
		return this.name.equals(obj.name) && this.id == obj.id;
//		return this.name == obj.name && this.id == obj.id;
	}
}
