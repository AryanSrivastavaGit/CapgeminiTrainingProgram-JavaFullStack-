package objectClass;

class Iphone extends ToStringOverridePhoneArray{
	Iphone(int ram, int rom){
		super(ram,rom);
	}
}
