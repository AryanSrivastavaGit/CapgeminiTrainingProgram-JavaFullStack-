package objectClass;

public class ToStringOverridePhoneArray {
	int ram;
	int rom;
	
	ToStringOverridePhoneArray(int ram, int rom){
		this.ram = ram;
		this.rom = rom;
	}
	
	public String toString() { // toString() overriding
		return "Phone: RAM: " + ram + " ROM: " + rom;
	}
}
