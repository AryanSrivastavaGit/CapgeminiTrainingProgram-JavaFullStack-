package String;

public class StringMethods {

	public static void main(String[] args) {
		String s1 = "Hello";
		String s2 = "My name is Aryan";
		
		//length() - return length of string
		System.out.println(s1.length());
		
		//charAt(i)
		System.out.println(s1.charAt(4));
		
		//substring(i)
		System.out.println(s1.substring(2));
		
		//substring(i, j)
		System.out.println(s1.substring(1,3));
		
		//concat(str)
		System.out.println(s1.concat(" World!"));
		
		//indexOf(str)
		System.out.println(s1.indexOf("l"));
		
		//indexOf(str, i)
		System.out.println(s1.indexOf("l", 3));
		
		//lastIndexOf(i)
		System.out.println(s1.lastIndexOf("l"));
		
		//equals(obj)
		System.out.println(s1.equals(s2));
		
		//equalsIgnoreCase(str)
		System.out.println(s1.equalsIgnoreCase("Hello"));
		
		//compareTo(str)
		System.out.println(s1.compareTo("hello"));
		
		//compareToIgnoreCase(str)
		System.out.println(s1.compareToIgnoreCase("Hello"));
		
		//toLowerCase()
		System.out.println(s1.toLowerCase());
		
		//toUpperCase()
		System.out.println(s1.toUpperCase());
		
		//trim()
		System.out.println(" Hello ".trim());
		
		//split(str)
		String strArr[] = s2.split(" ");
		System.out.println(strArr); // This gives reference because of println(Object x)
		
		//replace(oldChar, newChar)
		System.out.println(s1.replace("l", "o"));
		
		//contains(charSequence)
		System.out.println(s2.contains("Aryan"));
		
		//toCharArray()
		char chArr[] = s1.toCharArray();
		System.out.println(chArr);  //This is giving directly value not the reference because println(char[] x) is specially overloaded method for the char Array 
		
		//startsWith(str)
		System.out.println(s2.startsWith("My"));
		
		//endsWith(str)
		System.out.println(s2.endsWith("My"));
		

	}

}
