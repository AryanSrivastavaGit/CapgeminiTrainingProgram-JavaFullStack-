package String;

public class StringComparision {
	

	public static void main(String[] args) {
		String str1 = "Hello";  // created inside string constant pool area
		String str2 = "Hi";
		String str3 = str1;//"Hello";  // reference will point to str1
		
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);
		
		str1 = "Hi";  // creates new object reference
		
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);
		
		System.out.println(str1 == str2);
		System.out.println(str1 == str3);
		System.out.println(str1.equals(str2));
		
		
		
		String str4 = new String("Hey"); //created inside regular heap area. Note: 2 reference will be created one inside string constant pool area and second inside regular heap area.
		String str5 = new String("Hey");
		
		System.out.println(str4);
		System.out.println(str5);
		
		System.out.println(str4 == str5);  // comparing references here
		System.out.println(str4.equals(str5)); // comparing variables here

	}

}
