package String;
public class StringBufferEx {

	public static void main(String[] args) { 
		
		// 1. Using default constructor
		StringBuffer sb1 = new StringBuffer();
        sb1.append("Hello");
        System.out.println("Default Constructor: " + sb1);

        // 2. Using constructor with specified capacity
        StringBuffer sb2 = new StringBuffer(50);
        sb2.append("Java Programming");
        System.out.println("With Capacity 50: " + sb2);

        // 3. Using constructor with String
        StringBuffer sb3 = new StringBuffer("Welcome");
        sb3.append(" to Java");
        System.out.println("With String: " + sb3);
        
        
        

		StringBuffer s1 = new StringBuffer(); 
		
		//append(str)
		s1.append("Hello");
		System.out.println(s1);
		
		//insert(i, str)
		s1.insert(5, " World!");
		System.out.println(s1);
		
		//replace(startIndex, endIndex-1, str)
		s1.replace(1, 4, "A");
		System.out.println(s1);
		
		//delete(startIndex, endIndex-1)
		s1.delete(1, 2);
		System.out.println(s1);
		
		//reverse()
		s1.reverse();
		System.out.println(s1);
		
		//capacity()
		System.out.println(s1.capacity()); //The default capacity of the buffer is 16. If the number of characters increases from its current capacity, it increases the capacity by (oldcapacity*2)+2.
		
		//length()
		System.out.println(s1.length()); 
		
		//Use StringBuffer(synchronize) when multithreading needed

	}

}
