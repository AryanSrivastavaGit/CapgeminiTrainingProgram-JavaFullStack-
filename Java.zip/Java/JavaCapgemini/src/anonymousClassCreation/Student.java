package anonymousClassCreation;

public class Student {
	
	int id;
	String name;
	
	Student(){}
	
	Student(int id, String name){
		this.id=id;
		this.name=name;
	}
	
	void display() {
		System.out.println(id + " " + name);
	}
	
	void display(int id, String name) {
	System.out.println(id + " " + name);
}
	
	
	
	int marks1;
	int marks2;
	
	Student(int marks1, int marks2){
		this.marks1=marks1;
		this.marks2=marks2;
	}
	
	
	
	int add() {
		return marks1+marks2;
	}
	
	int add(int marks1, int marks2) {
		return marks1+marks2;
	}

}
