package anonymousClassCreation;

public class AnonymousClass {

	public static void main(String[] args) {
		
//		Student s1 = new Student(1, "Aryan"){
//			void display() {
//				System.out.println(id + " " + name);
//			}
//		};
//		s1.display();
		
		Student s2 = new Student(){
			void display(int id, String name) {
				System.out.println(id + " " + name);
			}
		};
		s2.display(1, "Aryan");
		
		
		
		
//		Student s3 = new Student(100, 99){
//		int add() {
//			return (marks1+ marks2);
//		}
//	};
//	System.out.println(s3.add());
		
		Student s4 = new Student(){
			int add(int marks1, int marks2) {
				return marks1+marks2;
			}
		};
		System.out.println(s4.add(100, 99));

	}

}
