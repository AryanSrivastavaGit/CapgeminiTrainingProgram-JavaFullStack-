package hashSet;

import java.util.HashSet;

public class HashSetCreation {

	public static void main(String[] args) {
		HashSet hs = new HashSet();
		
		hs.add(16);
		hs.add(18);
		hs.add(32);
		hs.add(null);
//		hs.add("H");
//		hs.add("I");
//		hs.add("G");
//		hs.add("AA");
//		hs.add("AB");
//		hs.add("a");
		
		System.out.println(hs);
		
		System.out.println(hs.contains(16));
		
		for(Object o : hs) {
			System.out.println(o);
		}
		
		
		HashSet<Student> s = new HashSet<>();
		s.add(new Student("Aryan", 1));
		s.add(new Student("Aryan", 1));
		s.add(new Student("Aryan", 4));
		s.add(new Student("Abhi", 3));
		s.add(new Student("Aks", 2));
		
		for(Student st : s) {
			System.out.println(st);
		}
		
	}

}
