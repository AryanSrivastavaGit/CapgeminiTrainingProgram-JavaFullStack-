package hashSet;

public class Student{

	String name;
	int id;
	
	Student(){}
	
	Student(String name, int id){
		this.name=name;
		this.id=id;
	}
	
	public String toString() {
		return "Student[ " +name+ " " + id + " ]";
	}
	
	public int hashCode() {
		return id;
	}
	
	public boolean equals(Object o) {
		Student s = (Student)o;
		return this.id == s.id;
	}

}
