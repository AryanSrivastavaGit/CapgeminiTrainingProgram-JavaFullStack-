package hasARelationship;

public class CarObjectArray {
	// early instantiation
//	TyreObjectArray tyres[] = {new TyreObjectArray("MRF"), new TyreObjectArray("MRF"), new TyreObjectArray("MRF"), new TyreObjectArray("MRF")};
	private TyreObjectArray tyres[] = {new TyreObjectArray("MRF"), new TyreObjectArray("MRF"), new TyreObjectArray("MRF"), new TyreObjectArray("MRF")};

	public TyreObjectArray[] getTyres() {
		return tyres;
	}

	public void setTyres(TyreObjectArray[] tyres) {
		this.tyres = tyres;
	}
}
