package hasARelationship;

public class University {
	private String universityName;
	
	University() {}

	University(String universityName) {
		this.universityName = universityName;
	}

	public String getUniversityName() {
		return universityName;
	}

	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}
	
	// has a relationship
	Department d = new Department("CSE");
}
