package hasARelationship;

public class UniversityMainApp {

	public static void main(String[] args) {
		University objUniversity = new University("LPU");
		System.out.println(objUniversity.getUniversityName());
		System.out.println(objUniversity.d.getDepartmentName());
	}

}
