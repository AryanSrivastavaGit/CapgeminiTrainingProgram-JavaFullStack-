package hasARelationship;

public class Engine {
	private int hp;
	
	Engine(){}
	
	Engine(int hp){
		this.hp = hp;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}	
	
}
