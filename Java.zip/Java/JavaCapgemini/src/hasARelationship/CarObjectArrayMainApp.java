package hasARelationship;

public class CarObjectArrayMainApp {

	public static void main(String[] args) {
		CarObjectArray objCarObjectArray = new CarObjectArray();
		
//		for(int i=0; i<objCarObjectArray.tyres.length; i++) { 
//			System.out.println(objCarObjectArray.tyres[i].getBrand());
//		}		
		for(int i=0; i<objCarObjectArray.getTyres().length; i++) {
			System.out.println(objCarObjectArray.getTyres()[i].getBrand());
		}
		
		objCarObjectArray.getTyres()[0].setBrand("Michelin Tyre");
		
		System.out.println(objCarObjectArray.getTyres()[0].getBrand());
		
		
		
		LazyInstantiationInsideCar objLazyInstantiationInsideCar = new LazyInstantiationInsideCar();
		objLazyInstantiationInsideCar.addTyres(new TyreObjectArray("CEAT"));
		objLazyInstantiationInsideCar.addTyres(new TyreObjectArray("CEAT"));
		objLazyInstantiationInsideCar.addTyres(new TyreObjectArray("CEAT"));
		objLazyInstantiationInsideCar.addTyres(new TyreObjectArray("CEAT"));
		
		for(int i=0; i<objLazyInstantiationInsideCar.lazyTyres.length; i++) {
			System.out.println(objLazyInstantiationInsideCar.lazyTyres[i].getBrand());
		}

	}

}
