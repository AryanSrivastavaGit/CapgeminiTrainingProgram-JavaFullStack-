package hasARelationship;

public class LazyInstantiationInsideCar {
	TyreObjectArray lazyTyres[] = new TyreObjectArray[4];
	
	int i=0;
	//helper method
	void addTyres(TyreObjectArray lazyTyres) {
		this.lazyTyres[i]=lazyTyres;
		i++;
	}
}
