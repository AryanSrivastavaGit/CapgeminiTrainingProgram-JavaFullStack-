package hasARelationship;

public class CarMainApp {

	public static void main(String[] args) {
		Car objCar = new Car("BMW");
		
		System.out.println(objCar.getModelName());
		System.out.println(objCar.getEngine().getHp());

	}

}
