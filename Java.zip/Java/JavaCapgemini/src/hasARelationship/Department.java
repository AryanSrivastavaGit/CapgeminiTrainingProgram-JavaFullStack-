package hasARelationship;

public class Department {
	private String departmentName;
	
	Department(){}
	
	Department(String departmentName){
		this.departmentName = departmentName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
}
