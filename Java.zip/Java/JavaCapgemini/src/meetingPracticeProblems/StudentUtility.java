package meetingPracticeProblems;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StudentUtility {
	
	private ArrayList<Student> studentList = new ArrayList<Student>();

	public ArrayList<Student> getStudentList() {
		return studentList;
	}

	public void setStudentList(ArrayList<Student> studentList) {
		this.studentList = studentList;
	}
	

	public Stream<Student> converToStream(){
		return studentList.stream();
	}
	
	public double averageMarks(Stream<Student> stream1) {
		
		ArrayList<Student> al =  (ArrayList<Student>)stream1.collect(Collectors.toList());
		double sumMarks = 0;
		int count = 0;
		for(Student s : al) {
			sumMarks+=s.getMarks();
			count++;
		}
		
		return sumMarks/count;
	}
	
	public Student findTopper(Stream<Student>stream1) {
		ArrayList<Student> al = (ArrayList<Student>) stream1.collect(Collectors.toList());
		int max = Integer.MIN_VALUE;
		Student st = null;
		for(Student s : al) {
			if(max<s.getMarks()) {
				max = s.getMarks();
				st=s;
			}
		}
		return st;
	}

	
	public List<Student> sortByMarks(Stream<Student> stream1){
		
		List<Student> al = stream1.collect(Collectors.toList());
		
//		Collections.sort(al); // use while using comparable		
		Collections.sort(al, Collections.reverseOrder(new ComparatorClass()));  // use while using Comparator
		
		return al;
	}

}
