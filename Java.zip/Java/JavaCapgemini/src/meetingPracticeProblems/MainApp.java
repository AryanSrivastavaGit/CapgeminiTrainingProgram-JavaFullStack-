package meetingPracticeProblems;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.text.DecimalFormat;

public class MainApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter number of students: ");
		int numStudent = sc.nextInt();
		
		ArrayList<Student> al = new ArrayList<Student>();
		
		int id;
		String name;
		int marks;
		
		for(int i=0; i<numStudent; i++) {
			
			System.out.print("Enter Student ID: ");
			id = sc.nextInt();
			sc.nextLine();
			System.out.print("Enter Student Name: ");
			name = sc.nextLine();
			System.out.print("Enter Marks: ");
			marks = sc.nextInt();
			
			al.add(new Student(id, name, marks));
			
		}
		
//		for(Student s : al) {
//			System.out.println(s.getId() + " " + " " + s.getName() + " " + s.getMarks());
//		}
		
		StudentUtility obj = new StudentUtility();
		obj.setStudentList(al);
		
//		for(Student s : obj.getStudentList()) {
//			System.out.println(s.getId() + " " + " " + s.getName() + " " + s.getMarks());
//		}
		
		DecimalFormat df = new DecimalFormat("0.00");
		String fV = df.format(obj.averageMarks(obj.converToStream()));
		System.out.println("Average Marks: " + fV);
		
		Student st = obj.findTopper(obj.converToStream());
		System.out.print("Top Scorer: ");
		System.out.println(st.getId() + " " + " " + st.getName() + " " + st.getMarks());
		
		System.out.println("Students Sorted by Marks:");
		List<Student> l = obj.sortByMarks(obj.converToStream());
		for(Student s : l) {
			System.out.println(s.getId() + " " + " " + s.getName() + " " + s.getMarks());
		}
		
		sc.close();
		
	}

}
