package meetingPracticeProblems;
import java.util.*;
public class ComparatorClass implements Comparator<Student>{
	public int compare(Student s1, Student s2) {
		return s1.getMarks()-s2.getMarks();
	}
}
