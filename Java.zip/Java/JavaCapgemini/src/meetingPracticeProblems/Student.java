package meetingPracticeProblems;

//public class Student implements Comparable<Student>{
public class Student{

		private int id;
		private String name;
		private int marks;
		
		Student(int id, String name, int marks){
			this.id=id;
			this.name=name;
			this.marks=marks;
		}

		public int getId() {
			return id;
		}

		public String getName() {
			return name;
		}

		public int getMarks() {
			return marks;
		}
		
//		public int compareTo(Student s) {
//			return this.getMarks()-s.getMarks();
//		}
		
}
