package treeSet;

public class Student implements Comparable<Student>{


	String name;
	public int id;
	int marks;
	
	Student(){}

	public Student(String name, int id, int marks){
		this.name=name;
		this.id=id;
		this.marks=marks;
	}
	
	public String toString() {
		return "Student[ " +name+ " " + id + " "+ marks + "]";
	}
	
	public int compareTo(Student s) {
		return this.id - s.id;
	}

}