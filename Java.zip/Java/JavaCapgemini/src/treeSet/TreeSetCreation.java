package treeSet;

import java.util.Collections;
import java.util.TreeSet;

public class TreeSetCreation {

	public static void main(String[] args) {
		TreeSet ts = new TreeSet();
		
		ts.add(10);
		ts.add(30);
		ts.add(15);
		ts.add(20);
		ts.add(40);
//		ts.add("Hello"); //java.lang.ClassCastException because comparison happening between int and String obj which is not possible, heterogeneous data type not allowed
//		ts.add(null);  //java.lang.NullPointerException, because to compare it need some value.
		
		System.out.println(ts);
		

		//object TreeSet
		TreeSet<Student> ots = new TreeSet<Student>(); //uses Comparable, compareTo()
//		TreeSet<Student> ots = new TreeSet<Student>(Collections.reverseOrder()); // uses Comparable, compareTo(), highest to lowest
		ots.add(new Student("Aryan", 1, 80));
		ots.add(new Student("Aryan", 1, 80));
		ots.add(new Student("Ariyan", 1, 30));
		ots.add(new Student("Abishek", 2, 90));
		ots.add(new Student("Priyanshu", 3, 60));
		ots.add(new Student("Devanshu", 4, 75));
		
		System.out.println(ots);
		

//		TreeSet<Student> ots1 = new TreeSet<Student>(new StudentComparator());  // uses Comparator, compare()
		TreeSet<Student> ots1 = new TreeSet<Student>(Collections.reverseOrder(new StudentComparator()));  // uses Comparator, compare()
		ots1.add(new Student("Aryan", 1, 80));
		ots1.add(new Student("Abishek", 2, 90));
		ots1.add(new Student("Priyanshu", 3, 60));
		ots1.add(new Student("Devanshu", 4, 75));
		System.out.println(ots1);
	}

}
