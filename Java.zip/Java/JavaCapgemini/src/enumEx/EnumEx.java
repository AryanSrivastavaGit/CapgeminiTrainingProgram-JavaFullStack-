package enumEx;

enum Status{  // enum is also a class we can use enum same as class but we can not extend enum because enum have already extended enum class internally and multiple inheritance is not allowed in java
	running, success, pending, failed; // these are enum object constant, [0,1,2,3]
}

enum Laptop{
	msi(1000), lenovo(1500), hp(2000), mackbook(2500), dell;
	
	private int price;
	
	private Laptop() {
		price = 500;
	}

	private Laptop(int price) {
		this.price = price;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
}

public class EnumEx {

	public static void main(String[] args) {
		
		Status s = Status.running;
		
		System.out.println(s); // print running
		
		System.out.println(s.ordinal()); // index of constant stored in s
		
		Status sArr[] = Status.values();
		
		for(Status ss : sArr) {
			System.out.println(ss + ": " + ss.ordinal());
		}
		
		
		//we can also compare this constants
//		if(s == Status.running) {
//			System.out.println("All good");
//		}else if(s == Status.success) {
//			System.out.println("Done");
//		}else if(s == Status.pending) {
//			System.out.println("Please Wait!");
//		}else if(s == Status.failed) {
//			System.out.println("Try again.");
//		}
		
		
//		switch(s) {
//		case running : System.out.println("All good");
//		break;
//		case success : System.out.println("Done");
//		break;
//		case pending : System.out.println("Please Wait!");
//		break;
//		case failed : System.out.println("Try again.");
//		}
		
		for(Laptop l : Laptop.values()) {
			System.out.println(l + ": " + l.getPrice());
		}		
		
	}

}
