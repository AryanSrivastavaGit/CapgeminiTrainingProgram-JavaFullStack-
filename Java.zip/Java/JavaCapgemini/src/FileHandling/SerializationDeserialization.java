package FileHandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerializationDeserialization implements Serializable{
	
	String name;
	int id;
	
	SerializationDeserialization(String name,int id){
		this.name=name;
		this.id=id;
	}

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		SerializationDeserialization s = new SerializationDeserialization("Aryan",1);
		
		File folder = new File("C:\\Users\\91997\\eclipse-workspace\\JavaCapgemini\\src\\FileHandling\\DemoFiles");
		folder.mkdir();
		
		File f5 = new File(folder, "StudentData.ser");
		try {
			f5.createNewFile();
		}catch(IOException e){
			e.printStackTrace();
		}
		
		FileOutputStream fos = new FileOutputStream(f5);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(s);
		oos.close();
		fos.close();
		
			
		SerializationDeserialization st = null;
		FileInputStream fis = new FileInputStream(f5);
		ObjectInputStream ois = new ObjectInputStream(fis);
		st = (SerializationDeserialization)ois.readObject();
		ois.close();
		fis.close();			

		System.out.println(st.name);
		System.out.println(st.id);

	}

}
