package polymorphismAssignment;

class MediaFile {
    void play() {
        System.out.println("Playing media");
    }
}

class AudioFile extends MediaFile {
    void play() {
        System.out.println("Playing audio");
    }
}

class VideoFile extends MediaFile {
    void play() {
        System.out.println("Playing video");
    }
}

class Podcast extends MediaFile {
    void play() {
        System.out.println("Playing podcast");
    }
}


public class MediaPlayerApplication {

	public static void main(String[] args) {
		MediaFile m;

        m = new AudioFile();
        m.play();

        m = new VideoFile();
        m.play();

	}

}
