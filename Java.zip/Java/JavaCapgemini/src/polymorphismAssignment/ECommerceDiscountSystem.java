package polymorphismAssignment;

class Customer {
    void calculateDiscount() {
        System.out.println("No discount");
    }
}

class RegularCustomer extends Customer {
    void calculateDiscount() {
        System.out.println("5% Discount");
    }
}

class PremiumCustomer extends Customer {
    void calculateDiscount() {
        System.out.println("10% Discount");
    }
}

class VIPCustomer extends Customer {
    void calculateDiscount() {
        System.out.println("20% Discount");
    }
}

public class ECommerceDiscountSystem {

	public static void main(String[] args) {
		Customer c;

        c = new RegularCustomer();
        c.calculateDiscount();

        c = new VIPCustomer();
        c.calculateDiscount();

	}

}
