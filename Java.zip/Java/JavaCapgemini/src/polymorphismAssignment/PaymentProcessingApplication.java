package polymorphismAssignment;

interface Payment {
    void pay();
}

class CreditCardPayment implements Payment {
    public void pay() {
        System.out.println("Payment via Credit Card");
    }
}

class DebitCardPayment implements Payment {
    public void pay() {
        System.out.println("Payment via Debit Card");
    }
}

class UPIPayment implements Payment {
    public void pay() {
        System.out.println("Payment via UPI");
    }
}


public class PaymentProcessingApplication {

	public static void main(String[] args) {
		Payment p;

        p = new CreditCardPayment();
        p.pay();
        
        CreditCardPayment obj = (CreditCardPayment)p;
        p.pay();

        p = new UPIPayment();
        p.pay();

	}

}
