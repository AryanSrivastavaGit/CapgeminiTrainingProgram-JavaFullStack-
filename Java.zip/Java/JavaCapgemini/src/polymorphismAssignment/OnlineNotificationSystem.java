package polymorphismAssignment;

class Notification {
    void send() {
        System.out.println("Sending notification");
    }
}

class EmailNotification extends Notification {
    void send() {
        System.out.println("Email sent");
    }
}

class SMSNotification extends Notification {
    void send() {
        System.out.println("SMS sent");
    }
}

class PushNotification extends Notification {
    void send() {
        System.out.println("Push notification sent");
    }
}


public class OnlineNotificationSystem {

	public static void main(String[] args) {
		Notification n;

        n = new EmailNotification();
        n.send();

        n = new SMSNotification();
        n.send();

	}

}
