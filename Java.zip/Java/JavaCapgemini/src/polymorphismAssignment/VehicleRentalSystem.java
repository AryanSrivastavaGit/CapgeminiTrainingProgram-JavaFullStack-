package polymorphismAssignment;

class Vehicle {
    void calculateRent() {
        System.out.println("Vehicle rent");
    }
}

class Car extends Vehicle {
    void calculateRent() {
        System.out.println("Car Rent = 2000/day");
    }
}

class Bike extends Vehicle {
    void calculateRent() {
        System.out.println("Bike Rent = 500/day");
    }
}

class Truck extends Vehicle {
    void calculateRent() {
        System.out.println("Truck Rent = 4000/day");
    }
}


public class VehicleRentalSystem {

	public static void main(String[] args) {
		Vehicle v;

        v = new Car();
        v.calculateRent();

        v = new Bike();
        v.calculateRent();

	}

}
