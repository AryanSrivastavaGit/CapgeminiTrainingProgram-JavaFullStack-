package polymorphismAssignment;

class MenuItem {
    void calculatePrice() {
        System.out.println("Item price");
    }
}

class VegItem extends MenuItem {
    void calculatePrice() {
        System.out.println("Veg Item Price = 150");
    }
}

class NonVegItem extends MenuItem {
    void calculatePrice() {
        System.out.println("Non-Veg Item Price = 250");
    }
}


public class RestaurantBillingSystem {

	public static void main(String[] args) {
		MenuItem m;

        m = new VegItem();
        m.calculatePrice();

        m = new NonVegItem();
        m.calculatePrice();

	}

}
