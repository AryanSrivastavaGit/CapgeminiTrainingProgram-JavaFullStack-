package polymorphismAssignment;

class Character {
    void attack() {
        System.out.println("Character attacks");
    }
}

class Warrior extends Character {
    void attack() {
        System.out.println("Warrior attacks with sword");
    }
}

class Archer extends Character {
    void attack() {
        System.out.println("Archer attacks with bow");
    }
}

class Mage extends Character {
    void attack() {
        System.out.println("Mage attacks with magic");
    }
}

public class GameCharacterBehavior {

	public static void main(String[] args) {
		Character c;

        c = new Warrior();
        c.attack();

        c = new Mage();
        c.attack();

	}

}
