package polymorphismAssignment;

class BankAccount {
    void calculateInterest() {
        System.out.println("Bank interest");
    }
}

class SavingsAccount extends BankAccount {
    void calculateInterest() {
        System.out.println("Savings Interest = 4%");
    }
}

class FixedDepositAccount extends BankAccount {
    void calculateInterest() {
        System.out.println("FD Interest = 7%");
    }
}

class CurrentAccount extends BankAccount {
    void calculateInterest() {
        System.out.println("Current Account Interest = 0%");
    }
}


public class BankingInterestCalculator {

	public static void main(String[] args) {
		BankAccount b;

        b = new SavingsAccount();
        b.calculateInterest();

        b = new FixedDepositAccount();
        b.calculateInterest();

	}

}
