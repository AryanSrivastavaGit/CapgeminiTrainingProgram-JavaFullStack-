package polymorphismAssignment;

class Employee {
    void calculateSalary() {
        System.out.println("Employee salary");
    }
}

class Developer extends Employee {
    void calculateSalary() {
        System.out.println("Developer Salary = 50,000");
    }
}

class Manager extends Employee {
    void calculateSalary() {
        System.out.println("Manager Salary = 80,000");
    }
}

class Intern extends Employee {
    void calculateSalary() {
        System.out.println("Intern Salary = 15,000");
    }
}

public class EmployeeSalarySystem {

	public static void main(String[] args) {
		Employee e;

        e = new Developer();
        e.calculateSalary();

        e = new Manager();
        e.calculateSalary();

        e = new Intern();
        e.calculateSalary();

	}

}
