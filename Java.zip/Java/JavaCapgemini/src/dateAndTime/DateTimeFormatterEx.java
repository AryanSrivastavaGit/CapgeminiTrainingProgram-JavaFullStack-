package dateAndTime;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateTimeFormatterEx {

	public static void main(String[] args) {
		LocalDate now = LocalDate.now();
		System.out.println(now);
		
		DateTimeFormatter myFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String format = now.format(myFormat);
		System.out.println(format);
		
		String date = "13/02/2026";
		LocalDate custDate = LocalDate.parse(date, myFormat);
		System.out.println(custDate);
		

	}

}
