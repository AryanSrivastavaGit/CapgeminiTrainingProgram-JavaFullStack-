package dateAndTime;

import java.time.ZonedDateTime;

public class ZonedDateTimeEx {

	public static void main(String[] args) {
		ZonedDateTime ztd = ZonedDateTime.now();
		System.out.println(ztd);

	}

}
