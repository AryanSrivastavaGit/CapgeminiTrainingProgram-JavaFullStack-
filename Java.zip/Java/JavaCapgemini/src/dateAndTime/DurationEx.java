package dateAndTime;

import java.time.Duration;
import java.time.Instant;

public class DurationEx {

	public static void main(String[] args) {
		Instant start = Instant.now();
		
		int sum=0;
		for(int i=0; i<100000; i++)
			sum+=i;
		System.out.println(sum);
		
		Instant end = Instant.now();
		
		Duration d1 = Duration.between(start, end);
		System.out.println(d1);
		

	}

}
