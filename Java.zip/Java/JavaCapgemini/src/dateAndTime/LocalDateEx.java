package dateAndTime;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;

public class LocalDateEx {

	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		System.out.println(today);
		System.out.println("====================================");
		
		
		int day = today.getDayOfMonth();
		DayOfWeek week = today.getDayOfWeek();
		int month1 = today.getMonthValue();
		Month month2 = today.getMonth();
		int year = today.getYear();
		System.out.println(day + "-" + week + "-" + month1 + "-" + year);
		System.out.println(day + "-" + week + "-" + month2 + "-" + year);
		System.out.println("====================================");
		
		
		LocalDate customDate = LocalDate.of(2003, 8, 17);
		System.out.println(customDate);
		System.out.println("====================================");
		
		
		LocalDate c = LocalDate.parse("2003-08-17");
		System.out.println(c);
		System.out.println("====================================");
		
		
		LocalDate yesterday = today.minusDays(1);
		LocalDate pastMonth = today.minusMonths(2);
		LocalDate pastYear = today.minusYears(3);
		LocalDate tommorow = today.plusDays(1);
		LocalDate futureMonth = today.plusMonths(2);
		LocalDate futureYear = today.plusYears(3);
		System.out.println(yesterday);
		System.out.println(pastMonth);
		System.out.println(pastYear);
		System.out.println(tommorow);
		System.out.println(futureMonth);
		System.out.println(futureYear);
		System.out.println("====================================");
		
		
		System.out.println(yesterday.isBefore(today));
		System.out.println(tommorow.isAfter(today));	

	}

}
