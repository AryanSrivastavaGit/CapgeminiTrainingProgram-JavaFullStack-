package dateAndTime;

import java.time.LocalDateTime;

public class LocalDateTimeEx {

	public static void main(String[] args) {
		LocalDateTime dt = LocalDateTime.now();
		System.out.println(dt);

	}

}
