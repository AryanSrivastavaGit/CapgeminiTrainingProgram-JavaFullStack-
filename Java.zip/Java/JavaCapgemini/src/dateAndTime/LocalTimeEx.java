package dateAndTime;

import java.time.LocalTime;

public class LocalTimeEx {

	public static void main(String[] args) {
		LocalTime t = LocalTime.now();
		System.out.println(t);
		System.out.println("====================================");
		
		
		int seconds = t.getSecond();
		int minutes =  t.getMinute();
		int hours = t.getHour();
		System.out.println(hours + ":" + minutes + ":" + seconds);
		System.out.println("====================================");
		
		
		LocalTime custTime = LocalTime.of(16, 45, 40);
		System.out.println(custTime);
		System.out.println("====================================");
		
		
		LocalTime parseTime = LocalTime.parse("16:17:52");
		System.out.println(parseTime);
		System.out.println("====================================");
		
		
		LocalTime before1Hour = t.minusHours(1);
		LocalTime before1Minute = t.minusMinutes(1);
		LocalTime before1Second = t.minusSeconds(1);
		LocalTime after1Hour = t.plusHours(1);
		LocalTime after1Minute = t.plusMinutes(1);
		LocalTime after1Second = t.plusSeconds(1);
		System.out.println(before1Hour);
		System.out.println(before1Minute);
		System.out.println(before1Second);
		System.out.println(after1Hour);
		System.out.println(after1Minute);
		System.out.println(after1Second);
		System.out.println("====================================");
		
		
		System.out.println(before1Hour.isBefore(t));
		System.out.println(after1Hour.isAfter(t));
		
		
	}
}
