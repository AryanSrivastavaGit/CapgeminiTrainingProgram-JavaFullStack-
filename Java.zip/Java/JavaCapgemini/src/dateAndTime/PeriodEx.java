package dateAndTime;

import java.time.LocalDate;
import java.time.Period;

public class PeriodEx {

	public static void main(String[] args) {
		LocalDate now = LocalDate.now();
		LocalDate before = LocalDate.of(2003, 8, 17);
		
		Period p = Period.between(now, before);
		System.out.println(p);

	}

}
