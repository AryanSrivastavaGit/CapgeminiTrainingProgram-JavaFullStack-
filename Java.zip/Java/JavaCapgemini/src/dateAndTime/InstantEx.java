package dateAndTime;

import java.time.Instant;

public class InstantEx {

	public static void main(String[] args) {
		long ctms = System.currentTimeMillis(); // return total milliseconds from 1-01-1970 UTC to now
		System.out.println(ctms);
		
		Instant i = Instant.now();
		System.out.println(i); 

	}

}
