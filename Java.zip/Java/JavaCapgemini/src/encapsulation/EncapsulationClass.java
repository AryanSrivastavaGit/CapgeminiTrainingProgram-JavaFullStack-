package encapsulation;

public class EncapsulationClass {

		private String username;
		private String password;
		
		public void setDetails(String username, String password) {
			this.username = username;
			int passLen = password.length();
			if(passLen >= 8) {
				this.password = password;
			}
		}
		
		public void getDetails() {
			System.out.println(username);
			System.out.println(password);
		}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
