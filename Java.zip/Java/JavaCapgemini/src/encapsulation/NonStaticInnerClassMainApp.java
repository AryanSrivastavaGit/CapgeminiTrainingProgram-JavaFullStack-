package encapsulation;

public class NonStaticInnerClassMainApp {

	public static void main(String[] args) {
		NonStaticInnerClass objNonStaticInnerClass = new NonStaticInnerClass();
		NonStaticInnerClass.Inner.display();
		
		NonStaticInnerClass.Inner objNonStaticInnerClassInner = objNonStaticInnerClass.new Inner();
		objNonStaticInnerClassInner.display1();

	}
}
