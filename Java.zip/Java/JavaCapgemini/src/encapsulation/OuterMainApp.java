package encapsulation;

public class OuterMainApp {
	
	public static void main(String[] args) {
		Outer.Inner.display();
		Outer.Inner innerObj = new Outer.Inner();
		innerObj.display1();
	}
}
