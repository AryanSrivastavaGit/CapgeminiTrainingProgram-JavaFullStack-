package encapsulation;

public class PrivateInnerClass {
	private class Inner{
		static void display() {
			System.out.println("static method inside private Inner class");
		}
		void display1() {
			System.out.println("non-static method inside private Inner class");
		}
		
	}
	
	void createInner() {
		Inner.display();
		Inner obj = new Inner();
		obj.display1();
	}
	
	public static void main(String[] args) {
		PrivateInnerClass obj1 = new PrivateInnerClass();
		obj1.createInner();
	}
}
