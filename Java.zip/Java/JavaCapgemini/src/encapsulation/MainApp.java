package encapsulation;

public class MainApp {
	
	public static void main(String[] args) {
		EncapsulationClass obj = new EncapsulationClass();
		obj.setDetails("Aryan", "Aryan789");
		obj.getDetails();
	}
}
