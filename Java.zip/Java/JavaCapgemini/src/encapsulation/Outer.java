package encapsulation;

public class Outer {
	static class Inner{
		static void display() {
			System.out.println("static method inside static-inner class.");
		}
		void display1() {
			System.out.println("non-static method inside static-inner class.");
		}
	}
}
