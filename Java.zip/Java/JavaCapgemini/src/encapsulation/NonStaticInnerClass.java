package encapsulation;

public class NonStaticInnerClass {
	class Inner{
		static void display() {
			System.out.println("static method inside non-static-inner class.");
		}
		void display1() {
			System.out.println("non-static method inside non-static-inner class.");
		}
	}
}
